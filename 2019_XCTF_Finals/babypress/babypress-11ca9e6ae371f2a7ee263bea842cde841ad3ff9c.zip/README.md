## babypress

Let's dig down into the easy baby-level wordpress 0day(?) exploitation!

by stypr
