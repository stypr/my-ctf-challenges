<?php /* created 2022-11-05 09:16:28 */ ?>
<?php $page = HTMLPage::getPage(); ?>
<style type="text/css">
.form_table th{
	width:200px;
}
.inner_table{
	margin:10px 5px;
	table-layout:fixed;
}
.inner_table .even td{
	background-color:white;
}
input[type="text"], input[type="password"]{
	width: 100%;
}
</style>

<div style="padding:0 20px;">

	<h1>サーバ設定</h1>
	
	<div class="table_container">
		
		<?php if(!isset($page["success_update_visible"]) || $page["success_update_visible"]){ ?><div class="success">設定を保存しました。</div><?php } ?>

		<?php if(!isset($page["success_test_visible"]) || $page["success_test_visible"]){ ?><div class="success">メールを送信しました。</div><?php } ?>

		<?php if(!isset($page["failed_to_update_visible"]) || $page["failed_to_update_visible"]){ ?><div class="error">更新に失敗しました</div><?php } ?>

		<?php if(!isset($page["failed_to_test_visible"]) || $page["failed_to_test_visible"]){ ?><div class="error">送信に失敗しました。サーバの設定を確認して下さい。</div><?php } ?>

		
		<?php if(!isset($page["form_visible"]) || $page["form_visible"]){ ?><?php $form = $page["form"]; ?><form<?php if(strlen($page["form_attribute"]["action"])){ ?> action="<?php echo $page["form_attribute"]["action"]; ?>"<?php } ?><?php if(strlen($page["form_attribute"]["method"])){ ?> method="<?php echo $page["form_attribute"]["method"]; ?>"<?php } ?><?php if($page["form_attribute"]["disabled"]){ ?> disabled="<?php echo $page["form_attribute"]["disabled"]; ?>"<?php } ?>><input type="hidden" name="soy2_token" value="<?php echo soy2_get_token(); ?>">
		<?php if(!isset($page["is_ssl_enabled_visible"]) || $page["is_ssl_enabled_visible"]){ ?><input<?php if(strlen($page["is_ssl_enabled_attribute"]["id"])){ ?> id="<?php echo $page["is_ssl_enabled_attribute"]["id"]; ?>"<?php } ?><?php if(strlen($page["is_ssl_enabled_attribute"]["value"])){ ?> value="<?php echo $page["is_ssl_enabled_attribute"]["value"]; ?>"<?php } ?><?php if(strlen($page["is_ssl_enabled_attribute"]["type"])){ ?> type="<?php echo $page["is_ssl_enabled_attribute"]["type"]; ?>"<?php } ?><?php if($page["is_ssl_enabled_attribute"]["disabled"]){ ?> disabled="<?php echo $page["is_ssl_enabled_attribute"]["disabled"]; ?>"<?php } ?><?php if($page["is_ssl_enabled_attribute"]["readonly"]){ ?> readonly="<?php echo $page["is_ssl_enabled_attribute"]["readonly"]; ?>"<?php } ?>><?php } ?>

		<?php if(!isset($page["is_imap_enabled_visible"]) || $page["is_imap_enabled_visible"]){ ?><input<?php if(strlen($page["is_imap_enabled_attribute"]["id"])){ ?> id="<?php echo $page["is_imap_enabled_attribute"]["id"]; ?>"<?php } ?><?php if(strlen($page["is_imap_enabled_attribute"]["value"])){ ?> value="<?php echo $page["is_imap_enabled_attribute"]["value"]; ?>"<?php } ?><?php if(strlen($page["is_imap_enabled_attribute"]["type"])){ ?> type="<?php echo $page["is_imap_enabled_attribute"]["type"]; ?>"<?php } ?><?php if($page["is_imap_enabled_attribute"]["disabled"]){ ?> disabled="<?php echo $page["is_imap_enabled_attribute"]["disabled"]; ?>"<?php } ?><?php if($page["is_imap_enabled_attribute"]["readonly"]){ ?> readonly="<?php echo $page["is_imap_enabled_attribute"]["readonly"]; ?>"<?php } ?>><?php } ?>

		
		<table class="form_table list">
			<col style="width:200px" />
			<thead>
				<tr>
					<td colspan="2">SMTP設定</td>
				</tr>
			</thead>
			<tr>
				<th>送信方法</th>
				<td>
					<?php if(!isset($page["send_server_type_sendmail_visible"]) || $page["send_server_type_sendmail_visible"]){ ?><input<?php if(strlen($page["send_server_type_sendmail_attribute"]["name"])){ ?> name="<?php echo $page["send_server_type_sendmail_attribute"]["name"]; ?>"<?php } ?><?php if(strlen($page["send_server_type_sendmail_attribute"]["value"])){ ?> value="<?php echo $page["send_server_type_sendmail_attribute"]["value"]; ?>"<?php } ?><?php if(strlen($page["send_server_type_sendmail_attribute"]["onclick"])){ ?> onclick="<?php echo $page["send_server_type_sendmail_attribute"]["onclick"]; ?>"<?php } ?> type="radio"<?php if($page["send_server_type_sendmail_attribute"]["disabled"]){ ?> disabled="<?php echo $page["send_server_type_sendmail_attribute"]["disabled"]; ?>"<?php } ?><?php if($page["send_server_type_sendmail_attribute"]["readonly"]){ ?> readonly="<?php echo $page["send_server_type_sendmail_attribute"]["readonly"]; ?>"<?php } ?><?php if(strlen($page["send_server_type_sendmail_attribute"]["id"])){ ?> id="<?php echo $page["send_server_type_sendmail_attribute"]["id"]; ?>"<?php } ?><?php if($page["send_server_type_sendmail_attribute"]["checked"]){ ?> checked="<?php echo $page["send_server_type_sendmail_attribute"]["checked"]; ?>"<?php } ?>><?php if(strlen($page["send_server_type_sendmail"])>0){ ?><label for="<?php echo $page["send_server_type_sendmail_attribute"]["id"]; ?>"><?php echo $page["send_server_type_sendmail"]; ?></label><?php } ?><?php } ?>

					<label for="send_server_type_sendmail">sendmail (PHPのmail関数)</label>
					<?php if(!isset($page["send_server_type_smtp_visible"]) || $page["send_server_type_smtp_visible"]){ ?><input<?php if(strlen($page["send_server_type_smtp_attribute"]["name"])){ ?> name="<?php echo $page["send_server_type_smtp_attribute"]["name"]; ?>"<?php } ?><?php if(strlen($page["send_server_type_smtp_attribute"]["value"])){ ?> value="<?php echo $page["send_server_type_smtp_attribute"]["value"]; ?>"<?php } ?><?php if(strlen($page["send_server_type_smtp_attribute"]["onclick"])){ ?> onclick="<?php echo $page["send_server_type_smtp_attribute"]["onclick"]; ?>"<?php } ?> type="radio"<?php if($page["send_server_type_smtp_attribute"]["disabled"]){ ?> disabled="<?php echo $page["send_server_type_smtp_attribute"]["disabled"]; ?>"<?php } ?><?php if($page["send_server_type_smtp_attribute"]["readonly"]){ ?> readonly="<?php echo $page["send_server_type_smtp_attribute"]["readonly"]; ?>"<?php } ?><?php if(strlen($page["send_server_type_smtp_attribute"]["id"])){ ?> id="<?php echo $page["send_server_type_smtp_attribute"]["id"]; ?>"<?php } ?><?php if($page["send_server_type_smtp_attribute"]["checked"]){ ?> checked="<?php echo $page["send_server_type_smtp_attribute"]["checked"]; ?>"<?php } ?>><?php if(strlen($page["send_server_type_smtp"])>0){ ?><label for="<?php echo $page["send_server_type_smtp_attribute"]["id"]; ?>"><?php echo $page["send_server_type_smtp"]; ?></label><?php } ?><?php } ?>

					<label for="send_server_type_smtp">SMTP</label>
				</td>
			</tr>
			<tr>
				<th rowspan="2">サーバ設定</th>
				<td>
					<table class="inner_table">
						<col style="width:100px;text-align:left;" />
						<tr>
							<th>サーバ</th>
							<td><?php if(!isset($page["send_server_address_visible"]) || $page["send_server_address_visible"]){ ?><input<?php if(strlen($page["send_server_address_attribute"]["id"])){ ?> id="<?php echo $page["send_server_address_attribute"]["id"]; ?>"<?php } ?><?php if(strlen($page["send_server_address_attribute"]["name"])){ ?> name="<?php echo $page["send_server_address_attribute"]["name"]; ?>"<?php } ?><?php if(strlen($page["send_server_address_attribute"]["value"])){ ?> value="<?php echo $page["send_server_address_attribute"]["value"]; ?>"<?php } ?> type="text"<?php if($page["send_server_address_attribute"]["disabled"]){ ?> disabled="<?php echo $page["send_server_address_attribute"]["disabled"]; ?>"<?php } ?><?php if($page["send_server_address_attribute"]["readonly"]){ ?> readonly="<?php echo $page["send_server_address_attribute"]["readonly"]; ?>"<?php } ?>><?php } ?>
</td>
						</tr>
						<tr>
							<th>ポート</th>
							<td><?php if(!isset($page["send_server_port_visible"]) || $page["send_server_port_visible"]){ ?><input<?php if(strlen($page["send_server_port_attribute"]["id"])){ ?> id="<?php echo $page["send_server_port_attribute"]["id"]; ?>"<?php } ?><?php if(strlen($page["send_server_port_attribute"]["name"])){ ?> name="<?php echo $page["send_server_port_attribute"]["name"]; ?>"<?php } ?><?php if(strlen($page["send_server_port_attribute"]["value"])){ ?> value="<?php echo $page["send_server_port_attribute"]["value"]; ?>"<?php } ?> type="text"<?php if($page["send_server_port_attribute"]["disabled"]){ ?> disabled="<?php echo $page["send_server_port_attribute"]["disabled"]; ?>"<?php } ?><?php if($page["send_server_port_attribute"]["readonly"]){ ?> readonly="<?php echo $page["send_server_port_attribute"]["readonly"]; ?>"<?php } ?>><?php } ?>
</td>
						</tr>
					</table>
				</td>
			</tr>
			<tr>
				<td>
					<input type="hidden" name="isUseSSLSendServer" value="0" />
					<?php if(!isset($page["is_use_ssl_send_server_visible"]) || $page["is_use_ssl_send_server_visible"]){ ?><input<?php if(strlen($page["is_use_ssl_send_server_attribute"]["name"])){ ?> name="<?php echo $page["is_use_ssl_send_server_attribute"]["name"]; ?>"<?php } ?><?php if(strlen($page["is_use_ssl_send_server_attribute"]["value"])){ ?> value="<?php echo $page["is_use_ssl_send_server_attribute"]["value"]; ?>"<?php } ?><?php if(strlen($page["is_use_ssl_send_server_attribute"]["onclick"])){ ?> onclick="<?php echo $page["is_use_ssl_send_server_attribute"]["onclick"]; ?>"<?php } ?> type="checkbox"<?php if($page["is_use_ssl_send_server_attribute"]["disabled"]){ ?> disabled="<?php echo $page["is_use_ssl_send_server_attribute"]["disabled"]; ?>"<?php } ?><?php if($page["is_use_ssl_send_server_attribute"]["readonly"]){ ?> readonly="<?php echo $page["is_use_ssl_send_server_attribute"]["readonly"]; ?>"<?php } ?><?php if(strlen($page["is_use_ssl_send_server_attribute"]["id"])){ ?> id="<?php echo $page["is_use_ssl_send_server_attribute"]["id"]; ?>"<?php } ?><?php if($page["is_use_ssl_send_server_attribute"]["checked"]){ ?> checked="<?php echo $page["is_use_ssl_send_server_attribute"]["checked"]; ?>"<?php } ?>><?php if(strlen($page["is_use_ssl_send_server"])>0){ ?><label for="<?php echo $page["is_use_ssl_send_server_attribute"]["id"]; ?>"><?php echo $page["is_use_ssl_send_server"]; ?></label><?php } ?><?php } ?>

					<label for="is_use_ssl_send_server">SSL(暗号化)を使用する</label>
					
					<?php if(!isset($page["ssl_disabled_visible"]) || $page["ssl_disabled_visible"]){ ?><p class="error">SSLが使えないサーバーです。</p><?php } ?>

				</td>
			</tr>

			<tr>
				<th rowspan="2">認証</th>
				<td>
					<input name="isUseSMTPAuth" type="hidden" value="0" />
					<?php if(!isset($page["is_use_smtp_auth_visible"]) || $page["is_use_smtp_auth_visible"]){ ?><input<?php if(strlen($page["is_use_smtp_auth_attribute"]["name"])){ ?> name="<?php echo $page["is_use_smtp_auth_attribute"]["name"]; ?>"<?php } ?><?php if(strlen($page["is_use_smtp_auth_attribute"]["value"])){ ?> value="<?php echo $page["is_use_smtp_auth_attribute"]["value"]; ?>"<?php } ?><?php if(strlen($page["is_use_smtp_auth_attribute"]["onclick"])){ ?> onclick="<?php echo $page["is_use_smtp_auth_attribute"]["onclick"]; ?>"<?php } ?> type="checkbox"<?php if(strlen($page["is_use_smtp_auth_attribute"]["id"])){ ?> id="<?php echo $page["is_use_smtp_auth_attribute"]["id"]; ?>"<?php } ?><?php if($page["is_use_smtp_auth_attribute"]["disabled"]){ ?> disabled="<?php echo $page["is_use_smtp_auth_attribute"]["disabled"]; ?>"<?php } ?><?php if($page["is_use_smtp_auth_attribute"]["readonly"]){ ?> readonly="<?php echo $page["is_use_smtp_auth_attribute"]["readonly"]; ?>"<?php } ?><?php if($page["is_use_smtp_auth_attribute"]["checked"]){ ?> checked="<?php echo $page["is_use_smtp_auth_attribute"]["checked"]; ?>"<?php } ?>><?php if(strlen($page["is_use_smtp_auth"])>0){ ?><label for="<?php echo $page["is_use_smtp_auth_attribute"]["id"]; ?>"><?php echo $page["is_use_smtp_auth"]; ?></label><?php } ?><?php } ?>

					<label for="is_use_smtp_auth">SMTP認証(SMTP-AUTH)を使用する</label>
					<table class="inner_table">
						<col style="width:100px;text-align:left;" />
						<tr>
							<th>ユーザ名</th>
							<td><?php if(!isset($page["send_server_user_visible"]) || $page["send_server_user_visible"]){ ?><input<?php if(strlen($page["send_server_user_attribute"]["id"])){ ?> id="<?php echo $page["send_server_user_attribute"]["id"]; ?>"<?php } ?><?php if(strlen($page["send_server_user_attribute"]["name"])){ ?> name="<?php echo $page["send_server_user_attribute"]["name"]; ?>"<?php } ?><?php if(strlen($page["send_server_user_attribute"]["value"])){ ?> value="<?php echo $page["send_server_user_attribute"]["value"]; ?>"<?php } ?> type="text"<?php if($page["send_server_user_attribute"]["disabled"]){ ?> disabled="<?php echo $page["send_server_user_attribute"]["disabled"]; ?>"<?php } ?><?php if($page["send_server_user_attribute"]["readonly"]){ ?> readonly="<?php echo $page["send_server_user_attribute"]["readonly"]; ?>"<?php } ?>><?php } ?>
</td>
						</tr>
						<tr>
							<th>パスワード</th>
							<td><?php if(!isset($page["send_server_password_visible"]) || $page["send_server_password_visible"]){ ?><input<?php if(strlen($page["send_server_password_attribute"]["id"])){ ?> id="<?php echo $page["send_server_password_attribute"]["id"]; ?>"<?php } ?><?php if(strlen($page["send_server_password_attribute"]["name"])){ ?> name="<?php echo $page["send_server_password_attribute"]["name"]; ?>"<?php } ?><?php if(strlen($page["send_server_password_attribute"]["value"])){ ?> value="<?php echo $page["send_server_password_attribute"]["value"]; ?>"<?php } ?><?php if(strlen($page["send_server_password_attribute"]["autocomplete"])){ ?> autocomplete="<?php echo $page["send_server_password_attribute"]["autocomplete"]; ?>"<?php } ?> type="password"<?php if($page["send_server_password_attribute"]["disabled"]){ ?> disabled="<?php echo $page["send_server_password_attribute"]["disabled"]; ?>"<?php } ?><?php if($page["send_server_password_attribute"]["readonly"]){ ?> readonly="<?php echo $page["send_server_password_attribute"]["readonly"]; ?>"<?php } ?>><?php } ?>
</td>
						</tr>

					</table>
				</td>
			</tr>
			<tr>
				<td>
					<input name="isUsePopBeforeSMTP" type="hidden" value="0" />	
					<?php if(!isset($page["is_use_pop_before_smtp_visible"]) || $page["is_use_pop_before_smtp_visible"]){ ?><input<?php if(strlen($page["is_use_pop_before_smtp_attribute"]["name"])){ ?> name="<?php echo $page["is_use_pop_before_smtp_attribute"]["name"]; ?>"<?php } ?><?php if(strlen($page["is_use_pop_before_smtp_attribute"]["value"])){ ?> value="<?php echo $page["is_use_pop_before_smtp_attribute"]["value"]; ?>"<?php } ?><?php if(strlen($page["is_use_pop_before_smtp_attribute"]["onclick"])){ ?> onclick="<?php echo $page["is_use_pop_before_smtp_attribute"]["onclick"]; ?>"<?php } ?> type="checkbox"<?php if($page["is_use_pop_before_smtp_attribute"]["disabled"]){ ?> disabled="<?php echo $page["is_use_pop_before_smtp_attribute"]["disabled"]; ?>"<?php } ?><?php if($page["is_use_pop_before_smtp_attribute"]["readonly"]){ ?> readonly="<?php echo $page["is_use_pop_before_smtp_attribute"]["readonly"]; ?>"<?php } ?><?php if(strlen($page["is_use_pop_before_smtp_attribute"]["id"])){ ?> id="<?php echo $page["is_use_pop_before_smtp_attribute"]["id"]; ?>"<?php } ?><?php if($page["is_use_pop_before_smtp_attribute"]["checked"]){ ?> checked="<?php echo $page["is_use_pop_before_smtp_attribute"]["checked"]; ?>"<?php } ?>><?php if(strlen($page["is_use_pop_before_smtp"])>0){ ?><label for="<?php echo $page["is_use_pop_before_smtp_attribute"]["id"]; ?>"><?php echo $page["is_use_pop_before_smtp"]; ?></label><?php } ?><?php } ?>

					<label for="is_use_pop_before_smtp">「POP/IMAP before SMTP」を使用する</label>
				</td>
			</tr>
		</table>
		
		<table class="form_table list">
			<col style="width:200px" />
			<thead>
				<tr>
					<td colspan="2">POP/IMAP設定</td>
				</tr>
			</thead>
			<tr>
				<th>受信方法</th>
				<td>
					<?php if(!isset($page["receive_server_type_pop_visible"]) || $page["receive_server_type_pop_visible"]){ ?><input<?php if(strlen($page["receive_server_type_pop_attribute"]["name"])){ ?> name="<?php echo $page["receive_server_type_pop_attribute"]["name"]; ?>"<?php } ?><?php if(strlen($page["receive_server_type_pop_attribute"]["value"])){ ?> value="<?php echo $page["receive_server_type_pop_attribute"]["value"]; ?>"<?php } ?><?php if(strlen($page["receive_server_type_pop_attribute"]["onclick"])){ ?> onclick="<?php echo $page["receive_server_type_pop_attribute"]["onclick"]; ?>"<?php } ?> type="radio"<?php if($page["receive_server_type_pop_attribute"]["disabled"]){ ?> disabled="<?php echo $page["receive_server_type_pop_attribute"]["disabled"]; ?>"<?php } ?><?php if($page["receive_server_type_pop_attribute"]["readonly"]){ ?> readonly="<?php echo $page["receive_server_type_pop_attribute"]["readonly"]; ?>"<?php } ?><?php if(strlen($page["receive_server_type_pop_attribute"]["id"])){ ?> id="<?php echo $page["receive_server_type_pop_attribute"]["id"]; ?>"<?php } ?><?php if($page["receive_server_type_pop_attribute"]["checked"]){ ?> checked="<?php echo $page["receive_server_type_pop_attribute"]["checked"]; ?>"<?php } ?>><?php if(strlen($page["receive_server_type_pop"])>0){ ?><label for="<?php echo $page["receive_server_type_pop_attribute"]["id"]; ?>"><?php echo $page["receive_server_type_pop"]; ?></label><?php } ?><?php } ?>

					<label for="receive_server_type_pop">POP3</label>
					
					<?php if(!isset($page["receive_server_type_imap_visible"]) || $page["receive_server_type_imap_visible"]){ ?><input<?php if(strlen($page["receive_server_type_imap_attribute"]["name"])){ ?> name="<?php echo $page["receive_server_type_imap_attribute"]["name"]; ?>"<?php } ?><?php if(strlen($page["receive_server_type_imap_attribute"]["value"])){ ?> value="<?php echo $page["receive_server_type_imap_attribute"]["value"]; ?>"<?php } ?><?php if(strlen($page["receive_server_type_imap_attribute"]["onclick"])){ ?> onclick="<?php echo $page["receive_server_type_imap_attribute"]["onclick"]; ?>"<?php } ?> type="radio"<?php if($page["receive_server_type_imap_attribute"]["disabled"]){ ?> disabled="<?php echo $page["receive_server_type_imap_attribute"]["disabled"]; ?>"<?php } ?><?php if($page["receive_server_type_imap_attribute"]["readonly"]){ ?> readonly="<?php echo $page["receive_server_type_imap_attribute"]["readonly"]; ?>"<?php } ?><?php if(strlen($page["receive_server_type_imap_attribute"]["id"])){ ?> id="<?php echo $page["receive_server_type_imap_attribute"]["id"]; ?>"<?php } ?><?php if($page["receive_server_type_imap_attribute"]["checked"]){ ?> checked="<?php echo $page["receive_server_type_imap_attribute"]["checked"]; ?>"<?php } ?>><?php if(strlen($page["receive_server_type_imap"])>0){ ?><label for="<?php echo $page["receive_server_type_imap_attribute"]["id"]; ?>"><?php echo $page["receive_server_type_imap"]; ?></label><?php } ?><?php } ?>

					<label for="receive_server_type_imap">IMAP</label>
					
					<?php if(!isset($page["imap_disabled_visible"]) || $page["imap_disabled_visible"]){ ?><p class="error">IMAPが使えないサーバーです。</p><?php } ?>

				</td>
			</tr>
			<tr>
				<th rowspan="2">サーバ設定</th>
				<td style="background-color:white;">
					<table class="inner_table">
						<col style="width:100px;text-align:left;" />
						<tr>
							<th>サーバ</th>
							<td><?php if(!isset($page["receive_server_address_visible"]) || $page["receive_server_address_visible"]){ ?><input<?php if(strlen($page["receive_server_address_attribute"]["id"])){ ?> id="<?php echo $page["receive_server_address_attribute"]["id"]; ?>"<?php } ?><?php if(strlen($page["receive_server_address_attribute"]["name"])){ ?> name="<?php echo $page["receive_server_address_attribute"]["name"]; ?>"<?php } ?><?php if(strlen($page["receive_server_address_attribute"]["value"])){ ?> value="<?php echo $page["receive_server_address_attribute"]["value"]; ?>"<?php } ?> type="text"<?php if($page["receive_server_address_attribute"]["disabled"]){ ?> disabled="<?php echo $page["receive_server_address_attribute"]["disabled"]; ?>"<?php } ?><?php if($page["receive_server_address_attribute"]["readonly"]){ ?> readonly="<?php echo $page["receive_server_address_attribute"]["readonly"]; ?>"<?php } ?>><?php } ?>
</td>
						</tr>
						<tr>
							<th>ポート</th>
							<td><?php if(!isset($page["receive_server_port_visible"]) || $page["receive_server_port_visible"]){ ?><input<?php if(strlen($page["receive_server_port_attribute"]["id"])){ ?> id="<?php echo $page["receive_server_port_attribute"]["id"]; ?>"<?php } ?><?php if(strlen($page["receive_server_port_attribute"]["name"])){ ?> name="<?php echo $page["receive_server_port_attribute"]["name"]; ?>"<?php } ?><?php if(strlen($page["receive_server_port_attribute"]["value"])){ ?> value="<?php echo $page["receive_server_port_attribute"]["value"]; ?>"<?php } ?> type="text"<?php if($page["receive_server_port_attribute"]["disabled"]){ ?> disabled="<?php echo $page["receive_server_port_attribute"]["disabled"]; ?>"<?php } ?><?php if($page["receive_server_port_attribute"]["readonly"]){ ?> readonly="<?php echo $page["receive_server_port_attribute"]["readonly"]; ?>"<?php } ?>><?php } ?>
</td>
						</tr>
						<tr>
							<th>ユーザ名</th>
							<td><?php if(!isset($page["receive_server_user_visible"]) || $page["receive_server_user_visible"]){ ?><input<?php if(strlen($page["receive_server_user_attribute"]["id"])){ ?> id="<?php echo $page["receive_server_user_attribute"]["id"]; ?>"<?php } ?><?php if(strlen($page["receive_server_user_attribute"]["name"])){ ?> name="<?php echo $page["receive_server_user_attribute"]["name"]; ?>"<?php } ?><?php if(strlen($page["receive_server_user_attribute"]["value"])){ ?> value="<?php echo $page["receive_server_user_attribute"]["value"]; ?>"<?php } ?> type="text"<?php if($page["receive_server_user_attribute"]["disabled"]){ ?> disabled="<?php echo $page["receive_server_user_attribute"]["disabled"]; ?>"<?php } ?><?php if($page["receive_server_user_attribute"]["readonly"]){ ?> readonly="<?php echo $page["receive_server_user_attribute"]["readonly"]; ?>"<?php } ?>><?php } ?>
</td>
						</tr>
						<tr>
							<th>パスワード</th>
							<td><?php if(!isset($page["receive_server_password_visible"]) || $page["receive_server_password_visible"]){ ?><input<?php if(strlen($page["receive_server_password_attribute"]["id"])){ ?> id="<?php echo $page["receive_server_password_attribute"]["id"]; ?>"<?php } ?><?php if(strlen($page["receive_server_password_attribute"]["name"])){ ?> name="<?php echo $page["receive_server_password_attribute"]["name"]; ?>"<?php } ?><?php if(strlen($page["receive_server_password_attribute"]["value"])){ ?> value="<?php echo $page["receive_server_password_attribute"]["value"]; ?>"<?php } ?><?php if(strlen($page["receive_server_password_attribute"]["autocomplete"])){ ?> autocomplete="<?php echo $page["receive_server_password_attribute"]["autocomplete"]; ?>"<?php } ?> type="password"<?php if($page["receive_server_password_attribute"]["disabled"]){ ?> disabled="<?php echo $page["receive_server_password_attribute"]["disabled"]; ?>"<?php } ?><?php if($page["receive_server_password_attribute"]["readonly"]){ ?> readonly="<?php echo $page["receive_server_password_attribute"]["readonly"]; ?>"<?php } ?>><?php } ?>
</td>
						</tr>
					</table>
				</td>
			</tr>
			
			<tr>
				<td>
					<input name="isUseSSLReceiveServer" type="hidden" value="0" />
					<?php if(!isset($page["is_use_ssl_receive_server_visible"]) || $page["is_use_ssl_receive_server_visible"]){ ?><input<?php if(strlen($page["is_use_ssl_receive_server_attribute"]["name"])){ ?> name="<?php echo $page["is_use_ssl_receive_server_attribute"]["name"]; ?>"<?php } ?><?php if(strlen($page["is_use_ssl_receive_server_attribute"]["value"])){ ?> value="<?php echo $page["is_use_ssl_receive_server_attribute"]["value"]; ?>"<?php } ?><?php if(strlen($page["is_use_ssl_receive_server_attribute"]["onclick"])){ ?> onclick="<?php echo $page["is_use_ssl_receive_server_attribute"]["onclick"]; ?>"<?php } ?> type="checkbox"<?php if($page["is_use_ssl_receive_server_attribute"]["disabled"]){ ?> disabled="<?php echo $page["is_use_ssl_receive_server_attribute"]["disabled"]; ?>"<?php } ?><?php if($page["is_use_ssl_receive_server_attribute"]["readonly"]){ ?> readonly="<?php echo $page["is_use_ssl_receive_server_attribute"]["readonly"]; ?>"<?php } ?><?php if(strlen($page["is_use_ssl_receive_server_attribute"]["id"])){ ?> id="<?php echo $page["is_use_ssl_receive_server_attribute"]["id"]; ?>"<?php } ?><?php if($page["is_use_ssl_receive_server_attribute"]["checked"]){ ?> checked="<?php echo $page["is_use_ssl_receive_server_attribute"]["checked"]; ?>"<?php } ?>><?php if(strlen($page["is_use_ssl_receive_server"])>0){ ?><label for="<?php echo $page["is_use_ssl_receive_server_attribute"]["id"]; ?>"><?php echo $page["is_use_ssl_receive_server"]; ?></label><?php } ?><?php } ?>

					<label for="is_use_ssl_receive_server">SSL(暗号化)を使用する</label>

					<?php if(!isset($page["ssl_disabled_visible"]) || $page["ssl_disabled_visible"]){ ?><p class="error">SSLが使えないサーバーです。</p><?php } ?>

				</td>
			</tr>
		</table>
		
		<table class="form_table list">
			<col style="width:200px" />
			<thead>
				<tr>
					<td colspan="2">メール設定</td>
				</tr>
			</thead>
			<tr>
				<th>管理者メールアドレス<br/>(From)</th>
				<td>
					<?php if(!isset($page["administrator_address_visible"]) || $page["administrator_address_visible"]){ ?><input<?php if(strlen($page["administrator_address_attribute"]["name"])){ ?> name="<?php echo $page["administrator_address_attribute"]["name"]; ?>"<?php } ?><?php if(strlen($page["administrator_address_attribute"]["value"])){ ?> value="<?php echo $page["administrator_address_attribute"]["value"]; ?>"<?php } ?> id="administrator_address" type="text"<?php if($page["administrator_address_attribute"]["disabled"]){ ?> disabled="<?php echo $page["administrator_address_attribute"]["disabled"]; ?>"<?php } ?><?php if($page["administrator_address_attribute"]["readonly"]){ ?> readonly="<?php echo $page["administrator_address_attribute"]["readonly"]; ?>"<?php } ?>><?php } ?>

				</td>
			</tr>
			<tr>
				<th>管理者名称</th>
				<td>
					<?php if(!isset($page["administrator_name_visible"]) || $page["administrator_name_visible"]){ ?><input<?php if(strlen($page["administrator_name_attribute"]["name"])){ ?> name="<?php echo $page["administrator_name_attribute"]["name"]; ?>"<?php } ?><?php if(strlen($page["administrator_name_attribute"]["value"])){ ?> value="<?php echo $page["administrator_name_attribute"]["value"]; ?>"<?php } ?> type="text"<?php if($page["administrator_name_attribute"]["disabled"]){ ?> disabled="<?php echo $page["administrator_name_attribute"]["disabled"]; ?>"<?php } ?><?php if($page["administrator_name_attribute"]["readonly"]){ ?> readonly="<?php echo $page["administrator_name_attribute"]["readonly"]; ?>"<?php } ?>><?php } ?>

				</td>
			</tr>
			
			<tr>
				<th>返信先メールアドレス<br/>(Reply-To)</th>
				<td>
					<?php if(!isset($page["return_address_visible"]) || $page["return_address_visible"]){ ?><input<?php if(strlen($page["return_address_attribute"]["name"])){ ?> name="<?php echo $page["return_address_attribute"]["name"]; ?>"<?php } ?><?php if(strlen($page["return_address_attribute"]["value"])){ ?> value="<?php echo $page["return_address_attribute"]["value"]; ?>"<?php } ?> type="text"<?php if($page["return_address_attribute"]["disabled"]){ ?> disabled="<?php echo $page["return_address_attribute"]["disabled"]; ?>"<?php } ?><?php if($page["return_address_attribute"]["readonly"]){ ?> readonly="<?php echo $page["return_address_attribute"]["readonly"]; ?>"<?php } ?>><?php } ?>

				</td>
			</tr>
			<tr>
				<th>返信先名称</th>
				<td>
					<?php if(!isset($page["return_name_visible"]) || $page["return_name_visible"]){ ?><input<?php if(strlen($page["return_name_attribute"]["name"])){ ?> name="<?php echo $page["return_name_attribute"]["name"]; ?>"<?php } ?><?php if(strlen($page["return_name_attribute"]["value"])){ ?> value="<?php echo $page["return_name_attribute"]["value"]; ?>"<?php } ?> type="text"<?php if($page["return_name_attribute"]["disabled"]){ ?> disabled="<?php echo $page["return_name_attribute"]["disabled"]; ?>"<?php } ?><?php if($page["return_name_attribute"]["readonly"]){ ?> readonly="<?php echo $page["return_name_attribute"]["readonly"]; ?>"<?php } ?>><?php } ?>

				</td>
			</tr>

			<tr>
				<th>文字コード</th>
				<td>
					<?php if(!isset($page["mail_encoding_visible"]) || $page["mail_encoding_visible"]){ ?><select<?php if(strlen($page["mail_encoding_attribute"]["name"])){ ?> name="<?php echo $page["mail_encoding_attribute"]["name"]; ?>"<?php } ?><?php if($page["mail_encoding_attribute"]["disabled"]){ ?> disabled="<?php echo $page["mail_encoding_attribute"]["disabled"]; ?>"<?php } ?><?php if($page["mail_encoding_attribute"]["readonly"]){ ?> readonly="<?php echo $page["mail_encoding_attribute"]["readonly"]; ?>"<?php } ?><?php if($page["mail_encoding_attribute"]["multiple"]){ ?> multiple="<?php echo $page["mail_encoding_attribute"]["multiple"]; ?>"<?php } ?>><?php echo $page["mail_encoding"]; ?></select><?php } ?>

				</td>
			</tr>
		</table>
		
		<table class="form_table list">
			<col style="width:200px" />
			<thead>
				<tr>
					<td colspan="2">ファイル設定</td>
				</tr>
			</thead>
			<tr>
				<th>アップロードディレクトリ</th>
				<td>
					<?php if(!isset($page["upload_root_dir_visible"]) || $page["upload_root_dir_visible"]){ ?><span><?php echo $page["upload_root_dir"]; ?></span><?php } ?>
<br/>
					<?php if(!isset($page["upload_dir_visible"]) || $page["upload_dir_visible"]){ ?><input<?php if(strlen($page["upload_dir_attribute"]["name"])){ ?> name="<?php echo $page["upload_dir_attribute"]["name"]; ?>"<?php } ?><?php if(strlen($page["upload_dir_attribute"]["value"])){ ?> value="<?php echo $page["upload_dir_attribute"]["value"]; ?>"<?php } ?> type="text" style="width:70%;"<?php if($page["upload_dir_attribute"]["disabled"]){ ?> disabled="<?php echo $page["upload_dir_attribute"]["disabled"]; ?>"<?php } ?><?php if($page["upload_dir_attribute"]["readonly"]){ ?> readonly="<?php echo $page["upload_dir_attribute"]["readonly"]; ?>"<?php } ?>><?php } ?>
<br/>
					既存のディレクトリを指定してください。
				</td>
			</tr>
		</table>
		
		<?php if(!isset($page["admin_url_visible"]) || $page["admin_url_visible"]){ ?><input<?php if(strlen($page["admin_url_attribute"]["name"])){ ?> name="<?php echo $page["admin_url_attribute"]["name"]; ?>"<?php } ?><?php if(strlen($page["admin_url_attribute"]["value"])){ ?> value="<?php echo $page["admin_url_attribute"]["value"]; ?>"<?php } ?> type="hidden"<?php if($page["admin_url_attribute"]["disabled"]){ ?> disabled="<?php echo $page["admin_url_attribute"]["disabled"]; ?>"<?php } ?><?php if($page["admin_url_attribute"]["readonly"]){ ?> readonly="<?php echo $page["admin_url_attribute"]["readonly"]; ?>"<?php } ?>><?php } ?>

				
		<table class="button_table">
			<tr class="button_table_row">
				<td style="backgruond-color:white;">
					<input type="submit" class="submit_button" value="更新" />
				</td>
			</tr>
		</table>
		
		</form><?php } ?>

	</div>

	<div class="table_container">
		<h2>送信テスト</h2>
		<?php if(!isset($page["test_form_visible"]) || $page["test_form_visible"]){ ?><?php $test_form = $page["test_form"]; ?><form<?php if(strlen($page["test_form_attribute"]["action"])){ ?> action="<?php echo $page["test_form_attribute"]["action"]; ?>"<?php } ?><?php if(strlen($page["test_form_attribute"]["method"])){ ?> method="<?php echo $page["test_form_attribute"]["method"]; ?>"<?php } ?><?php if($page["test_form_attribute"]["disabled"]){ ?> disabled="<?php echo $page["test_form_attribute"]["disabled"]; ?>"<?php } ?>><input type="hidden" name="soy2_token" value="<?php echo soy2_get_token(); ?>">
		<table class="form_table list">
			<tr>
				<th>テストメールの送信先</th>
				<td>
					<?php if(!isset($page["test_mail_address_visible"]) || $page["test_mail_address_visible"]){ ?><input<?php if(strlen($page["test_mail_address_attribute"]["name"])){ ?> name="<?php echo $page["test_mail_address_attribute"]["name"]; ?>"<?php } ?><?php if(strlen($page["test_mail_address_attribute"]["value"])){ ?> value="<?php echo $page["test_mail_address_attribute"]["value"]; ?>"<?php } ?> type="text" id="test_mail_address"><?php echo $page["test_mail_address"]; ?></input><?php } ?>

				</td>
			</tr>
		</table>
		<table class="button_table">
			<tr class="button_table_row">
				<td style="backgruond-color:white;">
					<input type="submit" class="submit_button" value="テスト送信" onclick="return confirm_test_send();" />
				</td>
			</tr>
		</table>
		</form><?php } ?>

	</div>

</div>

<script type="text/javascript">
function changeSendPort(){
	var port = 25;
	if($("#is_use_ssl_send_server").prop("checked")){
		if($("#send_server_type_smtp").prop("checked"))port = 465;
	}
	
	$('#send_server_port').val(port);
}

function changeReceivePort(){
	var port = 110;
	if($("#is_use_ssl_receive_server").prop("checked")){
		if($("#receive_server_type_pop").prop("checked"))port = 995;
		if($("#receive_server_type_imap").prop("checked"))port = 993;
	}else{
		if($("#receive_server_type_pop").prop("checked"))port = 110;
		if($("#receive_server_type_imap").prop("checked"))port = 147;
	}
	
	$('#receive_server_port').val(port);	
}

function toggleSMTP(){
	var ids = [
		"send_server_address","send_server_port","send_server_user","send_server_password","is_use_ssl_send_server",
		"is_use_pop_before_smtp","is_use_smtp_auth",
		"receive_server_type_pop","receive_server_type_imap","receive_server_address","receive_server_port","receive_server_user","receive_server_password","is_use_ssl_receive_server"
	];
	if($("#send_server_type_smtp").prop("checked")){
	   $.each(ids,function(id, value){
	       $("#" + value).prop("disabled",false);
		});
		disableUseSSL();
		togglePOPIMAPSetting();
		toggleSMTPAUTHSetting();
	}else{
		$.each(ids, function(id, value){
			$("#" + value).prop("disabled","disabled");
		});
	}
}

function toggleSMTPAUTHSetting(){
	if($("#is_use_smtp_auth").prop("checked")){
		$("#send_server_user").prop("disabled","");
		$("#send_server_password").prop("disabled","");

		$("#is_use_pop_before_smtp").prop("checked",false);
		togglePOPIMAPSetting();
	}else{
		$("#send_server_user").prop("disabled","disabled");
		$("#send_server_password").prop("disabled","disabled");
	}
}

function togglePOPIMAPSetting(){
	var ids = ["receive_server_type_pop","receive_server_type_imap","receive_server_address","receive_server_port","receive_server_user","receive_server_password","is_use_ssl_receive_server"];
	if($("#is_use_pop_before_smtp").prop("checked")){
		$.each(function(id, value){
			$("#" + value).prop("disabled",false);
		});

		disableUseSSL();
		disableUseIMAP();

		$("#is_use_smtp_auth").prop("checked",false);
		toggleSMTPAUTHSetting();
	}else{
		$.each(ids,function(id, value){
			$("#" + value).prop("disabled","disabled");
		});
	}
}

function disableUseSSL(){
	if($("#is_ssl_enabled").val() == 0){
		$("#is_use_ssl_send_server").prop("disabled","disabled");
		$("#is_use_ssl_receive_server").prop("disabled","disabled");
	}
}

function disableUseIMAP(){
	if($("#is_imap_enabled").val() == 0){
		$("#receive_server_type_imap").prop("disabled","disabled");
	}
}

function confirm_test_send(){
    if($("#administrator_address").val().length < 1){
		alert("「管理者メールアドレス」を入力してください。");
		return false;
	};
	
	if($("#test_mail_address").val().length < 1){
		alert("「テストメールの送信先」を入力してください。");
		return false;
	};
	
	return confirm(
			"現在保存されている設定内容でテストメールを送信します。\n" + 
			"送信先: " + $("#test_mail_address").val() + "\n\n"
			+ "よろしければ「OK」を押してください。\n"
			+ "中止する場合は「キャンセル」を押してください。"
			);
}
</script>