<?php /* created 2022-11-05 09:14:10 */ ?>
<?php $page = HTMLPage::getPage(); ?>
<div class="functions">
	<div class="function">
		<a href="/app/index.php/inquiry/Inquiry">一覧</a>
	</div>
	<div class="function">
		<a href="/app/index.php/inquiry/Inquiry/Export">CSVエクスポート</a>
	</div>
	
	<br style="clear:both;" />
</div>

<div style="padding:0px 20px;">

<h1>問い合わせ一覧</h1>

<div style="margin-bottom:1.4em;"><?php ob_start(); ?>
	<?php if(!isset($page["search_form_visible"]) || $page["search_form_visible"]){ ?><form<?php if(strlen($page["search_form_attribute"]["method"])){ ?> method="<?php echo $page["search_form_attribute"]["method"]; ?>"<?php } ?><?php if(strlen($page["search_form_attribute"]["action"])){ ?> action="<?php echo $page["search_form_attribute"]["action"]; ?>"<?php } ?><?php if(strlen($page["search_form_attribute"]["onsubmit"])){ ?> onsubmit="<?php echo $page["search_form_attribute"]["onsubmit"]; ?>"<?php } ?>>
		<?php if(!isset($page["forms_visible"]) || $page["forms_visible"]){ ?><select<?php if(strlen($page["forms_attribute"]["name"])){ ?> name="<?php echo $page["forms_attribute"]["name"]; ?>"<?php } ?><?php if($page["forms_attribute"]["disabled"]){ ?> disabled="<?php echo $page["forms_attribute"]["disabled"]; ?>"<?php } ?><?php if($page["forms_attribute"]["readonly"]){ ?> readonly="<?php echo $page["forms_attribute"]["readonly"]; ?>"<?php } ?><?php if($page["forms_attribute"]["multiple"]){ ?> multiple="<?php echo $page["forms_attribute"]["multiple"]; ?>"<?php } ?>><option value="">フォームを指定</option><?php echo $page["forms"]; ?></select><?php } ?>

		<?php if(!isset($page["trackId_visible"]) || $page["trackId_visible"]){ ?><input<?php if(strlen($page["trackId_attribute"]["name"])){ ?> name="<?php echo $page["trackId_attribute"]["name"]; ?>"<?php } ?><?php if(strlen($page["trackId_attribute"]["value"])){ ?> value="<?php echo $page["trackId_attribute"]["value"]; ?>"<?php } ?><?php if(strlen($page["trackId_attribute"]["style"])){ ?> style="<?php echo $page["trackId_attribute"]["style"]; ?>"<?php } ?><?php if(strlen($page["trackId_attribute"]["onfocus"])){ ?> onfocus="<?php echo $page["trackId_attribute"]["onfocus"]; ?>"<?php } ?><?php if(strlen($page["trackId_attribute"]["onblur"])){ ?> onblur="<?php echo $page["trackId_attribute"]["onblur"]; ?>"<?php } ?> type="text"<?php if($page["trackId_attribute"]["disabled"]){ ?> disabled="<?php echo $page["trackId_attribute"]["disabled"]; ?>"<?php } ?><?php if($page["trackId_attribute"]["readonly"]){ ?> readonly="<?php echo $page["trackId_attribute"]["readonly"]; ?>"<?php } ?>><?php } ?>

		<?php if(!isset($page["start_visible"]) || $page["start_visible"]){ ?><input<?php if(strlen($page["start_attribute"]["name"])){ ?> name="<?php echo $page["start_attribute"]["name"]; ?>"<?php } ?><?php if(strlen($page["start_attribute"]["value"])){ ?> value="<?php echo $page["start_attribute"]["value"]; ?>"<?php } ?><?php if(strlen($page["start_attribute"]["style"])){ ?> style="<?php echo $page["start_attribute"]["style"]; ?>"<?php } ?><?php if(strlen($page["start_attribute"]["onfocus"])){ ?> onfocus="<?php echo $page["start_attribute"]["onfocus"]; ?>"<?php } ?><?php if(strlen($page["start_attribute"]["onblur"])){ ?> onblur="<?php echo $page["start_attribute"]["onblur"]; ?>"<?php } ?> type="text" class="date_picker_start"<?php if($page["start_attribute"]["disabled"]){ ?> disabled="<?php echo $page["start_attribute"]["disabled"]; ?>"<?php } ?><?php if($page["start_attribute"]["readonly"]){ ?> readonly="<?php echo $page["start_attribute"]["readonly"]; ?>"<?php } ?>><?php } ?>
～<?php if(!isset($page["end_visible"]) || $page["end_visible"]){ ?><input<?php if(strlen($page["end_attribute"]["name"])){ ?> name="<?php echo $page["end_attribute"]["name"]; ?>"<?php } ?><?php if(strlen($page["end_attribute"]["value"])){ ?> value="<?php echo $page["end_attribute"]["value"]; ?>"<?php } ?><?php if(strlen($page["end_attribute"]["style"])){ ?> style="<?php echo $page["end_attribute"]["style"]; ?>"<?php } ?><?php if(strlen($page["end_attribute"]["onfocus"])){ ?> onfocus="<?php echo $page["end_attribute"]["onfocus"]; ?>"<?php } ?><?php if(strlen($page["end_attribute"]["onblur"])){ ?> onblur="<?php echo $page["end_attribute"]["onblur"]; ?>"<?php } ?> type="text" class="date_picker_end"<?php if($page["end_attribute"]["disabled"]){ ?> disabled="<?php echo $page["end_attribute"]["disabled"]; ?>"<?php } ?><?php if($page["end_attribute"]["readonly"]){ ?> readonly="<?php echo $page["end_attribute"]["readonly"]; ?>"<?php } ?>><?php } ?>

		<?php if(!isset($page["flag_visible"]) || $page["flag_visible"]){ ?><select<?php if(strlen($page["flag_attribute"]["name"])){ ?> name="<?php echo $page["flag_attribute"]["name"]; ?>"<?php } ?><?php if($page["flag_attribute"]["disabled"]){ ?> disabled="<?php echo $page["flag_attribute"]["disabled"]; ?>"<?php } ?><?php if($page["flag_attribute"]["readonly"]){ ?> readonly="<?php echo $page["flag_attribute"]["readonly"]; ?>"<?php } ?><?php if($page["flag_attribute"]["multiple"]){ ?> multiple="<?php echo $page["flag_attribute"]["multiple"]; ?>"<?php } ?>>状態<?php echo $page["flag"]; ?></select><?php } ?>

		<input type="submit" value="検索" />&nbsp;&nbsp;
		<a href="/app/index.php/inquiry/Inquiry">リセット</a>
	</form><?php } ?>

<?php $_panel_plugin_search_form = ob_get_contents(); ?>
<?php ob_end_clean(); ?>
<?php echo $_panel_plugin_search_form; ?></div>

<?php if(!isset($page["bulk_modify_form_visible"]) || $page["bulk_modify_form_visible"]){ ?><?php $bulk_modify_form = $page["bulk_modify_form"]; ?><form<?php if(strlen($page["bulk_modify_form_attribute"]["action"])){ ?> action="<?php echo $page["bulk_modify_form_attribute"]["action"]; ?>"<?php } ?><?php if(strlen($page["bulk_modify_form_attribute"]["method"])){ ?> method="<?php echo $page["bulk_modify_form_attribute"]["method"]; ?>"<?php } ?><?php if($page["bulk_modify_form_attribute"]["disabled"]){ ?> disabled="<?php echo $page["bulk_modify_form_attribute"]["disabled"]; ?>"<?php } ?>><input type="hidden" name="soy2_token" value="<?php echo soy2_get_token(); ?>">

	<div class="table_container">
		<table class="nowrap list" id="inquiry_list">
			<thead>
				<tr>
					<th class="checkbox">
						<input type="checkbox" id="toggle_checkbox_header" onclick="toggle_all_inquiry_check(this);show_bulk_modify_panel();" />
					</th>
					<?php if(!isset($page["form_name_th_visible"]) || $page["form_name_th_visible"]){ ?><th class="short">フォーム</th><?php } ?>

					<th class="short">受付番号</th>
					<th class="long">内容</th>	
					<th class="middle" style="width:10em;">投稿日時</th>
					<th class="short">状態</th>
				</tr>
			</thead>
			<tfoot>
				<tr id="bulk_modify_panel" style="display:none;">
					<th class="checkbox">
						<input type="checkbox" id="toggle_checkbox_footer" onclick="toggle_all_inquiry_check(this);" />
					</th>
					<?php if(!isset($page["bulk_modify_buttons_visible"]) || $page["bulk_modify_buttons_visible"]){ ?><th<?php if(strlen($page["bulk_modify_buttons_attribute"]["colspan"])){ ?> colspan="<?php echo $page["bulk_modify_buttons_attribute"]["colspan"]; ?>"<?php } ?>>
						チェックを
						<?php if(!isset($page["bulk_delete_visible"]) || $page["bulk_delete_visible"]){ ?><input<?php if(strlen($page["bulk_delete_attribute"]["name"])){ ?> name="<?php echo $page["bulk_delete_attribute"]["name"]; ?>"<?php } ?><?php if(strlen($page["bulk_delete_attribute"]["value"])){ ?> value="<?php echo $page["bulk_delete_attribute"]["value"]; ?>"<?php } ?><?php if(strlen($page["bulk_delete_attribute"]["onclick"])){ ?> onclick="<?php echo $page["bulk_delete_attribute"]["onclick"]; ?>"<?php } ?> type="submit"<?php if($page["bulk_delete_attribute"]["disabled"]){ ?> disabled="<?php echo $page["bulk_delete_attribute"]["disabled"]; ?>"<?php } ?><?php if($page["bulk_delete_attribute"]["readonly"]){ ?> readonly="<?php echo $page["bulk_delete_attribute"]["readonly"]; ?>"<?php } ?>><?php } ?>

						<?php if(!isset($page["bulk_read_visible"]) || $page["bulk_read_visible"]){ ?><input<?php if(strlen($page["bulk_read_attribute"]["name"])){ ?> name="<?php echo $page["bulk_read_attribute"]["name"]; ?>"<?php } ?><?php if(strlen($page["bulk_read_attribute"]["value"])){ ?> value="<?php echo $page["bulk_read_attribute"]["value"]; ?>"<?php } ?> type="submit"<?php if($page["bulk_read_attribute"]["disabled"]){ ?> disabled="<?php echo $page["bulk_read_attribute"]["disabled"]; ?>"<?php } ?><?php if($page["bulk_read_attribute"]["readonly"]){ ?> readonly="<?php echo $page["bulk_read_attribute"]["readonly"]; ?>"<?php } ?>><?php } ?>

						<?php if(!isset($page["bulk_new_visible"]) || $page["bulk_new_visible"]){ ?><input<?php if(strlen($page["bulk_new_attribute"]["name"])){ ?> name="<?php echo $page["bulk_new_attribute"]["name"]; ?>"<?php } ?><?php if(strlen($page["bulk_new_attribute"]["value"])){ ?> value="<?php echo $page["bulk_new_attribute"]["value"]; ?>"<?php } ?> type="submit"<?php if($page["bulk_new_attribute"]["disabled"]){ ?> disabled="<?php echo $page["bulk_new_attribute"]["disabled"]; ?>"<?php } ?><?php if($page["bulk_new_attribute"]["readonly"]){ ?> readonly="<?php echo $page["bulk_new_attribute"]["readonly"]; ?>"<?php } ?>><?php } ?>

					</th><?php } ?>

				</tr>
				<?php if(!isset($page["pager_row_visible"]) || $page["pager_row_visible"]){ ?><tr class="pager">
					<?php if(!isset($page["pager_col_visible"]) || $page["pager_col_visible"]){ ?><td<?php if(strlen($page["pager_col_attribute"]["colspan"])){ ?> colspan="<?php echo $page["pager_col_attribute"]["colspan"]; ?>"<?php } ?>>
						<div class="pager_item">
							<?php if(!isset($page["pager_select_visible"]) || $page["pager_select_visible"]){ ?><select<?php if(strlen($page["pager_select_attribute"]["name"])){ ?> name="<?php echo $page["pager_select_attribute"]["name"]; ?>"<?php } ?><?php if(strlen($page["pager_select_attribute"]["onchange"])){ ?> onchange="<?php echo $page["pager_select_attribute"]["onchange"]; ?>"<?php } ?><?php if($page["pager_select_attribute"]["disabled"]){ ?> disabled="<?php echo $page["pager_select_attribute"]["disabled"]; ?>"<?php } ?><?php if($page["pager_select_attribute"]["readonly"]){ ?> readonly="<?php echo $page["pager_select_attribute"]["readonly"]; ?>"<?php } ?><?php if($page["pager_select_attribute"]["multiple"]){ ?> multiple="<?php echo $page["pager_select_attribute"]["multiple"]; ?>"<?php } ?>><?php echo $page["pager_select"]; ?></select><?php } ?>

						</div>
						<div class="pager_item">
							<?php if(!isset($page["prev_pager_visible"]) || $page["prev_pager_visible"]){ ?><?php if(strlen($page["prev_pager_attribute"]["href"])>0){ ?><a<?php if(strlen($page["prev_pager_attribute"]["class"])){ ?> class="<?php echo $page["prev_pager_attribute"]["class"]; ?>"<?php } ?><?php if(strlen($page["prev_pager_attribute"]["href"])){ ?> href="<?php echo $page["prev_pager_attribute"]["href"]; ?>"<?php } ?>><?php } ?>&lt;<?php if(strlen($page["prev_pager_attribute"]["href"])>0){ ?></a><?php } ?><?php } ?>

							<?php if(!isset($page["pager_list_visible"]) || $page["pager_list_visible"]){ ?><?php $pager_list_counter = -1;foreach($page["pager_list"] as $key => $pager_list){ $pager_list_counter++; ?>
							<?php if(!isset($pager_list["target_link_visible"]) || $pager_list["target_link_visible"]){ ?><?php if(strlen($pager_list["target_link_attribute"]["href"])>0){ ?><a<?php if(strlen($pager_list["target_link_attribute"]["class"])){ ?> class="<?php echo $pager_list["target_link_attribute"]["class"]; ?>"<?php } ?><?php if(strlen($pager_list["target_link_attribute"]["href"])){ ?> href="<?php echo $pager_list["target_link_attribute"]["href"]; ?>"<?php } ?>><?php } ?><?php echo $pager_list["target_link"]; ?><?php if(strlen($pager_list["target_link_attribute"]["href"])>0){ ?></a><?php } ?><?php } ?>

							<?php } ?><?php } ?>

							<?php if(!isset($page["next_pager_visible"]) || $page["next_pager_visible"]){ ?><?php if(strlen($page["next_pager_attribute"]["href"])>0){ ?><a<?php if(strlen($page["next_pager_attribute"]["class"])){ ?> class="<?php echo $page["next_pager_attribute"]["class"]; ?>"<?php } ?><?php if(strlen($page["next_pager_attribute"]["href"])){ ?> href="<?php echo $page["next_pager_attribute"]["href"]; ?>"<?php } ?>><?php } ?>&gt;<?php if(strlen($page["next_pager_attribute"]["href"])>0){ ?></a><?php } ?><?php } ?>

						</div>
						<div class="pager_item">
							<?php if(!isset($page["count_start_visible"]) || $page["count_start_visible"]){ ?><span><?php echo $page["count_start"]; ?></span><?php } ?>
 - <?php if(!isset($page["count_end_visible"]) || $page["count_end_visible"]){ ?><span><?php echo $page["count_end"]; ?></span><?php } ?>
 / <?php if(!isset($page["count_max_visible"]) || $page["count_max_visible"]){ ?><span><?php echo $page["count_max"]; ?></span><?php } ?>

						</div>
					</td><?php } ?>

				</tr><?php } ?>
	
			</tfoot>
			<tbody>
				<?php if(!isset($page["inquiry_list_visible"]) || $page["inquiry_list_visible"]){ ?><?php $inquiry_list_counter = -1;foreach($page["inquiry_list"] as $key => $inquiry_list){ $inquiry_list_counter++; ?>
				<tr>
				<td class="checkbox">
					<?php if(!isset($inquiry_list["inquiry_check_visible"]) || $inquiry_list["inquiry_check_visible"]){ ?><input<?php if(strlen($inquiry_list["inquiry_check_attribute"]["type"])){ ?> type="<?php echo $inquiry_list["inquiry_check_attribute"]["type"]; ?>"<?php } ?><?php if(strlen($inquiry_list["inquiry_check_attribute"]["name"])){ ?> name="<?php echo $inquiry_list["inquiry_check_attribute"]["name"]; ?>"<?php } ?><?php if(strlen($inquiry_list["inquiry_check_attribute"]["value"])){ ?> value="<?php echo $inquiry_list["inquiry_check_attribute"]["value"]; ?>"<?php } ?> class="inquiry_check" onclick="show_bulk_modify_panel();"<?php if($inquiry_list["inquiry_check_attribute"]["disabled"]){ ?> disabled="<?php echo $inquiry_list["inquiry_check_attribute"]["disabled"]; ?>"<?php } ?><?php if($inquiry_list["inquiry_check_attribute"]["readonly"]){ ?> readonly="<?php echo $inquiry_list["inquiry_check_attribute"]["readonly"]; ?>"<?php } ?><?php if(strlen($inquiry_list["inquiry_check_attribute"]["id"])){ ?> id="<?php echo $inquiry_list["inquiry_check_attribute"]["id"]; ?>"<?php } ?><?php if($inquiry_list["inquiry_check_attribute"]["checked"]){ ?> checked="<?php echo $inquiry_list["inquiry_check_attribute"]["checked"]; ?>"<?php } ?>><?php if(strlen($inquiry_list["inquiry_check"])>0){ ?><label for="<?php echo $inquiry_list["inquiry_check_attribute"]["id"]; ?>"><?php echo $inquiry_list["inquiry_check"]; ?></label><?php } ?><?php } ?>

				</td>
				<?php if(!isset($inquiry_list["form_name_td_visible"]) || $inquiry_list["form_name_td_visible"]){ ?><td<?php if(strlen($inquiry_list["form_name_td_attribute"]["style"])){ ?> style="<?php echo $inquiry_list["form_name_td_attribute"]["style"]; ?>"<?php } ?><?php if(strlen($inquiry_list["form_name_td_attribute"]["onclick"])){ ?> onclick="<?php echo $inquiry_list["form_name_td_attribute"]["onclick"]; ?>"<?php } ?> class="short"><?php if(!isset($inquiry_list["form_name_visible"]) || $inquiry_list["form_name_visible"]){ ?><?php if(strlen($inquiry_list["form_name_attribute"]["href"])>0){ ?><a<?php if(strlen($inquiry_list["form_name_attribute"]["title"])){ ?> title="<?php echo $inquiry_list["form_name_attribute"]["title"]; ?>"<?php } ?><?php if(strlen($inquiry_list["form_name_attribute"]["href"])){ ?> href="<?php echo $inquiry_list["form_name_attribute"]["href"]; ?>"<?php } ?>><?php } ?><?php echo $inquiry_list["form_name"]; ?><?php if(strlen($inquiry_list["form_name_attribute"]["href"])>0){ ?></a><?php } ?><?php } ?>
</td><?php } ?>

				<?php if(!isset($inquiry_list["traking_number_td_visible"]) || $inquiry_list["traking_number_td_visible"]){ ?><td<?php if(strlen($inquiry_list["traking_number_td_attribute"]["onclick"])){ ?> onclick="<?php echo $inquiry_list["traking_number_td_attribute"]["onclick"]; ?>"<?php } ?><?php if(strlen($inquiry_list["traking_number_td_attribute"]["style"])){ ?> style="<?php echo $inquiry_list["traking_number_td_attribute"]["style"]; ?>"<?php } ?> class="short"><?php if(!isset($inquiry_list["traking_number_visible"]) || $inquiry_list["traking_number_visible"]){ ?><?php if(strlen($inquiry_list["traking_number_attribute"]["href"])>0){ ?><a<?php if(strlen($inquiry_list["traking_number_attribute"]["style"])){ ?> style="<?php echo $inquiry_list["traking_number_attribute"]["style"]; ?>"<?php } ?><?php if(strlen($inquiry_list["traking_number_attribute"]["href"])){ ?> href="<?php echo $inquiry_list["traking_number_attribute"]["href"]; ?>"<?php } ?>><?php } ?><?php echo $inquiry_list["traking_number"]; ?><?php if(strlen($inquiry_list["traking_number_attribute"]["href"])>0){ ?></a><?php } ?><?php } ?>
</td><?php } ?>

				<?php if(!isset($inquiry_list["content_visible"]) || $inquiry_list["content_visible"]){ ?><td<?php if(strlen($inquiry_list["content_attribute"]["style"])){ ?> style="<?php echo $inquiry_list["content_attribute"]["style"]; ?>"<?php } ?><?php if(strlen($inquiry_list["content_attribute"]["title"])){ ?> title="<?php echo $inquiry_list["content_attribute"]["title"]; ?>"<?php } ?><?php if(strlen($inquiry_list["content_attribute"]["onclick"])){ ?> onclick="<?php echo $inquiry_list["content_attribute"]["onclick"]; ?>"<?php } ?> class="long"><?php echo $inquiry_list["content"]; ?></td><?php } ?>

				<?php if(!isset($inquiry_list["create_date_td_visible"]) || $inquiry_list["create_date_td_visible"]){ ?><td<?php if(strlen($inquiry_list["create_date_td_attribute"]["onclick"])){ ?> onclick="<?php echo $inquiry_list["create_date_td_attribute"]["onclick"]; ?>"<?php } ?><?php if(strlen($inquiry_list["create_date_td_attribute"]["style"])){ ?> style="<?php echo $inquiry_list["create_date_td_attribute"]["style"]; ?>"<?php } ?> class="middle"><nobr><?php if(!isset($inquiry_list["create_date_visible"]) || $inquiry_list["create_date_visible"]){ ?><span<?php if(strlen($inquiry_list["create_date_attribute"]["style"])){ ?> style="<?php echo $inquiry_list["create_date_attribute"]["style"]; ?>"<?php } ?><?php if(strlen($inquiry_list["create_date_attribute"]["onclick"])){ ?> onclick="<?php echo $inquiry_list["create_date_attribute"]["onclick"]; ?>"<?php } ?>><?php echo $inquiry_list["create_date"]; ?></span><?php } ?>
</nobr></td><?php } ?>

				<?php if(!isset($inquiry_list["flag_td_visible"]) || $inquiry_list["flag_td_visible"]){ ?><td<?php if(strlen($inquiry_list["flag_td_attribute"]["onclick"])){ ?> onclick="<?php echo $inquiry_list["flag_td_attribute"]["onclick"]; ?>"<?php } ?><?php if(strlen($inquiry_list["flag_td_attribute"]["style"])){ ?> style="<?php echo $inquiry_list["flag_td_attribute"]["style"]; ?>"<?php } ?> class="short"><?php if(!isset($inquiry_list["flag_visible"]) || $inquiry_list["flag_visible"]){ ?><?php if(strlen($inquiry_list["flag_attribute"]["href"])>0){ ?><a<?php if(strlen($inquiry_list["flag_attribute"]["style"])){ ?> style="<?php echo $inquiry_list["flag_attribute"]["style"]; ?>"<?php } ?><?php if(strlen($inquiry_list["flag_attribute"]["href"])){ ?> href="<?php echo $inquiry_list["flag_attribute"]["href"]; ?>"<?php } ?>><?php } ?><?php echo $inquiry_list["flag"]; ?><?php if(strlen($inquiry_list["flag_attribute"]["href"])>0){ ?></a><?php } ?><?php } ?>
</td><?php } ?>

				</tr>
				<?php } ?><?php } ?>

				
				<?php if(!isset($page["no_inquiry_visible"]) || $page["no_inquiry_visible"]){ ?>
				<tr>
				<?php if(!isset($page["no_inquiry_text_visible"]) || $page["no_inquiry_text_visible"]){ ?><td<?php if(strlen($page["no_inquiry_text_attribute"]["colspan"])){ ?> colspan="<?php echo $page["no_inquiry_text_attribute"]["colspan"]; ?>"<?php } ?>>
					新着の問い合わせはありません。
				</td><?php } ?>

				</tr>
				<?php } ?>

			</tbody>
		</table>
	</div>

</form><?php } ?>


</div>

<script type="text/javascript">
	function toggle_all_inquiry_check(checkbox){
		$(".inquiry_check").each(function(){
			$(this).prop("checked",!$(this).prop("checked"));
		});
		if($(checkbox).attr("id") != "toggle_checkbox_header") $("#toggle_checkbox_header").prop("checked",$(checkbox).prop("checked"));
		if($(checkbox).attr("id") != "toggle_checkbox_footer") $("#toggle_checkbox_footer").prop("checked",$(checkbox).prop("checked"));
	}
	function show_bulk_modify_panel(){
		$("#bulk_modify_panel").show();											
	}
</script>

