<?php /* created 2022-11-05 09:16:30 */ ?>
<?php $page = HTMLPage::getPage(); ?>
<div class="functions">
	<div class="function">
		<a href="/app/index.php/inquiry/Form/Create">フォームの作成</a>
	</div>
	
	<div class="function">	
		<a href="/app/index.php/inquiry/Form/Copy">フォームの複製</a>
	</div>
	
	<br style="clear:both;" />
</div>

<div style="padding:0px 20px;">

<h1>フォーム</h1>

	<div class="table_container">
		<table class="nowrap list">
			<thead>
				<tr>
					<th class="short">ID</th>
					<th class="middle">名前</th>
					<th class="short">件数 (未読)</th>	
					<th class="long"></th>
				</tr>
			</thead>
			<tbody>
				<?php if(!isset($page["form_list_visible"]) || $page["form_list_visible"]){ ?><?php $form_list_counter = -1;foreach($page["form_list"] as $key => $form_list){ $form_list_counter++; ?>
				<tr>
					<?php if(!isset($form_list["formId_visible"]) || $form_list["formId_visible"]){ ?><td><?php echo $form_list["formId"]; ?></td><?php } ?>

					<?php if(!isset($form_list["name_visible"]) || $form_list["name_visible"]){ ?><td><?php echo $form_list["name"]; ?></td><?php } ?>

					<td><?php if(!isset($form_list["inquiry_link_visible"]) || $form_list["inquiry_link_visible"]){ ?><?php if(strlen($form_list["inquiry_link_attribute"]["href"])>0){ ?><a<?php if(strlen($form_list["inquiry_link_attribute"]["href"])){ ?> href="<?php echo $form_list["inquiry_link_attribute"]["href"]; ?>"<?php } ?>><?php } ?><?php echo $form_list["inquiry_link"]; ?><?php if(strlen($form_list["inquiry_link_attribute"]["href"])>0){ ?></a><?php } ?><?php } ?>
 <?php if(!isset($form_list["unread_inquiry_link_visible"]) || $form_list["unread_inquiry_link_visible"]){ ?><?php if(strlen($form_list["unread_inquiry_link_attribute"]["href"])>0){ ?><a<?php if(strlen($form_list["unread_inquiry_link_attribute"]["style"])){ ?> style="<?php echo $form_list["unread_inquiry_link_attribute"]["style"]; ?>"<?php } ?><?php if(strlen($form_list["unread_inquiry_link_attribute"]["href"])){ ?> href="<?php echo $form_list["unread_inquiry_link_attribute"]["href"]; ?>"<?php } ?>><?php } ?><?php echo $form_list["unread_inquiry_link"]; ?><?php if(strlen($form_list["unread_inquiry_link_attribute"]["href"])>0){ ?></a><?php } ?><?php } ?>
</td>	
					<td>
						<?php if(!isset($form_list["design_link_visible"]) || $form_list["design_link_visible"]){ ?><?php if(strlen($form_list["design_link_attribute"]["href"])>0){ ?><a<?php if(strlen($form_list["design_link_attribute"]["href"])){ ?> href="<?php echo $form_list["design_link_attribute"]["href"]; ?>"<?php } ?>><?php } ?>問い合わせ項目<?php if(strlen($form_list["design_link_attribute"]["href"])>0){ ?></a><?php } ?><?php } ?>
&nbsp;&nbsp;<?php if(!isset($form_list["config_link_visible"]) || $form_list["config_link_visible"]){ ?><?php if(strlen($form_list["config_link_attribute"]["href"])>0){ ?><a<?php if(strlen($form_list["config_link_attribute"]["href"])){ ?> href="<?php echo $form_list["config_link_attribute"]["href"]; ?>"<?php } ?>><?php } ?>設定<?php if(strlen($form_list["config_link_attribute"]["href"])>0){ ?></a><?php } ?><?php } ?>
&nbsp;&nbsp;<?php if(!isset($form_list["template_link_visible"]) || $form_list["template_link_visible"]){ ?><?php if(strlen($form_list["template_link_attribute"]["href"])>0){ ?><a<?php if(strlen($form_list["template_link_attribute"]["href"])){ ?> href="<?php echo $form_list["template_link_attribute"]["href"]; ?>"<?php } ?>><?php } ?>SOY CMS連携<?php if(strlen($form_list["template_link_attribute"]["href"])>0){ ?></a><?php } ?><?php } ?>
&nbsp;&nbsp;<?php if(!isset($form_list["delete_link_visible"]) || $form_list["delete_link_visible"]){ ?><?php if(strlen($form_list["delete_link_attribute"]["href"])>0){ ?><a<?php if(strlen($form_list["delete_link_attribute"]["onclick"])){ ?> onclick="<?php echo $form_list["delete_link_attribute"]["onclick"]; ?>"<?php } ?><?php if(strlen($form_list["delete_link_attribute"]["href"])){ ?> href="<?php echo $form_list["delete_link_attribute"]["href"]; ?>"<?php } ?>><?php } ?>削除<?php if(strlen($form_list["delete_link_attribute"]["href"])>0){ ?></a><?php } ?><?php } ?>

					</td>
				</tr>
				<?php } ?><?php } ?>

			</tbody>
		</table>
	</div>

</div>