<?php /* created 2022-11-05 09:17:16 */ ?>
<?php $page = HTMLPage::getPage(); ?>
<div class="functions">
	<div class="function">
		<a href="/app/index.php/inquiry/Form">戻る</a>
	</div>

	<div class="function">
		<?php if(!isset($page["config_link_visible"]) || $page["config_link_visible"]){ ?><?php if(strlen($page["config_link_attribute"]["href"])>0){ ?><a<?php if(strlen($page["config_link_attribute"]["href"])){ ?> href="<?php echo $page["config_link_attribute"]["href"]; ?>"<?php } ?>><?php } ?>設定<?php if(strlen($page["config_link_attribute"]["href"])>0){ ?></a><?php } ?><?php } ?>

	</div>

	<div class="function">
		<?php if(!isset($page["preview_link_visible"]) || $page["preview_link_visible"]){ ?><?php if(strlen($page["preview_link_attribute"]["href"])>0){ ?><a<?php if(strlen($page["preview_link_attribute"]["onclick"])){ ?> onclick="<?php echo $page["preview_link_attribute"]["onclick"]; ?>"<?php } ?><?php if(strlen($page["preview_link_attribute"]["href"])){ ?> href="<?php echo $page["preview_link_attribute"]["href"]; ?>"<?php } ?>><?php } ?>プレビュー<?php if(strlen($page["preview_link_attribute"]["href"])>0){ ?></a><?php } ?><?php } ?>

	</div>

	<div class="function">
		<?php if(!isset($page["template_link_visible"]) || $page["template_link_visible"]){ ?><?php if(strlen($page["template_link_attribute"]["href"])>0){ ?><a<?php if(strlen($page["template_link_attribute"]["href"])){ ?> href="<?php echo $page["template_link_attribute"]["href"]; ?>"<?php } ?>><?php } ?>SOY CMS連携<?php if(strlen($page["template_link_attribute"]["href"])>0){ ?></a><?php } ?><?php } ?>

	</div>

	<br style="clear:both;" />
</div>

<div style="padding:0px 20px;">

<h1><?php if(!isset($page["form_name_visible"]) || $page["form_name_visible"]){ ?><span><?php echo $page["form_name"]; ?></span><?php } ?>
 - 問い合わせ項目の編集</h1>

	<div style="border:1px solid lightgrey; border-bottom:none;padding:8px 20px 0px;">
		<?php if(!isset($page["add_column_link_visible"]) || $page["add_column_link_visible"]){ ?><?php if(strlen($page["add_column_link_attribute"]["href"])>0){ ?><a onclick="return show_form(this);" style="margin-right:10px;"<?php if(strlen($page["add_column_link_attribute"]["href"])){ ?> href="<?php echo $page["add_column_link_attribute"]["href"]; ?>"<?php } ?>><?php } ?>項目を追加する<?php if(strlen($page["add_column_link_attribute"]["href"])>0){ ?></a><?php } ?><?php } ?>

		<?php if(!isset($page["change_order_link_visible"]) || $page["change_order_link_visible"]){ ?><?php if(strlen($page["change_order_link_attribute"]["href"])>0){ ?><a onclick="return show_form(this);"<?php if(strlen($page["change_order_link_attribute"]["href"])){ ?> href="<?php echo $page["change_order_link_attribute"]["href"]; ?>"<?php } ?>><?php } ?>順番を変更する<?php if(strlen($page["change_order_link_attribute"]["href"])>0){ ?></a><?php } ?><?php } ?>

	</div>
	<div style="border:1px solid lightgrey; border-top:none;">
		<?php if(!isset($page["column_fr_visible"]) || $page["column_fr_visible"]){ ?><iframe<?php if(strlen($page["column_fr_attribute"]["src"])){ ?> src="<?php echo $page["column_fr_attribute"]["src"]; ?>"<?php } ?> id="column_fr" name="column_fr" style="width:100%;height:600px;" frameborder="0"></iframe><?php } ?>

	</div>

	<iframe id="target_fr" name="target_fr" style="width:0;height:0;visibility:hidden;"></iframe>

</div>

<script type="text/javascript">
var add_win = null;
function show_form(ele){
	if(add_win)add_win.close();
	
	add_win = new soycms.UI.TargetWindow(ele,{
		width : 640,
		height: 480
	});

	return false;
}
function reloadColumnPage(){
	window.column_fr.location.reload();
	if(add_win){
		add_win.close();
		add_win = null;
	}
}
</script>