<?php /* created 2022-11-05 09:17:32 */ ?>
<?php $page = HTMLPage::getPage(); ?>
<div class="functions">
	<div class="function">
		<a href="/app/index.php/inquiry/Form">戻る</a>
	</div>
	
	<div class="function">
		<?php if(!isset($page["design_link_visible"]) || $page["design_link_visible"]){ ?><?php if(strlen($page["design_link_attribute"]["href"])>0){ ?><a<?php if(strlen($page["design_link_attribute"]["href"])){ ?> href="<?php echo $page["design_link_attribute"]["href"]; ?>"<?php } ?>><?php } ?>問い合わせ項目<?php if(strlen($page["design_link_attribute"]["href"])>0){ ?></a><?php } ?><?php } ?>

	</div>

	<div class="function">
		<?php if(!isset($page["preview_link_visible"]) || $page["preview_link_visible"]){ ?><?php if(strlen($page["preview_link_attribute"]["href"])>0){ ?><a<?php if(strlen($page["preview_link_attribute"]["onclick"])){ ?> onclick="<?php echo $page["preview_link_attribute"]["onclick"]; ?>"<?php } ?><?php if(strlen($page["preview_link_attribute"]["href"])){ ?> href="<?php echo $page["preview_link_attribute"]["href"]; ?>"<?php } ?>><?php } ?>プレビュー<?php if(strlen($page["preview_link_attribute"]["href"])>0){ ?></a><?php } ?><?php } ?>

	</div>
	
	<div class="function">
		<?php if(!isset($page["config_link_visible"]) || $page["config_link_visible"]){ ?><?php if(strlen($page["config_link_attribute"]["href"])>0){ ?><a<?php if(strlen($page["config_link_attribute"]["href"])){ ?> href="<?php echo $page["config_link_attribute"]["href"]; ?>"<?php } ?>><?php } ?>設定<?php if(strlen($page["config_link_attribute"]["href"])>0){ ?></a><?php } ?><?php } ?>

	</div>
	
	<br style="clear:both;" />
</div>

<div style="padding:0px 20px;">

<h1>SOY CMSとの連携 - <?php if(!isset($page["form_name_visible"]) || $page["form_name_visible"]){ ?><span><?php echo $page["form_name"]; ?></span><?php } ?>
</h1>

<a name="config_form"></a>
<h2>問い合わせフォームを表示する</h2>
<p style="margin-top:2em;margin-bottom:1ex;">アプリケーションページのテンプレートに以下のように記述してください。</p>
<?php if(!isset($page["template_visible"]) || $page["template_visible"]){ ?><textarea<?php if(strlen($page["template_attribute"]["onclick"])){ ?> onclick="<?php echo $page["template_attribute"]["onclick"]; ?>"<?php } ?> style="height:4em;width:90%;"><?php echo $page["template"]; ?></textarea><?php } ?>


<p style="margin-top:1em;margin-bottom:1ex;">※SOY CMS 1.3.3から<strong>標準ページでもSOY Appを呼び出せるようになりました</strong>。<br>
標準ページなどでSOY Inquiryを呼び出すには以下のように記述してください。<br>
一行目の記述によりSOYAppページでSOY Inquiryを指定したのと同じ状態になります。
</p>
<?php if(!isset($page["template2_visible"]) || $page["template2_visible"]){ ?><textarea<?php if(strlen($page["template2_attribute"]["onclick"])){ ?> onclick="<?php echo $page["template2_attribute"]["onclick"]; ?>"<?php } ?> style="height:6em;width:90%;"><?php echo $page["template2"]; ?></textarea><?php } ?>





</div>