<?php if(!class_exists('SOYInquiry_Inquiry')){ 
include_once("/var/www/html/app/webapp/inquiry/src/domain/SOYInquiry_Inquiry.class.php"); 
} 
?><?php $updateDate = max(filemtime("/var/www/html/app/webapp/inquiry/src/domain/SOYInquiry_InquiryDAO.class.php"),filemtime("/var/www/html/app/webapp/inquiry/src/domain/SOYInquiry_Inquiry.class.php"));if($updateDate  < filemtime(__FILE__)){ ?><?php
class SOYInquiry_InquiryDAOImpl extends SOYInquiry_InquiryDAO{
var $_entity = "O:14:\"SOY2DAO_Entity\":5:{s:4:\"name\";s:18:\"SOYInquiry_Inquiry\";s:5:\"table\";s:18:\"soyinquiry_inquiry\";s:2:\"id\";b:0;s:7:\"columns\";a:8:{s:2:\"id\";O:20:\"SOY2DAO_EntityColumn\":7:{s:2:\"id\";N;s:4:\"name\";s:2:\"id\";s:5:\"alias\";N;s:4:\"prop\";s:2:\"id\";s:9:\"isPrimary\";b:1;s:8:\"readOnly\";b:0;s:8:\"sequence\";N;}s:14:\"trackingnumber\";O:20:\"SOY2DAO_EntityColumn\":7:{s:2:\"id\";N;s:4:\"name\";s:15:\"tracking_number\";s:5:\"alias\";N;s:4:\"prop\";s:14:\"trackingNumber\";s:9:\"isPrimary\";N;s:8:\"readOnly\";b:0;s:8:\"sequence\";N;}s:6:\"formid\";O:20:\"SOY2DAO_EntityColumn\":7:{s:2:\"id\";N;s:4:\"name\";s:7:\"form_id\";s:5:\"alias\";N;s:4:\"prop\";s:6:\"formId\";s:9:\"isPrimary\";N;s:8:\"readOnly\";b:0;s:8:\"sequence\";N;}s:7:\"content\";O:20:\"SOY2DAO_EntityColumn\":7:{s:2:\"id\";N;s:4:\"name\";s:7:\"content\";s:5:\"alias\";N;s:4:\"prop\";s:7:\"content\";s:9:\"isPrimary\";N;s:8:\"readOnly\";b:0;s:8:\"sequence\";N;}s:4:\"data\";O:20:\"SOY2DAO_EntityColumn\":7:{s:2:\"id\";N;s:4:\"name\";s:4:\"data\";s:5:\"alias\";N;s:4:\"prop\";s:4:\"data\";s:9:\"isPrimary\";N;s:8:\"readOnly\";b:0;s:8:\"sequence\";N;}s:4:\"flag\";O:20:\"SOY2DAO_EntityColumn\":7:{s:2:\"id\";N;s:4:\"name\";s:4:\"flag\";s:5:\"alias\";N;s:4:\"prop\";s:4:\"flag\";s:9:\"isPrimary\";N;s:8:\"readOnly\";b:0;s:8:\"sequence\";N;}s:10:\"createdate\";O:20:\"SOY2DAO_EntityColumn\":7:{s:2:\"id\";N;s:4:\"name\";s:11:\"create_date\";s:5:\"alias\";N;s:4:\"prop\";s:10:\"createDate\";s:9:\"isPrimary\";N;s:8:\"readOnly\";b:0;s:8:\"sequence\";N;}s:7:\"formurl\";O:20:\"SOY2DAO_EntityColumn\":7:{s:2:\"id\";N;s:4:\"name\";s:8:\"form_url\";s:5:\"alias\";N;s:4:\"prop\";s:7:\"formUrl\";s:9:\"isPrimary\";N;s:8:\"readOnly\";b:0;s:8:\"sequence\";N;}}s:14:\"reverseColumns\";a:8:{s:2:\"id\";s:2:\"id\";s:15:\"tracking_number\";s:14:\"trackingnumber\";s:7:\"form_id\";s:6:\"formid\";s:7:\"content\";s:7:\"content\";s:4:\"data\";s:4:\"data\";s:4:\"flag\";s:4:\"flag\";s:11:\"create_date\";s:10:\"createdate\";s:8:\"form_url\";s:7:\"formurl\";}}";
function insert(SOYInquiry_Inquiry $bean){
$this->setMethod("insert");
$query = $this->buildQuery($this->_method,unserialize('a:0:{}'),unserialize('a:0:{}'),"");
if($query instanceof SOY2DAO_Query){ $query->parseExpression(array("bean" => $bean)); }
$this->buildBinds($query,array("bean" => $bean));
$query = $this->getQuery();
$binds = $this->getBinds();
$result = $this->executeUpdateQuery($query,$binds);
return $this->lastInsertId();
}
function update(SOYInquiry_Inquiry $bean){
$this->setMethod("update");
$query = $this->buildQuery($this->_method,unserialize('a:0:{}'),unserialize('a:0:{}'),"");
if($query instanceof SOY2DAO_Query){ $query->parseExpression(array("bean" => $bean)); }
$this->buildBinds($query,array("bean" => $bean));
$query = $this->getQuery();
$binds = $this->getBinds();
$result = $this->executeUpdateQuery($query,$binds);
$array = array();
if(is_array($result)){
foreach($result as $row){
$array[] = $this->getObject($row);
}
}
return $array;
}

function updateFlagById($id,$flag){
$this->setMethod("updateFlagById");
$query = $this->buildQuery($this->_method,unserialize('a:0:{}'),unserialize('a:2:{i:0;s:2:"id";i:1;s:4:"flag";}'),"");
if($query instanceof SOY2DAO_Query){ $query->parseExpression(array("id" => $id,"flag" => $flag)); }
$this->buildBinds($query,array("id" => $id,"flag" => $flag));
$query = $this->getQuery();
$binds = $this->getBinds();
$result = $this->executeUpdateQuery($query,$binds);
$array = array();
if(is_array($result)){
foreach($result as $row){
$array[] = $this->getObject($row);
}
}
return $array;
}
function get(){
$this->setMethod("get");
$query = $this->buildQuery($this->_method,unserialize('a:0:{}'),unserialize('a:0:{}'),"");
if($query instanceof SOY2DAO_Query){ $query->parseExpression(array()); }
$this->buildBinds($query,array());
$query = $this->getQuery();
$binds = $this->getBinds();
$result = $this->executeQuery($query,$binds);
$array = array();
if(is_array($result)){
foreach($result as $row){
$array[] = $this->getObject($row);
}
}
return $array;
}
function getByFormId($formId){
$this->setMethod("getByFormId");
$query = $this->buildQuery($this->_method,unserialize('a:0:{}'),unserialize('a:0:{}'),"");
if($query instanceof SOY2DAO_Query){ $query->parseExpression(array("formId" => $formId)); }
$this->buildBinds($query,array("formId" => $formId));
$query = $this->getQuery();
$binds = $this->getBinds();
$result = $this->executeQuery($query,$binds);
$array = array();
if(is_array($result)){
foreach($result as $row){
$array[] = $this->getObject($row);
}
}
return $array;
}
function getByTrackingNumber($trackingNumber){
$this->setMethod("getByTrackingNumber");
$query = $this->buildQuery($this->_method,unserialize('a:0:{}'),unserialize('a:0:{}'),"");
if($query instanceof SOY2DAO_Query){ $query->parseExpression(array("trackingNumber" => $trackingNumber)); }
$this->buildBinds($query,array("trackingNumber" => $trackingNumber));
$query = $this->getQuery();
$binds = $this->getBinds();
$oldLimit = $this->_limit;
$this->setLimit(1);
$oldOffset = $this->_offset;
$this->setOffset(0);
$result = $this->executeQuery($query,$binds);
$this->setLimit($oldLimit);
$this->setOffset($oldOffset);
if(count($result)<1)throw new SOY2DAOException("[SOY2DAO]Failed to return Object.");
$obj = $this->getObject($result[0]);
return $obj;
}
function search($formId,$start,$end,$trackId,$flag){
$this->setMethod("search");
$query = $this->buildQuery($this->_method,unserialize('a:0:{}'),unserialize('a:0:{}'),"");
$query->order = "create_date desc";
if($query instanceof SOY2DAO_Query){ $query->parseExpression(array("formId" => $formId,"start" => $start,"end" => $end,"trackId" => $trackId,"flag" => $flag)); }
$this->buildBinds($query,array("formId" => $formId,"start" => $start,"end" => $end,"trackId" => $trackId,"flag" => $flag));
return parent::search($formId,$start,$end,$trackId,$flag);
}
function getById($id){
$this->setMethod("getById");
$query = $this->buildQuery($this->_method,unserialize('a:0:{}'),unserialize('a:0:{}'),"");
if($query instanceof SOY2DAO_Query){ $query->parseExpression(array("id" => $id)); }
$this->buildBinds($query,array("id" => $id));
$query = $this->getQuery();
$binds = $this->getBinds();
$oldLimit = $this->_limit;
$this->setLimit(1);
$oldOffset = $this->_offset;
$this->setOffset(0);
$result = $this->executeQuery($query,$binds);
$this->setLimit($oldLimit);
$this->setOffset($oldOffset);
if(count($result)<1)throw new SOY2DAOException("[SOY2DAO]Failed to return Object.");
$obj = $this->getObject($result[0]);
return $obj;
}
function delete($id){
$this->setMethod("delete");
$query = $this->buildQuery($this->_method,unserialize('a:0:{}'),unserialize('a:0:{}'),"");
if($query instanceof SOY2DAO_Query){ $query->parseExpression(array("id" => $id)); }
$this->buildBinds($query,array("id" => $id));
$query = $this->getQuery();
$binds = $this->getBinds();
$result = $this->executeUpdateQuery($query,$binds);
$array = array();
if(is_array($result)){
foreach($result as $row){
$array[] = $this->getObject($row);
}
}
return $array;
}
function deleteByFormId($formId){
$this->setMethod("deleteByFormId");
$query = $this->buildQuery($this->_method,unserialize('a:0:{}'),unserialize('a:0:{}'),"");
if($query instanceof SOY2DAO_Query){ $query->parseExpression(array("formId" => $formId)); }
$this->buildBinds($query,array("formId" => $formId));
$query = $this->getQuery();
$binds = $this->getBinds();
$result = $this->executeUpdateQuery($query,$binds);
$array = array();
if(is_array($result)){
foreach($result as $row){
$array[] = $this->getObject($row);
}
}
return $array;
}
function countUnreadInquiryByFormId($formId){
$this->setMethod("countUnreadInquiryByFormId");
$query = $this->buildQuery($this->_method,unserialize('a:0:{}'),unserialize('a:1:{i:0;s:16:"count(id) as cnt";}'),"");
$query->where = "form_id = :formId and flag = 0";
if($query instanceof SOY2DAO_Query){ $query->parseExpression(array("formId" => $formId)); }
$this->buildBinds($query,array("formId" => $formId));
$query = $this->getQuery();
$binds = $this->getBinds();
$oldLimit = $this->_limit;
$this->setLimit(1);
$oldOffset = $this->_offset;
$this->setOffset(0);
$result = $this->executeQuery($query,$binds);
$this->setLimit($oldLimit);
$this->setOffset($oldOffset);
if(count($result)<1)throw new SOY2DAOException("[SOY2DAO]Failed to return column.");
$row = $result[0];
return $row["cnt"];
}
function countInquiryByFormIdByFlag($formId,$flag){
$this->setMethod("countInquiryByFormIdByFlag");
$query = $this->buildQuery($this->_method,unserialize('a:0:{}'),unserialize('a:1:{i:0;s:16:"count(id) as cnt";}'),"");
$query->where = "form_id = :formId and flag = :flag";
if($query instanceof SOY2DAO_Query){ $query->parseExpression(array("formId" => $formId,"flag" => $flag)); }
$this->buildBinds($query,array("formId" => $formId,"flag" => $flag));
$query = $this->getQuery();
$binds = $this->getBinds();
$oldLimit = $this->_limit;
$this->setLimit(1);
$oldOffset = $this->_offset;
$this->setOffset(0);
$result = $this->executeQuery($query,$binds);
$this->setLimit($oldLimit);
$this->setOffset($oldOffset);
if(count($result)<1)throw new SOY2DAOException("[SOY2DAO]Failed to return column.");
$row = $result[0];
return $row["cnt"];
}
function countUndeletedInquiryByFormId($formId){
$this->setMethod("countUndeletedInquiryByFormId");
$query = $this->buildQuery($this->_method,unserialize('a:0:{}'),unserialize('a:1:{i:0;s:16:"count(id) as cnt";}'),"");
$query->where = "form_id = :formId and flag <> 2";
if($query instanceof SOY2DAO_Query){ $query->parseExpression(array("formId" => $formId)); }
$this->buildBinds($query,array("formId" => $formId));
$query = $this->getQuery();
$binds = $this->getBinds();
$oldLimit = $this->_limit;
$this->setLimit(1);
$oldOffset = $this->_offset;
$this->setOffset(0);
$result = $this->executeQuery($query,$binds);
$this->setLimit($oldLimit);
$this->setOffset($oldOffset);
if(count($result)<1)throw new SOY2DAOException("[SOY2DAO]Failed to return column.");
$row = $result[0];
return $row["cnt"];
}}?><?php
 } 
?>