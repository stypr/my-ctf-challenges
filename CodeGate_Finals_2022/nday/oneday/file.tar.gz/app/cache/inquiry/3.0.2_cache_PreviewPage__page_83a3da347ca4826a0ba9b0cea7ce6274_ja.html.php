<?php /* created 2022-11-05 09:33:37 */ ?>
<?php $page = HTMLPage::getPage(); ?>
<style type="text/css">
table{
	border-collapse:collapse;
	border-spacing:0;
}
td,th{
	border:solid 1px #777777;
}
</style>
<div class="container" style="width:80%;">
<?php if(!isset($page["preview_visible"]) || $page["preview_visible"]){ ?><?php echo $page["preview"]; ?><?php } ?>

</div>