<?php /* created 2022-11-05 09:17:16 */ ?>
<?php $page = HTMLPage::getPage(); ?>
<style type="text/css">
.column_box{
	border:solid 1px black;
	margin-bottom:8px;
}
.column_box table{
	width:100%;
	height:100%;
	border-collapse:collapse;
	margin:0;
}
#require_cell_title, .require_cell{
	width:30px;border-right:solid 1px gray;text-align:center;vertical-align:middle;
}
#item_name_title{
	width:10em;border-right:solid 1px gray;text-align:center;vertical-align:middle;
}
.require_cell{
	cursor:pointer;
}
td.operation{
	width:80px;background-color:#CCFFCC;
}
td.configure{
	border-top:solid 1px gray;
}
body{
	background-image: none;
}
.column_box input{
	display:inline;
	vertical-align:middle;
}
.column_box input[type="text"]{
	border:solid 1px #666;
	margin-right:3px;
	margin-left:3px;
}
.column_hash{
	display:none;
}
</style>

<div style="padding:0px 20px;margin-top:10px;">

	<div class="column_box">
		<table>
		<tr>
			<th id="require_cell_title">必須</th>
			<th id="item_name_title" style="width:10em;">項目名</th>
			<th>名前</th>
			<th style="width:10em;border-left:solid 1px #bbb;">SOY Mail連携</th>
			<th style="width:10em;border-left:solid 1px #bbb;">SOY Shop連携</th>
		</tr>

		</table>
	</div>

	<?php if(!isset($page["column_list_visible"]) || $page["column_list_visible"]){ ?><?php $column_list_counter = -1;foreach($page["column_list"] as $key => $column_list){ $column_list_counter++; ?>
	<?php if(!isset($column_list["column_form_visible"]) || $column_list["column_form_visible"]){ ?><?php $column_form = $column_list["column_form"]; ?><form<?php if(strlen($column_list["column_form_attribute"]["action"])){ ?> action="<?php echo $column_list["column_form_attribute"]["action"]; ?>"<?php } ?><?php if(strlen($column_list["column_form_attribute"]["method"])){ ?> method="<?php echo $column_list["column_form_attribute"]["method"]; ?>"<?php } ?><?php if($column_list["column_form_attribute"]["disabled"]){ ?> disabled="<?php echo $column_list["column_form_attribute"]["disabled"]; ?>"<?php } ?>><input type="hidden" name="soy2_token" value="<?php echo soy2_get_token(); ?>">
	<div class="column_box">
		<?php if(!isset($column_list["column_hash_visible"]) || $column_list["column_hash_visible"]){ ?><a<?php if(strlen($column_list["column_hash_attribute"]["name"])){ ?> name="<?php echo $column_list["column_hash_attribute"]["name"]; ?>"<?php } ?> class="column_hash"><?php echo $column_list["column_hash"]; ?></a><?php } ?>

		<table>
			<tr>
				<?php if(!isset($column_list["require_cell_visible"]) || $column_list["require_cell_visible"]){ ?><td<?php if(strlen($column_list["require_cell_attribute"]["onclick"])){ ?> onclick="<?php echo $column_list["require_cell_attribute"]["onclick"]; ?>"<?php } ?><?php if(strlen($column_list["require_cell_attribute"]["style"])){ ?> style="<?php echo $column_list["require_cell_attribute"]["style"]; ?>"<?php } ?><?php if(strlen($column_list["require_cell_attribute"]["checkcolor"])){ ?> checkcolor="<?php echo $column_list["require_cell_attribute"]["checkcolor"]; ?>"<?php } ?> rowspan="2" class="require_cell">
					<?php if(!isset($column_list["not_require_visible"]) || $column_list["not_require_visible"]){ ?><input<?php if(strlen($column_list["not_require_attribute"]["type"])){ ?> type="<?php echo $column_list["not_require_attribute"]["type"]; ?>"<?php } ?><?php if(strlen($column_list["not_require_attribute"]["name"])){ ?> name="<?php echo $column_list["not_require_attribute"]["name"]; ?>"<?php } ?><?php if(strlen($column_list["not_require_attribute"]["value"])){ ?> value="<?php echo $column_list["not_require_attribute"]["value"]; ?>"<?php } ?><?php if($column_list["not_require_attribute"]["disabled"]){ ?> disabled="<?php echo $column_list["not_require_attribute"]["disabled"]; ?>"<?php } ?><?php if($column_list["not_require_attribute"]["readonly"]){ ?> readonly="<?php echo $column_list["not_require_attribute"]["readonly"]; ?>"<?php } ?>><?php } ?>

					<?php if(!isset($column_list["require_visible"]) || $column_list["require_visible"]){ ?><input<?php if(strlen($column_list["require_attribute"]["name"])){ ?> name="<?php echo $column_list["require_attribute"]["name"]; ?>"<?php } ?><?php if(strlen($column_list["require_attribute"]["value"])){ ?> value="<?php echo $column_list["require_attribute"]["value"]; ?>"<?php } ?><?php if(strlen($column_list["require_attribute"]["onmouseup"])){ ?> onmouseup="<?php echo $column_list["require_attribute"]["onmouseup"]; ?>"<?php } ?> type="checkbox"<?php if($column_list["require_attribute"]["disabled"]){ ?> disabled="<?php echo $column_list["require_attribute"]["disabled"]; ?>"<?php } ?><?php if($column_list["require_attribute"]["readonly"]){ ?> readonly="<?php echo $column_list["require_attribute"]["readonly"]; ?>"<?php } ?><?php if(strlen($column_list["require_attribute"]["id"])){ ?> id="<?php echo $column_list["require_attribute"]["id"]; ?>"<?php } ?><?php if($column_list["require_attribute"]["checked"]){ ?> checked="<?php echo $column_list["require_attribute"]["checked"]; ?>"<?php } ?>><?php if(strlen($column_list["require"])>0){ ?><label for="<?php echo $column_list["require_attribute"]["id"]; ?>"><?php echo $column_list["require"]; ?></label><?php } ?><?php } ?>

				</td><?php } ?>

				<td style="width:10em;border-right:solid 1px #bbb;">
					<?php if(!isset($column_list["column_type_visible"]) || $column_list["column_type_visible"]){ ?><span><?php echo $column_list["column_type"]; ?></span><?php } ?>

				</td>
				<td>
					<?php if(!isset($column_list["label_visible"]) || $column_list["label_visible"]){ ?><input<?php if(strlen($column_list["label_attribute"]["name"])){ ?> name="<?php echo $column_list["label_attribute"]["name"]; ?>"<?php } ?><?php if(strlen($column_list["label_attribute"]["value"])){ ?> value="<?php echo $column_list["label_attribute"]["value"]; ?>"<?php } ?> class="text" type="text"<?php if($column_list["label_attribute"]["disabled"]){ ?> disabled="<?php echo $column_list["label_attribute"]["disabled"]; ?>"<?php } ?><?php if($column_list["label_attribute"]["readonly"]){ ?> readonly="<?php echo $column_list["label_attribute"]["readonly"]; ?>"<?php } ?>><?php } ?>

				</td>
				<td style="width:10em;border-left:solid 1px #bbb;">
					<?php if(!isset($column_list["linkage_soymail_visible"]) || $column_list["linkage_soymail_visible"]){ ?><select<?php if(strlen($column_list["linkage_soymail_attribute"]["name"])){ ?> name="<?php echo $column_list["linkage_soymail_attribute"]["name"]; ?>"<?php } ?> style="width:8em;"<?php if($column_list["linkage_soymail_attribute"]["disabled"]){ ?> disabled="<?php echo $column_list["linkage_soymail_attribute"]["disabled"]; ?>"<?php } ?><?php if($column_list["linkage_soymail_attribute"]["readonly"]){ ?> readonly="<?php echo $column_list["linkage_soymail_attribute"]["readonly"]; ?>"<?php } ?><?php if($column_list["linkage_soymail_attribute"]["multiple"]){ ?> multiple="<?php echo $column_list["linkage_soymail_attribute"]["multiple"]; ?>"<?php } ?>><?php echo $column_list["linkage_soymail"]; ?></select><?php } ?>

				</td>
				<td style="width:10em;border-left:solid 1px #bbb;">
					<?php if(!isset($column_list["linkage_soyshop_visible"]) || $column_list["linkage_soyshop_visible"]){ ?><select<?php if(strlen($column_list["linkage_soyshop_attribute"]["name"])){ ?> name="<?php echo $column_list["linkage_soyshop_attribute"]["name"]; ?>"<?php } ?> style="width:8em;"<?php if($column_list["linkage_soyshop_attribute"]["disabled"]){ ?> disabled="<?php echo $column_list["linkage_soyshop_attribute"]["disabled"]; ?>"<?php } ?><?php if($column_list["linkage_soyshop_attribute"]["readonly"]){ ?> readonly="<?php echo $column_list["linkage_soyshop_attribute"]["readonly"]; ?>"<?php } ?><?php if($column_list["linkage_soyshop_attribute"]["multiple"]){ ?> multiple="<?php echo $column_list["linkage_soyshop_attribute"]["multiple"]; ?>"<?php } ?>><?php echo $column_list["linkage_soyshop"]; ?></select><?php } ?>

				</td>
			</tr>
			<tr>
				<td class="configure" colspan="4">
					<?php if(!isset($column_list["configure_wrapper_visible"]) || $column_list["configure_wrapper_visible"]){ ?><div<?php if(strlen($column_list["configure_wrapper_attribute"]["id"])){ ?> id="<?php echo $column_list["configure_wrapper_attribute"]["id"]; ?>"<?php } ?>>

						<?php if(!isset($column_list["configure_visible"]) || $column_list["configure_visible"]){ ?><div style="margin:8px 0;"><?php echo $column_list["configure"]; ?></div><?php } ?>

						<div style="margin:8px 0;">
							注釈:<?php if(!isset($column_list["annotation_visible"]) || $column_list["annotation_visible"]){ ?><input<?php if(strlen($column_list["annotation_attribute"]["value"])){ ?> value="<?php echo $column_list["annotation_attribute"]["value"]; ?>"<?php } ?><?php if(strlen($column_list["annotation_attribute"]["name"])){ ?> name="<?php echo $column_list["annotation_attribute"]["name"]; ?>"<?php } ?> type="text" style="width: 90%;"<?php if($column_list["annotation_attribute"]["disabled"]){ ?> disabled="<?php echo $column_list["annotation_attribute"]["disabled"]; ?>"<?php } ?><?php if($column_list["annotation_attribute"]["readonly"]){ ?> readonly="<?php echo $column_list["annotation_attribute"]["readonly"]; ?>"<?php } ?>><?php } ?>

						</div>
						<?php if(!isset($column_list["replace_wrapper_visible"]) || $column_list["replace_wrapper_visible"]){ ?><span<?php if(strlen($column_list["replace_wrapper_attribute"]["id"])){ ?> id="<?php echo $column_list["replace_wrapper_attribute"]["id"]; ?>"<?php } ?><?php if(strlen($column_list["replace_wrapper_attribute"]["style"])){ ?> style="<?php echo $column_list["replace_wrapper_attribute"]["style"]; ?>"<?php } ?>>
							メールで引用:<?php if(!isset($column_list["replace_visible"]) || $column_list["replace_visible"]){ ?><input<?php if(strlen($column_list["replace_attribute"]["value"])){ ?> value="<?php echo $column_list["replace_attribute"]["value"]; ?>"<?php } ?><?php if(strlen($column_list["replace_attribute"]["name"])){ ?> name="<?php echo $column_list["replace_attribute"]["name"]; ?>"<?php } ?> type="input" style="margin-right:10px;margin-left:10px;"<?php if($column_list["replace_attribute"]["disabled"]){ ?> disabled="<?php echo $column_list["replace_attribute"]["disabled"]; ?>"<?php } ?><?php if($column_list["replace_attribute"]["readonly"]){ ?> readonly="<?php echo $column_list["replace_attribute"]["readonly"]; ?>"<?php } ?>><?php } ?>

						</span><?php } ?>

						<input type="submit" name="update" value="保存" style="margin-right:50px;margin-left:50px;" />
						<input type="submit" name="remove" value="削除" />
					</div><?php } ?>

				</td>
			</tr>
		</table>
	</div>

	</form><?php } ?>

	<?php } ?><?php } ?>

</div>

<script type="text/javascript">
$(function(){
    $("#column_fr",parent.document).css("height", ( document.body.scrollHeight + 50) + "px");
});
function changeColor(cell, input){
	$(input).prop("checked",!$(input).prop("checked"));
	var css_attr = ($(input).prop("checked")) ? $(cell).attr("checkColor") : "white";
	$(cell).css("backgroundColor",css_attr);
};

function changeRepalce(div,check){
    if($(check).prop("checked")){
		$(div).css("visibility","visible");
	}else{
		$(div).attr("visibility","hidden");
	}
};
</script>