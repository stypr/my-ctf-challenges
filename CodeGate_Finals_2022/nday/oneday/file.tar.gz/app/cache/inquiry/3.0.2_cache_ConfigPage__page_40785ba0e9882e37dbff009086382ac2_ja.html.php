<?php /* created 2022-11-05 09:17:20 */ ?>
<?php $page = HTMLPage::getPage(); ?>
<div class="functions">
	<div class="function">
		<a href="/app/index.php/inquiry/Form">戻る</a>
	</div>
	
	<div class="function">
		<?php if(!isset($page["design_link_visible"]) || $page["design_link_visible"]){ ?><?php if(strlen($page["design_link_attribute"]["href"])>0){ ?><a<?php if(strlen($page["design_link_attribute"]["href"])){ ?> href="<?php echo $page["design_link_attribute"]["href"]; ?>"<?php } ?>><?php } ?>問い合わせ項目<?php if(strlen($page["design_link_attribute"]["href"])>0){ ?></a><?php } ?><?php } ?>

	</div>
	
	<div class="function">
		<?php if(!isset($page["preview_link_visible"]) || $page["preview_link_visible"]){ ?><?php if(strlen($page["preview_link_attribute"]["href"])>0){ ?><a<?php if(strlen($page["preview_link_attribute"]["onclick"])){ ?> onclick="<?php echo $page["preview_link_attribute"]["onclick"]; ?>"<?php } ?><?php if(strlen($page["preview_link_attribute"]["href"])){ ?> href="<?php echo $page["preview_link_attribute"]["href"]; ?>"<?php } ?>><?php } ?>プレビュー<?php if(strlen($page["preview_link_attribute"]["href"])>0){ ?></a><?php } ?><?php } ?>

	</div>
	
	<div class="function">
		<?php if(!isset($page["template_link_visible"]) || $page["template_link_visible"]){ ?><?php if(strlen($page["template_link_attribute"]["href"])>0){ ?><a<?php if(strlen($page["template_link_attribute"]["href"])){ ?> href="<?php echo $page["template_link_attribute"]["href"]; ?>"<?php } ?>><?php } ?>SOY CMS連携<?php if(strlen($page["template_link_attribute"]["href"])>0){ ?></a><?php } ?><?php } ?>

	</div>

	<br style="clear:both;" />
</div>

<style type="text/css">
.small_message{
	font-size:90%;
	color:#999;
}
</style>

<div style="padding:0px 20px;">

<h1>フォーム - <?php if(!isset($page["form_name_visible"]) || $page["form_name_visible"]){ ?><span><?php echo $page["form_name"]; ?></span><?php } ?>
</h1>

<a name="config_form"></a>
<h2>フォームの設定</h2>

<div class="table_container">
<?php if(!isset($page["config_form_visible"]) || $page["config_form_visible"]){ ?><?php $config_form = $page["config_form"]; ?><form<?php if(strlen($page["config_form_attribute"]["action"])){ ?> action="<?php echo $page["config_form_attribute"]["action"]; ?>"<?php } ?><?php if(strlen($page["config_form_attribute"]["method"])){ ?> method="<?php echo $page["config_form_attribute"]["method"]; ?>"<?php } ?><?php if($page["config_form_attribute"]["disabled"]){ ?> disabled="<?php echo $page["config_form_attribute"]["disabled"]; ?>"<?php } ?>><input type="hidden" name="soy2_token" value="<?php echo soy2_get_token(); ?>">
<table class="form_table list">
	<col style="width:200px" />
	<tr>
		<th>
			フォーム名
		</th>
		<td>
			<?php if(!isset($page["config_form_name_visible"]) || $page["config_form_name_visible"]){ ?><input<?php if(strlen($page["config_form_name_attribute"]["name"])){ ?> name="<?php echo $page["config_form_name_attribute"]["name"]; ?>"<?php } ?><?php if(strlen($page["config_form_name_attribute"]["value"])){ ?> value="<?php echo $page["config_form_name_attribute"]["value"]; ?>"<?php } ?> class="text"<?php if($page["config_form_name_attribute"]["disabled"]){ ?> disabled="<?php echo $page["config_form_name_attribute"]["disabled"]; ?>"<?php } ?><?php if($page["config_form_name_attribute"]["readonly"]){ ?> readonly="<?php echo $page["config_form_name_attribute"]["readonly"]; ?>"<?php } ?>><?php } ?>

		</td>
	</tr>
	
	<tr>
		<th>
			フォームID
		</th>
		<td>
			<?php if(!isset($page["config_form_id_visible"]) || $page["config_form_id_visible"]){ ?><input<?php if(strlen($page["config_form_id_attribute"]["name"])){ ?> name="<?php echo $page["config_form_id_attribute"]["name"]; ?>"<?php } ?><?php if(strlen($page["config_form_id_attribute"]["value"])){ ?> value="<?php echo $page["config_form_id_attribute"]["value"]; ?>"<?php } ?> class="text"<?php if($page["config_form_id_attribute"]["disabled"]){ ?> disabled="<?php echo $page["config_form_id_attribute"]["disabled"]; ?>"<?php } ?><?php if($page["config_form_id_attribute"]["readonly"]){ ?> readonly="<?php echo $page["config_form_id_attribute"]["readonly"]; ?>"<?php } ?>><?php } ?>

		</td>
	</tr>

	<tr>
		<th>
			CAPCTHA(画像認証)を使用する
		</th>
		<td>
			<?php if(!isset($page["config_notUseCaptcha_visible"]) || $page["config_notUseCaptcha_visible"]){ ?><input<?php if(strlen($page["config_notUseCaptcha_attribute"]["type"])){ ?> type="<?php echo $page["config_notUseCaptcha_attribute"]["type"]; ?>"<?php } ?><?php if(strlen($page["config_notUseCaptcha_attribute"]["name"])){ ?> name="<?php echo $page["config_notUseCaptcha_attribute"]["name"]; ?>"<?php } ?><?php if(strlen($page["config_notUseCaptcha_attribute"]["value"])){ ?> value="<?php echo $page["config_notUseCaptcha_attribute"]["value"]; ?>"<?php } ?><?php if($page["config_notUseCaptcha_attribute"]["disabled"]){ ?> disabled="<?php echo $page["config_notUseCaptcha_attribute"]["disabled"]; ?>"<?php } ?><?php if($page["config_notUseCaptcha_attribute"]["readonly"]){ ?> readonly="<?php echo $page["config_notUseCaptcha_attribute"]["readonly"]; ?>"<?php } ?>><?php } ?>

			<?php if(!isset($page["config_isUseCaptcha_visible"]) || $page["config_isUseCaptcha_visible"]){ ?><input<?php if(strlen($page["config_isUseCaptcha_attribute"]["name"])){ ?> name="<?php echo $page["config_isUseCaptcha_attribute"]["name"]; ?>"<?php } ?><?php if(strlen($page["config_isUseCaptcha_attribute"]["value"])){ ?> value="<?php echo $page["config_isUseCaptcha_attribute"]["value"]; ?>"<?php } ?> type="checkbox"<?php if($page["config_isUseCaptcha_attribute"]["disabled"]){ ?> disabled="<?php echo $page["config_isUseCaptcha_attribute"]["disabled"]; ?>"<?php } ?><?php if($page["config_isUseCaptcha_attribute"]["readonly"]){ ?> readonly="<?php echo $page["config_isUseCaptcha_attribute"]["readonly"]; ?>"<?php } ?><?php if(strlen($page["config_isUseCaptcha_attribute"]["id"])){ ?> id="<?php echo $page["config_isUseCaptcha_attribute"]["id"]; ?>"<?php } ?><?php if($page["config_isUseCaptcha_attribute"]["checked"]){ ?> checked="<?php echo $page["config_isUseCaptcha_attribute"]["checked"]; ?>"<?php } ?>><?php if(strlen($page["config_isUseCaptcha"])>0){ ?><label for="<?php echo $page["config_isUseCaptcha_attribute"]["id"]; ?>"><?php echo $page["config_isUseCaptcha"]; ?></label><?php } ?><?php } ?>

			<?php if(!isset($page["gd_disabled_visible"]) || $page["gd_disabled_visible"]){ ?><p class="error"><a href="http://www.php.net/manual/book.image.php">GD</a>が使えないため使用出来ません。</p><?php } ?>

		</td>
	</tr>
	<!--tr>
		<th>
			スマートフォン設定
		</th>
		<td>
			<?php if(!isset($page["config_notSmartPhone_visible"]) || $page["config_notSmartPhone_visible"]){ ?><input<?php if(strlen($page["config_notSmartPhone_attribute"]["type"])){ ?> type="<?php echo $page["config_notSmartPhone_attribute"]["type"]; ?>"<?php } ?><?php if(strlen($page["config_notSmartPhone_attribute"]["name"])){ ?> name="<?php echo $page["config_notSmartPhone_attribute"]["name"]; ?>"<?php } ?><?php if(strlen($page["config_notSmartPhone_attribute"]["value"])){ ?> value="<?php echo $page["config_notSmartPhone_attribute"]["value"]; ?>"<?php } ?><?php if($page["config_notSmartPhone_attribute"]["disabled"]){ ?> disabled="<?php echo $page["config_notSmartPhone_attribute"]["disabled"]; ?>"<?php } ?><?php if($page["config_notSmartPhone_attribute"]["readonly"]){ ?> readonly="<?php echo $page["config_notSmartPhone_attribute"]["readonly"]; ?>"<?php } ?>><?php } ?>

			<?php if(!isset($page["config_isSmartPhone_visible"]) || $page["config_isSmartPhone_visible"]){ ?><input<?php if(strlen($page["config_isSmartPhone_attribute"]["name"])){ ?> name="<?php echo $page["config_isSmartPhone_attribute"]["name"]; ?>"<?php } ?><?php if(strlen($page["config_isSmartPhone_attribute"]["value"])){ ?> value="<?php echo $page["config_isSmartPhone_attribute"]["value"]; ?>"<?php } ?> type="checkbox"<?php if($page["config_isSmartPhone_attribute"]["disabled"]){ ?> disabled="<?php echo $page["config_isSmartPhone_attribute"]["disabled"]; ?>"<?php } ?><?php if($page["config_isSmartPhone_attribute"]["readonly"]){ ?> readonly="<?php echo $page["config_isSmartPhone_attribute"]["readonly"]; ?>"<?php } ?><?php if(strlen($page["config_isSmartPhone_attribute"]["id"])){ ?> id="<?php echo $page["config_isSmartPhone_attribute"]["id"]; ?>"<?php } ?><?php if($page["config_isSmartPhone_attribute"]["checked"]){ ?> checked="<?php echo $page["config_isSmartPhone_attribute"]["checked"]; ?>"<?php } ?>><?php if(strlen($page["config_isSmartPhone"])>0){ ?><label for="<?php echo $page["config_isSmartPhone_attribute"]["id"]; ?>"><?php echo $page["config_isSmartPhone"]; ?></label><?php } ?><?php } ?>

		</td>
	</tr-->
	
</table>

	<table class="button_table">
		<tr class="button_table_row">
			<td>
				<button name="config" type="submit">保存</button>
			</td>
		</tr>
	</table>
	
</form><?php } ?>

</div>

<a name="mail_form"></a>
<h2>メールの送信設定</h2>

<div class="table_container">
<?php if(!isset($page["mail_form_visible"]) || $page["mail_form_visible"]){ ?><?php $mail_form = $page["mail_form"]; ?><form<?php if(strlen($page["mail_form_attribute"]["action"])){ ?> action="<?php echo $page["mail_form_attribute"]["action"]; ?>"<?php } ?><?php if(strlen($page["mail_form_attribute"]["method"])){ ?> method="<?php echo $page["mail_form_attribute"]["method"]; ?>"<?php } ?><?php if($page["mail_form_attribute"]["disabled"]){ ?> disabled="<?php echo $page["mail_form_attribute"]["disabled"]; ?>"<?php } ?>><input type="hidden" name="soy2_token" value="<?php echo soy2_get_token(); ?>">
	<table class="form_table list">
		<col style="width:200px" />
		<tr>
			<td colspan="2">管理者宛メールの設定</td>
		</tr>
		<tr>
			<th>
				送信可否
			</th>
			<td>
				<?php if(!isset($page["config_notSendNotifyMail_visible"]) || $page["config_notSendNotifyMail_visible"]){ ?><input<?php if(strlen($page["config_notSendNotifyMail_attribute"]["name"])){ ?> name="<?php echo $page["config_notSendNotifyMail_attribute"]["name"]; ?>"<?php } ?><?php if(strlen($page["config_notSendNotifyMail_attribute"]["value"])){ ?> value="<?php echo $page["config_notSendNotifyMail_attribute"]["value"]; ?>"<?php } ?> type="hidden"<?php if($page["config_notSendNotifyMail_attribute"]["disabled"]){ ?> disabled="<?php echo $page["config_notSendNotifyMail_attribute"]["disabled"]; ?>"<?php } ?><?php if($page["config_notSendNotifyMail_attribute"]["readonly"]){ ?> readonly="<?php echo $page["config_notSendNotifyMail_attribute"]["readonly"]; ?>"<?php } ?><?php if(strlen($page["config_notSendNotifyMail_attribute"]["id"])){ ?> id="<?php echo $page["config_notSendNotifyMail_attribute"]["id"]; ?>"<?php } ?><?php if($page["config_notSendNotifyMail_attribute"]["checked"]){ ?> checked="<?php echo $page["config_notSendNotifyMail_attribute"]["checked"]; ?>"<?php } ?>><?php if(strlen($page["config_notSendNotifyMail"])>0){ ?><label for="<?php echo $page["config_notSendNotifyMail_attribute"]["id"]; ?>"><?php echo $page["config_notSendNotifyMail"]; ?></label><?php } ?><?php } ?>

				<?php if(!isset($page["config_isSendNotifyMail_visible"]) || $page["config_isSendNotifyMail_visible"]){ ?><input<?php if(strlen($page["config_isSendNotifyMail_attribute"]["name"])){ ?> name="<?php echo $page["config_isSendNotifyMail_attribute"]["name"]; ?>"<?php } ?><?php if(strlen($page["config_isSendNotifyMail_attribute"]["value"])){ ?> value="<?php echo $page["config_isSendNotifyMail_attribute"]["value"]; ?>"<?php } ?> type="checkbox"<?php if($page["config_isSendNotifyMail_attribute"]["disabled"]){ ?> disabled="<?php echo $page["config_isSendNotifyMail_attribute"]["disabled"]; ?>"<?php } ?><?php if($page["config_isSendNotifyMail_attribute"]["readonly"]){ ?> readonly="<?php echo $page["config_isSendNotifyMail_attribute"]["readonly"]; ?>"<?php } ?><?php if(strlen($page["config_isSendNotifyMail_attribute"]["id"])){ ?> id="<?php echo $page["config_isSendNotifyMail_attribute"]["id"]; ?>"<?php } ?><?php if($page["config_isSendNotifyMail_attribute"]["checked"]){ ?> checked="<?php echo $page["config_isSendNotifyMail_attribute"]["checked"]; ?>"<?php } ?>><?php if(strlen($page["config_isSendNotifyMail"])>0){ ?><label for="<?php echo $page["config_isSendNotifyMail_attribute"]["id"]; ?>"><?php echo $page["config_isSendNotifyMail"]; ?></label><?php } ?><?php } ?>

			</td>
		</tr>
		<tr>
			<th>
				追加の送信先
			</th>
			<td>
				<?php if(!isset($page["config_administratorMailAddress_visible"]) || $page["config_administratorMailAddress_visible"]){ ?><input<?php if(strlen($page["config_administratorMailAddress_attribute"]["name"])){ ?> name="<?php echo $page["config_administratorMailAddress_attribute"]["name"]; ?>"<?php } ?><?php if(strlen($page["config_administratorMailAddress_attribute"]["value"])){ ?> value="<?php echo $page["config_administratorMailAddress_attribute"]["value"]; ?>"<?php } ?> class="text"<?php if($page["config_administratorMailAddress_attribute"]["disabled"]){ ?> disabled="<?php echo $page["config_administratorMailAddress_attribute"]["disabled"]; ?>"<?php } ?><?php if($page["config_administratorMailAddress_attribute"]["readonly"]){ ?> readonly="<?php echo $page["config_administratorMailAddress_attribute"]["readonly"]; ?>"<?php } ?>><?php } ?>
<br />
				<span class="small_message">「,」区切りで複数個入力できます。</span>
			</td>
		</tr>
		<tr>
			<th>
				件名
			</th>
			<td>
				<?php if(!isset($page["config_notifyMailSubject_visible"]) || $page["config_notifyMailSubject_visible"]){ ?><input<?php if(strlen($page["config_notifyMailSubject_attribute"]["name"])){ ?> name="<?php echo $page["config_notifyMailSubject_attribute"]["name"]; ?>"<?php } ?><?php if(strlen($page["config_notifyMailSubject_attribute"]["value"])){ ?> value="<?php echo $page["config_notifyMailSubject_attribute"]["value"]; ?>"<?php } ?> class="text"<?php if($page["config_notifyMailSubject_attribute"]["disabled"]){ ?> disabled="<?php echo $page["config_notifyMailSubject_attribute"]["disabled"]; ?>"<?php } ?><?php if($page["config_notifyMailSubject_attribute"]["readonly"]){ ?> readonly="<?php echo $page["config_notifyMailSubject_attribute"]["readonly"]; ?>"<?php } ?>><?php } ?>
<br />
				<span class="small_message"><?php if(!isset($page["replace_trackingnumber_text_visible"]) || $page["replace_trackingnumber_text_visible"]){ ?><?php echo $page["replace_trackingnumber_text"]; ?><?php } ?>
などが使えます。</span>
			</td>
		</tr>
		<tr>
			<th>
				管理画面へのリンク
			</th>
			<td>
				<?php if(!isset($page["config_notIncludeAdminURL_visible"]) || $page["config_notIncludeAdminURL_visible"]){ ?><input<?php if(strlen($page["config_notIncludeAdminURL_attribute"]["name"])){ ?> name="<?php echo $page["config_notIncludeAdminURL_attribute"]["name"]; ?>"<?php } ?><?php if(strlen($page["config_notIncludeAdminURL_attribute"]["value"])){ ?> value="<?php echo $page["config_notIncludeAdminURL_attribute"]["value"]; ?>"<?php } ?> type="hidden"<?php if($page["config_notIncludeAdminURL_attribute"]["disabled"]){ ?> disabled="<?php echo $page["config_notIncludeAdminURL_attribute"]["disabled"]; ?>"<?php } ?><?php if($page["config_notIncludeAdminURL_attribute"]["readonly"]){ ?> readonly="<?php echo $page["config_notIncludeAdminURL_attribute"]["readonly"]; ?>"<?php } ?><?php if(strlen($page["config_notIncludeAdminURL_attribute"]["id"])){ ?> id="<?php echo $page["config_notIncludeAdminURL_attribute"]["id"]; ?>"<?php } ?><?php if($page["config_notIncludeAdminURL_attribute"]["checked"]){ ?> checked="<?php echo $page["config_notIncludeAdminURL_attribute"]["checked"]; ?>"<?php } ?>><?php if(strlen($page["config_notIncludeAdminURL"])>0){ ?><label for="<?php echo $page["config_notIncludeAdminURL_attribute"]["id"]; ?>"><?php echo $page["config_notIncludeAdminURL"]; ?></label><?php } ?><?php } ?>

				<?php if(!isset($page["config_isIncludeAdminURL_visible"]) || $page["config_isIncludeAdminURL_visible"]){ ?><input<?php if(strlen($page["config_isIncludeAdminURL_attribute"]["name"])){ ?> name="<?php echo $page["config_isIncludeAdminURL_attribute"]["name"]; ?>"<?php } ?><?php if(strlen($page["config_isIncludeAdminURL_attribute"]["value"])){ ?> value="<?php echo $page["config_isIncludeAdminURL_attribute"]["value"]; ?>"<?php } ?> type="checkbox"<?php if($page["config_isIncludeAdminURL_attribute"]["disabled"]){ ?> disabled="<?php echo $page["config_isIncludeAdminURL_attribute"]["disabled"]; ?>"<?php } ?><?php if($page["config_isIncludeAdminURL_attribute"]["readonly"]){ ?> readonly="<?php echo $page["config_isIncludeAdminURL_attribute"]["readonly"]; ?>"<?php } ?><?php if(strlen($page["config_isIncludeAdminURL_attribute"]["id"])){ ?> id="<?php echo $page["config_isIncludeAdminURL_attribute"]["id"]; ?>"<?php } ?><?php if($page["config_isIncludeAdminURL_attribute"]["checked"]){ ?> checked="<?php echo $page["config_isIncludeAdminURL_attribute"]["checked"]; ?>"<?php } ?>><?php if(strlen($page["config_isIncludeAdminURL"])>0){ ?><label for="<?php echo $page["config_isIncludeAdminURL_attribute"]["id"]; ?>"><?php echo $page["config_isIncludeAdminURL"]; ?></label><?php } ?><?php } ?>

			</td>
		</tr>
		<tr>
			<th>
				返信先
			</th>
			<td>
				<?php if(!isset($page["config_notReplyToUser_visible"]) || $page["config_notReplyToUser_visible"]){ ?><input<?php if(strlen($page["config_notReplyToUser_attribute"]["name"])){ ?> name="<?php echo $page["config_notReplyToUser_attribute"]["name"]; ?>"<?php } ?><?php if(strlen($page["config_notReplyToUser_attribute"]["value"])){ ?> value="<?php echo $page["config_notReplyToUser_attribute"]["value"]; ?>"<?php } ?> type="hidden"<?php if($page["config_notReplyToUser_attribute"]["disabled"]){ ?> disabled="<?php echo $page["config_notReplyToUser_attribute"]["disabled"]; ?>"<?php } ?><?php if($page["config_notReplyToUser_attribute"]["readonly"]){ ?> readonly="<?php echo $page["config_notReplyToUser_attribute"]["readonly"]; ?>"<?php } ?><?php if(strlen($page["config_notReplyToUser_attribute"]["id"])){ ?> id="<?php echo $page["config_notReplyToUser_attribute"]["id"]; ?>"<?php } ?><?php if($page["config_notReplyToUser_attribute"]["checked"]){ ?> checked="<?php echo $page["config_notReplyToUser_attribute"]["checked"]; ?>"<?php } ?>><?php if(strlen($page["config_notReplyToUser"])>0){ ?><label for="<?php echo $page["config_notReplyToUser_attribute"]["id"]; ?>"><?php echo $page["config_notReplyToUser"]; ?></label><?php } ?><?php } ?>

				<?php if(!isset($page["config_isReplyToUser_visible"]) || $page["config_isReplyToUser_visible"]){ ?><input<?php if(strlen($page["config_isReplyToUser_attribute"]["name"])){ ?> name="<?php echo $page["config_isReplyToUser_attribute"]["name"]; ?>"<?php } ?><?php if(strlen($page["config_isReplyToUser_attribute"]["value"])){ ?> value="<?php echo $page["config_isReplyToUser_attribute"]["value"]; ?>"<?php } ?> type="checkbox"<?php if($page["config_isReplyToUser_attribute"]["disabled"]){ ?> disabled="<?php echo $page["config_isReplyToUser_attribute"]["disabled"]; ?>"<?php } ?><?php if($page["config_isReplyToUser_attribute"]["readonly"]){ ?> readonly="<?php echo $page["config_isReplyToUser_attribute"]["readonly"]; ?>"<?php } ?><?php if(strlen($page["config_isReplyToUser_attribute"]["id"])){ ?> id="<?php echo $page["config_isReplyToUser_attribute"]["id"]; ?>"<?php } ?><?php if($page["config_isReplyToUser_attribute"]["checked"]){ ?> checked="<?php echo $page["config_isReplyToUser_attribute"]["checked"]; ?>"<?php } ?>><?php if(strlen($page["config_isReplyToUser"])>0){ ?><label for="<?php echo $page["config_isReplyToUser_attribute"]["id"]; ?>"><?php echo $page["config_isReplyToUser"]; ?></label><?php } ?><?php } ?>

			</td>
		</tr>
	</table>
		
	<table class="form_table list">
		<col style="width:200px" />
		<tr>
			<td colspan="2">ユーザー宛メールの設定</td>
		</tr>
		<tr>
			<th>
				送信可否
			</th>
			<td>
				<?php if(!isset($page["config_notSendConfirmMail_visible"]) || $page["config_notSendConfirmMail_visible"]){ ?><input<?php if(strlen($page["config_notSendConfirmMail_attribute"]["name"])){ ?> name="<?php echo $page["config_notSendConfirmMail_attribute"]["name"]; ?>"<?php } ?><?php if(strlen($page["config_notSendConfirmMail_attribute"]["value"])){ ?> value="<?php echo $page["config_notSendConfirmMail_attribute"]["value"]; ?>"<?php } ?> type="hidden"<?php if($page["config_notSendConfirmMail_attribute"]["disabled"]){ ?> disabled="<?php echo $page["config_notSendConfirmMail_attribute"]["disabled"]; ?>"<?php } ?><?php if($page["config_notSendConfirmMail_attribute"]["readonly"]){ ?> readonly="<?php echo $page["config_notSendConfirmMail_attribute"]["readonly"]; ?>"<?php } ?><?php if(strlen($page["config_notSendConfirmMail_attribute"]["id"])){ ?> id="<?php echo $page["config_notSendConfirmMail_attribute"]["id"]; ?>"<?php } ?><?php if($page["config_notSendConfirmMail_attribute"]["checked"]){ ?> checked="<?php echo $page["config_notSendConfirmMail_attribute"]["checked"]; ?>"<?php } ?>><?php if(strlen($page["config_notSendConfirmMail"])>0){ ?><label for="<?php echo $page["config_notSendConfirmMail_attribute"]["id"]; ?>"><?php echo $page["config_notSendConfirmMail"]; ?></label><?php } ?><?php } ?>

				<?php if(!isset($page["config_isSendConfirmMail_visible"]) || $page["config_isSendConfirmMail_visible"]){ ?><input<?php if(strlen($page["config_isSendConfirmMail_attribute"]["name"])){ ?> name="<?php echo $page["config_isSendConfirmMail_attribute"]["name"]; ?>"<?php } ?><?php if(strlen($page["config_isSendConfirmMail_attribute"]["value"])){ ?> value="<?php echo $page["config_isSendConfirmMail_attribute"]["value"]; ?>"<?php } ?> type="checkbox"<?php if($page["config_isSendConfirmMail_attribute"]["disabled"]){ ?> disabled="<?php echo $page["config_isSendConfirmMail_attribute"]["disabled"]; ?>"<?php } ?><?php if($page["config_isSendConfirmMail_attribute"]["readonly"]){ ?> readonly="<?php echo $page["config_isSendConfirmMail_attribute"]["readonly"]; ?>"<?php } ?><?php if(strlen($page["config_isSendConfirmMail_attribute"]["id"])){ ?> id="<?php echo $page["config_isSendConfirmMail_attribute"]["id"]; ?>"<?php } ?><?php if($page["config_isSendConfirmMail_attribute"]["checked"]){ ?> checked="<?php echo $page["config_isSendConfirmMail_attribute"]["checked"]; ?>"<?php } ?>><?php if(strlen($page["config_isSendConfirmMail"])>0){ ?><label for="<?php echo $page["config_isSendConfirmMail_attribute"]["id"]; ?>"><?php echo $page["config_isSendConfirmMail"]; ?></label><?php } ?><?php } ?>

			</td>
		</tr>
		
		<tr>
			<th>送信元メールアドレス（個別）</th>
			<td>
				<?php if(!isset($page["config_fromAddress_visible"]) || $page["config_fromAddress_visible"]){ ?><input<?php if(strlen($page["config_fromAddress_attribute"]["name"])){ ?> name="<?php echo $page["config_fromAddress_attribute"]["name"]; ?>"<?php } ?><?php if(strlen($page["config_fromAddress_attribute"]["value"])){ ?> value="<?php echo $page["config_fromAddress_attribute"]["value"]; ?>"<?php } ?> class="text"<?php if($page["config_fromAddress_attribute"]["disabled"]){ ?> disabled="<?php echo $page["config_fromAddress_attribute"]["disabled"]; ?>"<?php } ?><?php if($page["config_fromAddress_attribute"]["readonly"]){ ?> readonly="<?php echo $page["config_fromAddress_attribute"]["readonly"]; ?>"<?php } ?>><?php } ?>

			</td>
		</tr>
		
		<tr>
			<th>送信元名称（個別）</th>
			<td>
				<?php if(!isset($page["config_fromAddressName_visible"]) || $page["config_fromAddressName_visible"]){ ?><input<?php if(strlen($page["config_fromAddressName_attribute"]["name"])){ ?> name="<?php echo $page["config_fromAddressName_attribute"]["name"]; ?>"<?php } ?><?php if(strlen($page["config_fromAddressName_attribute"]["value"])){ ?> value="<?php echo $page["config_fromAddressName_attribute"]["value"]; ?>"<?php } ?> class="text"<?php if($page["config_fromAddressName_attribute"]["disabled"]){ ?> disabled="<?php echo $page["config_fromAddressName_attribute"]["disabled"]; ?>"<?php } ?><?php if($page["config_fromAddressName_attribute"]["readonly"]){ ?> readonly="<?php echo $page["config_fromAddressName_attribute"]["readonly"]; ?>"<?php } ?>><?php } ?>

			</td>
		</tr>
		
		<tr>
			<th>返信先メールアドレス（個別）</th>
			<td>
				<?php if(!isset($page["config_returnAddress_visible"]) || $page["config_returnAddress_visible"]){ ?><input<?php if(strlen($page["config_returnAddress_attribute"]["name"])){ ?> name="<?php echo $page["config_returnAddress_attribute"]["name"]; ?>"<?php } ?><?php if(strlen($page["config_returnAddress_attribute"]["value"])){ ?> value="<?php echo $page["config_returnAddress_attribute"]["value"]; ?>"<?php } ?> class="text"<?php if($page["config_returnAddress_attribute"]["disabled"]){ ?> disabled="<?php echo $page["config_returnAddress_attribute"]["disabled"]; ?>"<?php } ?><?php if($page["config_returnAddress_attribute"]["readonly"]){ ?> readonly="<?php echo $page["config_returnAddress_attribute"]["readonly"]; ?>"<?php } ?>><?php } ?>

			</td>
		</tr>
		
		<tr>
			<th>返信先名称（個別）</th>
			<td>
				<?php if(!isset($page["config_returnAddressName_visible"]) || $page["config_returnAddressName_visible"]){ ?><input<?php if(strlen($page["config_returnAddressName_attribute"]["name"])){ ?> name="<?php echo $page["config_returnAddressName_attribute"]["name"]; ?>"<?php } ?><?php if(strlen($page["config_returnAddressName_attribute"]["value"])){ ?> value="<?php echo $page["config_returnAddressName_attribute"]["value"]; ?>"<?php } ?> class="text"<?php if($page["config_returnAddressName_attribute"]["disabled"]){ ?> disabled="<?php echo $page["config_returnAddressName_attribute"]["disabled"]; ?>"<?php } ?><?php if($page["config_returnAddressName_attribute"]["readonly"]){ ?> readonly="<?php echo $page["config_returnAddressName_attribute"]["readonly"]; ?>"<?php } ?>><?php } ?>

			</td>
		</tr>
		
	</table>

	<table class="button_table">
		<tr class="button_table_row">
			<td>
				<button name="mail" type="submit">保存</button>
			</td>
		</tr>
	</table>
	
</form><?php } ?>

</div>

<a name="message_form"></a>
<h2>フォームのメッセージ設定</h2>

<div class="table_container">
<?php if(!isset($page["message_form_visible"]) || $page["message_form_visible"]){ ?><?php $message_form = $page["message_form"]; ?><form<?php if(strlen($page["message_form_attribute"]["action"])){ ?> action="<?php echo $page["message_form_attribute"]["action"]; ?>"<?php } ?><?php if(strlen($page["message_form_attribute"]["method"])){ ?> method="<?php echo $page["message_form_attribute"]["method"]; ?>"<?php } ?><?php if($page["message_form_attribute"]["disabled"]){ ?> disabled="<?php echo $page["message_form_attribute"]["disabled"]; ?>"<?php } ?>><input type="hidden" name="soy2_token" value="<?php echo soy2_get_token(); ?>">
<table class="form_table list">
	<tr>
		<th>説明</th>
	</tr>
	<tr>
		<td>
			<?php if(!isset($page["message_information_visible"]) || $page["message_information_visible"]){ ?><textarea<?php if(strlen($page["message_information_attribute"]["name"])){ ?> name="<?php echo $page["message_information_attribute"]["name"]; ?>"<?php } ?> style="width:96%;padding:5px 2%;"<?php if($page["message_information_attribute"]["disabled"]){ ?> disabled="<?php echo $page["message_information_attribute"]["disabled"]; ?>"<?php } ?><?php if($page["message_information_attribute"]["readonly"]){ ?> readonly="<?php echo $page["message_information_attribute"]["readonly"]; ?>"<?php } ?>><?php echo $page["message_information"]; ?></textarea><?php } ?>

		</td>
	</tr>
</table>

<table class="form_table list">
	<tr>
		<th>確認メッセージ</th>
	</tr>
	<tr>
		<td>
			<?php if(!isset($page["message_confirm_visible"]) || $page["message_confirm_visible"]){ ?><textarea<?php if(strlen($page["message_confirm_attribute"]["name"])){ ?> name="<?php echo $page["message_confirm_attribute"]["name"]; ?>"<?php } ?> style="width:96%;padding:5px 2%;"<?php if($page["message_confirm_attribute"]["disabled"]){ ?> disabled="<?php echo $page["message_confirm_attribute"]["disabled"]; ?>"<?php } ?><?php if($page["message_confirm_attribute"]["readonly"]){ ?> readonly="<?php echo $page["message_confirm_attribute"]["readonly"]; ?>"<?php } ?>><?php echo $page["message_confirm"]; ?></textarea><?php } ?>

		</td>
	</tr>
</table>

<table class="form_table list">
	<tr>
		<th>送信完了メッセージ</th>
	</tr>
	<tr>
		<td>
			<?php if(!isset($page["message_complete_visible"]) || $page["message_complete_visible"]){ ?><textarea<?php if(strlen($page["message_complete_attribute"]["name"])){ ?> name="<?php echo $page["message_complete_attribute"]["name"]; ?>"<?php } ?> style="width:96%;padding:5px 2%;"<?php if($page["message_complete_attribute"]["disabled"]){ ?> disabled="<?php echo $page["message_complete_attribute"]["disabled"]; ?>"<?php } ?><?php if($page["message_complete_attribute"]["readonly"]){ ?> readonly="<?php echo $page["message_complete_attribute"]["readonly"]; ?>"<?php } ?>><?php echo $page["message_complete"]; ?></textarea><?php } ?>

		</td>
	</tr>
</table>

<table class="button_table">
	<tr class="button_table_row">
		<td>
			<button name="message" type="submit">保存</button>
		</td>
	</tr>
</table>


</form><?php } ?>

</div>


<a name="confirmmail_form"></a>
<h2>確認メール設定</h2>

<div class="table_container">
<?php if(!isset($page["confirmmail_form_visible"]) || $page["confirmmail_form_visible"]){ ?><?php $confirmmail_form = $page["confirmmail_form"]; ?><form<?php if(strlen($page["confirmmail_form_attribute"]["action"])){ ?> action="<?php echo $page["confirmmail_form_attribute"]["action"]; ?>"<?php } ?><?php if(strlen($page["confirmmail_form_attribute"]["method"])){ ?> method="<?php echo $page["confirmmail_form_attribute"]["method"]; ?>"<?php } ?><?php if($page["confirmmail_form_attribute"]["disabled"]){ ?> disabled="<?php echo $page["confirmmail_form_attribute"]["disabled"]; ?>"<?php } ?>><input type="hidden" name="soy2_token" value="<?php echo soy2_get_token(); ?>">
<table class="form_table list">
	<tr>
		<th style="width:200px;">件名</th>
		<td>
			<?php if(!isset($page["confirmmail_title_visible"]) || $page["confirmmail_title_visible"]){ ?><input<?php if(strlen($page["confirmmail_title_attribute"]["name"])){ ?> name="<?php echo $page["confirmmail_title_attribute"]["name"]; ?>"<?php } ?><?php if(strlen($page["confirmmail_title_attribute"]["value"])){ ?> value="<?php echo $page["confirmmail_title_attribute"]["value"]; ?>"<?php } ?> class="text"<?php if($page["confirmmail_title_attribute"]["disabled"]){ ?> disabled="<?php echo $page["confirmmail_title_attribute"]["disabled"]; ?>"<?php } ?><?php if($page["confirmmail_title_attribute"]["readonly"]){ ?> readonly="<?php echo $page["confirmmail_title_attribute"]["readonly"]; ?>"<?php } ?>><?php } ?>

			<span class="small_message"><?php if(!isset($page["replace_trackingnumber_text_visible"]) || $page["replace_trackingnumber_text_visible"]){ ?><?php echo $page["replace_trackingnumber_text"]; ?><?php } ?>
などが使えます。</span>
		</td>
	</tr>
</table>

<table class="form_table list">
	<tr>
		<th>本文</th>
	</tr>
	<tr class="last_row">
		<td>
			<?php if(!isset($page["confirmmail_notoutput_content_visible"]) || $page["confirmmail_notoutput_content_visible"]){ ?><input<?php if(strlen($page["confirmmail_notoutput_content_attribute"]["name"])){ ?> name="<?php echo $page["confirmmail_notoutput_content_attribute"]["name"]; ?>"<?php } ?><?php if(strlen($page["confirmmail_notoutput_content_attribute"]["value"])){ ?> value="<?php echo $page["confirmmail_notoutput_content_attribute"]["value"]; ?>"<?php } ?> type="hidden"<?php if($page["confirmmail_notoutput_content_attribute"]["disabled"]){ ?> disabled="<?php echo $page["confirmmail_notoutput_content_attribute"]["disabled"]; ?>"<?php } ?><?php if($page["confirmmail_notoutput_content_attribute"]["readonly"]){ ?> readonly="<?php echo $page["confirmmail_notoutput_content_attribute"]["readonly"]; ?>"<?php } ?>><?php } ?>

			<?php if(!isset($page["confirmmail_isoutput_content_visible"]) || $page["confirmmail_isoutput_content_visible"]){ ?><input<?php if(strlen($page["confirmmail_isoutput_content_attribute"]["name"])){ ?> name="<?php echo $page["confirmmail_isoutput_content_attribute"]["name"]; ?>"<?php } ?><?php if(strlen($page["confirmmail_isoutput_content_attribute"]["value"])){ ?> value="<?php echo $page["confirmmail_isoutput_content_attribute"]["value"]; ?>"<?php } ?> type="checkbox"<?php if($page["confirmmail_isoutput_content_attribute"]["disabled"]){ ?> disabled="<?php echo $page["confirmmail_isoutput_content_attribute"]["disabled"]; ?>"<?php } ?><?php if($page["confirmmail_isoutput_content_attribute"]["readonly"]){ ?> readonly="<?php echo $page["confirmmail_isoutput_content_attribute"]["readonly"]; ?>"<?php } ?><?php if(strlen($page["confirmmail_isoutput_content_attribute"]["id"])){ ?> id="<?php echo $page["confirmmail_isoutput_content_attribute"]["id"]; ?>"<?php } ?><?php if($page["confirmmail_isoutput_content_attribute"]["checked"]){ ?> checked="<?php echo $page["confirmmail_isoutput_content_attribute"]["checked"]; ?>"<?php } ?>><?php if(strlen($page["confirmmail_isoutput_content"])>0){ ?><label for="<?php echo $page["confirmmail_isoutput_content_attribute"]["id"]; ?>"><?php echo $page["confirmmail_isoutput_content"]; ?></label><?php } ?><?php } ?>

		</td>
	</tr>
	<tr>
		<td>
			お問い合わせ番号をメールの件名および本文で使用する：<?php if(!isset($page["replace_trackingnumber_visible"]) || $page["replace_trackingnumber_visible"]){ ?><input<?php if(strlen($page["replace_trackingnumber_attribute"]["name"])){ ?> name="<?php echo $page["replace_trackingnumber_attribute"]["name"]; ?>"<?php } ?><?php if(strlen($page["replace_trackingnumber_attribute"]["value"])){ ?> value="<?php echo $page["replace_trackingnumber_attribute"]["value"]; ?>"<?php } ?> type="input"<?php if($page["replace_trackingnumber_attribute"]["disabled"]){ ?> disabled="<?php echo $page["replace_trackingnumber_attribute"]["disabled"]; ?>"<?php } ?><?php if($page["replace_trackingnumber_attribute"]["readonly"]){ ?> readonly="<?php echo $page["replace_trackingnumber_attribute"]["readonly"]; ?>"<?php } ?>><?php } ?>

		</td>
	</tr>
	<tr>
		<th>ヘッダー</th>
	</tr>
	<tr class="last_row">
		<td>
			<?php if(!isset($page["confirmmail_header_visible"]) || $page["confirmmail_header_visible"]){ ?><textarea<?php if(strlen($page["confirmmail_header_attribute"]["name"])){ ?> name="<?php echo $page["confirmmail_header_attribute"]["name"]; ?>"<?php } ?> style="width:96%;padding:5px 2%;"<?php if($page["confirmmail_header_attribute"]["disabled"]){ ?> disabled="<?php echo $page["confirmmail_header_attribute"]["disabled"]; ?>"<?php } ?><?php if($page["confirmmail_header_attribute"]["readonly"]){ ?> readonly="<?php echo $page["confirmmail_header_attribute"]["readonly"]; ?>"<?php } ?>><?php echo $page["confirmmail_header"]; ?></textarea><?php } ?>

		</td>
	</tr>
	<tr>
		<th>フッター</th>
	</tr>
	<tr>
		<td>
			<?php if(!isset($page["confirmmail_footer_visible"]) || $page["confirmmail_footer_visible"]){ ?><textarea<?php if(strlen($page["confirmmail_footer_attribute"]["name"])){ ?> name="<?php echo $page["confirmmail_footer_attribute"]["name"]; ?>"<?php } ?> style="width:96%;padding:5px 2%;"<?php if($page["confirmmail_footer_attribute"]["disabled"]){ ?> disabled="<?php echo $page["confirmmail_footer_attribute"]["disabled"]; ?>"<?php } ?><?php if($page["confirmmail_footer_attribute"]["readonly"]){ ?> readonly="<?php echo $page["confirmmail_footer_attribute"]["readonly"]; ?>"<?php } ?>><?php echo $page["confirmmail_footer"]; ?></textarea><?php } ?>

		</td>
	</tr>
</table>

	<table class="button_table">
		<tr class="button_table_row">
			<td>
				<button name="confirmmail" type="submit">保存</button>
			</td>
		</tr>
	</table>

</form><?php } ?>

</div>

<a name="design_form"></a>
<h2>デザイン設定</h2>
<div class="table_container">
<?php if(!isset($page["design_form_visible"]) || $page["design_form_visible"]){ ?><?php $design_form = $page["design_form"]; ?><form<?php if(strlen($page["design_form_attribute"]["action"])){ ?> action="<?php echo $page["design_form_attribute"]["action"]; ?>"<?php } ?><?php if(strlen($page["design_form_attribute"]["method"])){ ?> method="<?php echo $page["design_form_attribute"]["method"]; ?>"<?php } ?><?php if($page["design_form_attribute"]["disabled"]){ ?> disabled="<?php echo $page["design_form_attribute"]["disabled"]; ?>"<?php } ?>><input type="hidden" name="soy2_token" value="<?php echo soy2_get_token(); ?>">
<table class="form_table list">
	<col style="width:200px" />
	<tr>
		<th>
			デザイン
		</th>
		<td>
			<?php if(!isset($page["design_theme_visible"]) || $page["design_theme_visible"]){ ?><select<?php if(strlen($page["design_theme_attribute"]["name"])){ ?> name="<?php echo $page["design_theme_attribute"]["name"]; ?>"<?php } ?><?php if($page["design_theme_attribute"]["disabled"]){ ?> disabled="<?php echo $page["design_theme_attribute"]["disabled"]; ?>"<?php } ?><?php if($page["design_theme_attribute"]["readonly"]){ ?> readonly="<?php echo $page["design_theme_attribute"]["readonly"]; ?>"<?php } ?><?php if($page["design_theme_attribute"]["multiple"]){ ?> multiple="<?php echo $page["design_theme_attribute"]["multiple"]; ?>"<?php } ?>><?php echo $page["design_theme"]; ?></select><?php } ?>

		</td>
	</tr>
	<tr>
		<th>
			スタイルシート
		</th>
		<td>
			<?php if(!isset($page["design_notoutput_stylesheet_visible"]) || $page["design_notoutput_stylesheet_visible"]){ ?><input<?php if(strlen($page["design_notoutput_stylesheet_attribute"]["name"])){ ?> name="<?php echo $page["design_notoutput_stylesheet_attribute"]["name"]; ?>"<?php } ?><?php if(strlen($page["design_notoutput_stylesheet_attribute"]["value"])){ ?> value="<?php echo $page["design_notoutput_stylesheet_attribute"]["value"]; ?>"<?php } ?> type="hidden"<?php if($page["design_notoutput_stylesheet_attribute"]["disabled"]){ ?> disabled="<?php echo $page["design_notoutput_stylesheet_attribute"]["disabled"]; ?>"<?php } ?><?php if($page["design_notoutput_stylesheet_attribute"]["readonly"]){ ?> readonly="<?php echo $page["design_notoutput_stylesheet_attribute"]["readonly"]; ?>"<?php } ?>><?php } ?>

			<?php if(!isset($page["design_isoutput_stylesheet_visible"]) || $page["design_isoutput_stylesheet_visible"]){ ?><input<?php if(strlen($page["design_isoutput_stylesheet_attribute"]["name"])){ ?> name="<?php echo $page["design_isoutput_stylesheet_attribute"]["name"]; ?>"<?php } ?><?php if(strlen($page["design_isoutput_stylesheet_attribute"]["value"])){ ?> value="<?php echo $page["design_isoutput_stylesheet_attribute"]["value"]; ?>"<?php } ?> type="checkbox"<?php if($page["design_isoutput_stylesheet_attribute"]["disabled"]){ ?> disabled="<?php echo $page["design_isoutput_stylesheet_attribute"]["disabled"]; ?>"<?php } ?><?php if($page["design_isoutput_stylesheet_attribute"]["readonly"]){ ?> readonly="<?php echo $page["design_isoutput_stylesheet_attribute"]["readonly"]; ?>"<?php } ?><?php if(strlen($page["design_isoutput_stylesheet_attribute"]["id"])){ ?> id="<?php echo $page["design_isoutput_stylesheet_attribute"]["id"]; ?>"<?php } ?><?php if($page["design_isoutput_stylesheet_attribute"]["checked"]){ ?> checked="<?php echo $page["design_isoutput_stylesheet_attribute"]["checked"]; ?>"<?php } ?>><?php if(strlen($page["design_isoutput_stylesheet"])>0){ ?><label for="<?php echo $page["design_isoutput_stylesheet_attribute"]["id"]; ?>"><?php echo $page["design_isoutput_stylesheet"]; ?></label><?php } ?><?php } ?>

		</td>
	</tr>
</table>

	<table class="button_table">
		<tr class="button_table_row">
			<td>
				<button name="design" type="submit">保存</button>
			</td>
		</tr>
	</table>
	
</form><?php } ?>

</div>

<a name="connect_form"></a>
<h2>SOY Shop連携</h2>
<div class="table_container">
<?php if(!isset($page["check_version_visible"]) || $page["check_version_visible"]){ ?><p class="error">SOY Shopのバージョンが1.8.0より古いため、連携機能は使えません</p><?php } ?>

<?php if(!isset($page["connect_form_visible"]) || $page["connect_form_visible"]){ ?><?php $connect_form = $page["connect_form"]; ?><form<?php if(strlen($page["connect_form_attribute"]["action"])){ ?> action="<?php echo $page["connect_form_attribute"]["action"]; ?>"<?php } ?><?php if(strlen($page["connect_form_attribute"]["method"])){ ?> method="<?php echo $page["connect_form_attribute"]["method"]; ?>"<?php } ?><?php if($page["connect_form_attribute"]["disabled"]){ ?> disabled="<?php echo $page["connect_form_attribute"]["disabled"]; ?>"<?php } ?>><input type="hidden" name="soy2_token" value="<?php echo soy2_get_token(); ?>">
<table class="form_table list">
	<col style="width:200px" />
	<tr>
		<th>
			SOY Shopの連携
		</th>
		<td>
			ショップ名 : 
			<?php if(!isset($page["connect_sites_visible"]) || $page["connect_sites_visible"]){ ?><select<?php if(strlen($page["connect_sites_attribute"]["name"])){ ?> name="<?php echo $page["connect_sites_attribute"]["name"]; ?>"<?php } ?><?php if($page["connect_sites_attribute"]["disabled"]){ ?> disabled="<?php echo $page["connect_sites_attribute"]["disabled"]; ?>"<?php } ?><?php if($page["connect_sites_attribute"]["readonly"]){ ?> readonly="<?php echo $page["connect_sites_attribute"]["readonly"]; ?>"<?php } ?><?php if($page["connect_sites_attribute"]["multiple"]){ ?> multiple="<?php echo $page["connect_sites_attribute"]["multiple"]; ?>"<?php } ?>>
				<option value="0">連携しない</option>
			<?php echo $page["connect_sites"]; ?></select><?php } ?>
<br />
			※お問い合わせユーザの情報がSOY Shopの顧客名簿に登録されます。<br />(要SOY Mail連携)<br />
			※SOY Shopの顧客情報を取得し、各カラムに値を挿入します。<br />(要SOY Shop連携)
		</td>
	</tr>
</table>

	<table class="button_table">
		<tr class="button_table_row">
			<td>
				<button name="connect" type="submit">保存</button>
			</td>
		</tr>
	</table>
	
</form><?php } ?>


</div>