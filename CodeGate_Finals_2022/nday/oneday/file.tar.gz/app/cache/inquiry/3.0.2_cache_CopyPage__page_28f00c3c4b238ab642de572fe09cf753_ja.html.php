<?php /* created 2022-11-05 09:16:33 */ ?>
<?php $page = HTMLPage::getPage(); ?>
<div class="functions">
	<div class="function">
		<a href="/app/index.php/inquiry/Form">戻る</a>
	</div>
	
	<br style="clear:both;" />
</div>

<div style="padding:0px 20px;">

<h1>フォームの複製</h1>

<div class="table_container">
	<?php if(!isset($page["create_form_visible"]) || $page["create_form_visible"]){ ?><?php $create_form = $page["create_form"]; ?><form<?php if(strlen($page["create_form_attribute"]["action"])){ ?> action="<?php echo $page["create_form_attribute"]["action"]; ?>"<?php } ?><?php if(strlen($page["create_form_attribute"]["method"])){ ?> method="<?php echo $page["create_form_attribute"]["method"]; ?>"<?php } ?><?php if($page["create_form_attribute"]["disabled"]){ ?> disabled="<?php echo $page["create_form_attribute"]["disabled"]; ?>"<?php } ?>><input type="hidden" name="soy2_token" value="<?php echo soy2_get_token(); ?>">
	
	<?php if(!isset($page["error_visible"]) || $page["error_visible"]){ ?><div><?php echo $page["error"]; ?></div><?php } ?>

	
	<table class="form_table list">
		<col style="width:200px" />
		
		<tr>
			<th>
				コピー元フォーム
			</th>
			<td>
				<?php if(!isset($page["form_list_visible"]) || $page["form_list_visible"]){ ?><select<?php if(strlen($page["form_list_attribute"]["name"])){ ?> name="<?php echo $page["form_list_attribute"]["name"]; ?>"<?php } ?><?php if($page["form_list_attribute"]["disabled"]){ ?> disabled="<?php echo $page["form_list_attribute"]["disabled"]; ?>"<?php } ?><?php if($page["form_list_attribute"]["readonly"]){ ?> readonly="<?php echo $page["form_list_attribute"]["readonly"]; ?>"<?php } ?><?php if($page["form_list_attribute"]["multiple"]){ ?> multiple="<?php echo $page["form_list_attribute"]["multiple"]; ?>"<?php } ?>><?php echo $page["form_list"]; ?></select><?php } ?>

			</td>
		</tr>
		
		
		<tr>
			<th>
				フォーム名
			</th>
			<td>
				<?php if(!isset($page["form_name_visible"]) || $page["form_name_visible"]){ ?><input<?php if(strlen($page["form_name_attribute"]["name"])){ ?> name="<?php echo $page["form_name_attribute"]["name"]; ?>"<?php } ?><?php if(strlen($page["form_name_attribute"]["value"])){ ?> value="<?php echo $page["form_name_attribute"]["value"]; ?>"<?php } ?> class="text"<?php if($page["form_name_attribute"]["disabled"]){ ?> disabled="<?php echo $page["form_name_attribute"]["disabled"]; ?>"<?php } ?><?php if($page["form_name_attribute"]["readonly"]){ ?> readonly="<?php echo $page["form_name_attribute"]["readonly"]; ?>"<?php } ?>><?php } ?>

			</td>
		</tr>
		
		<tr>
			<th>
				フォームID(半角英数字のみ)
			</th>
			<td>
				<?php if(!isset($page["form_id_visible"]) || $page["form_id_visible"]){ ?><input<?php if(strlen($page["form_id_attribute"]["name"])){ ?> name="<?php echo $page["form_id_attribute"]["name"]; ?>"<?php } ?><?php if(strlen($page["form_id_attribute"]["value"])){ ?> value="<?php echo $page["form_id_attribute"]["value"]; ?>"<?php } ?> class="text"<?php if($page["form_id_attribute"]["disabled"]){ ?> disabled="<?php echo $page["form_id_attribute"]["disabled"]; ?>"<?php } ?><?php if($page["form_id_attribute"]["readonly"]){ ?> readonly="<?php echo $page["form_id_attribute"]["readonly"]; ?>"<?php } ?>><?php } ?>

			</td>
		</tr>
		
	</table>
	
	<table class="button_table">
		<tr class="button_table_row">
			<td>
				<button type="submit">複製</button>
			</td>
		</tr>
	</table>
	
	</form><?php } ?>

</div>			

</div>