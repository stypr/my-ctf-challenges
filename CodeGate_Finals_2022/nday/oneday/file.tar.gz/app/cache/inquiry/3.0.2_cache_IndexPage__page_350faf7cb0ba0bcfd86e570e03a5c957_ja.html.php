<?php /* created 2022-11-05 09:14:08 */ ?>
<?php $page = HTMLPage::getPage(); ?>
<div style="padding:4px 20px;">

<h1>フォーム</h1>

	<div class="table_container">
		<table class="nowrap list">
			<thead>
				<tr>
					<th class="short">ID</th>
					<th class="middle">名前</th>
					<th class="short">件数 (未読)</th>	
					<th class="long"></th>
				</tr>
			</thead>
			<tbody>
				<?php if(!isset($page["form_list_visible"]) || $page["form_list_visible"]){ ?><?php $form_list_counter = -1;foreach($page["form_list"] as $key => $form_list){ $form_list_counter++; ?>
				<tr>
					<?php if(!isset($form_list["formId_visible"]) || $form_list["formId_visible"]){ ?><td><?php echo $form_list["formId"]; ?></td><?php } ?>

					<?php if(!isset($form_list["name_visible"]) || $form_list["name_visible"]){ ?><td><?php echo $form_list["name"]; ?></td><?php } ?>

					<td><?php if(!isset($form_list["inquiry_link_visible"]) || $form_list["inquiry_link_visible"]){ ?><?php if(strlen($form_list["inquiry_link_attribute"]["href"])>0){ ?><a<?php if(strlen($form_list["inquiry_link_attribute"]["href"])){ ?> href="<?php echo $form_list["inquiry_link_attribute"]["href"]; ?>"<?php } ?>><?php } ?><?php echo $form_list["inquiry_link"]; ?><?php if(strlen($form_list["inquiry_link_attribute"]["href"])>0){ ?></a><?php } ?><?php } ?>
 <?php if(!isset($form_list["unread_inquiry_link_visible"]) || $form_list["unread_inquiry_link_visible"]){ ?><?php if(strlen($form_list["unread_inquiry_link_attribute"]["href"])>0){ ?><a<?php if(strlen($form_list["unread_inquiry_link_attribute"]["style"])){ ?> style="<?php echo $form_list["unread_inquiry_link_attribute"]["style"]; ?>"<?php } ?><?php if(strlen($form_list["unread_inquiry_link_attribute"]["href"])){ ?> href="<?php echo $form_list["unread_inquiry_link_attribute"]["href"]; ?>"<?php } ?>><?php } ?><?php echo $form_list["unread_inquiry_link"]; ?><?php if(strlen($form_list["unread_inquiry_link_attribute"]["href"])>0){ ?></a><?php } ?><?php } ?>
</td>	
					<td>
						<?php if(!isset($form_list["design_link_visible"]) || $form_list["design_link_visible"]){ ?><?php if(strlen($form_list["design_link_attribute"]["href"])>0){ ?><a<?php if(strlen($form_list["design_link_attribute"]["href"])){ ?> href="<?php echo $form_list["design_link_attribute"]["href"]; ?>"<?php } ?>><?php } ?>問い合わせ項目<?php if(strlen($form_list["design_link_attribute"]["href"])>0){ ?></a><?php } ?><?php } ?>
&nbsp;&nbsp;<?php if(!isset($form_list["config_link_visible"]) || $form_list["config_link_visible"]){ ?><?php if(strlen($form_list["config_link_attribute"]["href"])>0){ ?><a<?php if(strlen($form_list["config_link_attribute"]["href"])){ ?> href="<?php echo $form_list["config_link_attribute"]["href"]; ?>"<?php } ?>><?php } ?>設定<?php if(strlen($form_list["config_link_attribute"]["href"])>0){ ?></a><?php } ?><?php } ?>

					</td>
				</tr>
				<?php } ?><?php } ?>

			</tbody>
		</table>
	</div>


<h1>新着問い合わせ</h1>

	<div style="margin-bottom:1.4em;"><?php ob_start(); ?>
	<form method="POST">
	<?php if(!isset($page["trackId_visible"]) || $page["trackId_visible"]){ ?><input<?php if(strlen($page["trackId_attribute"]["name"])){ ?> name="<?php echo $page["trackId_attribute"]["name"]; ?>"<?php } ?><?php if(strlen($page["trackId_attribute"]["value"])){ ?> value="<?php echo $page["trackId_attribute"]["value"]; ?>"<?php } ?><?php if(strlen($page["trackId_attribute"]["style"])){ ?> style="<?php echo $page["trackId_attribute"]["style"]; ?>"<?php } ?><?php if(strlen($page["trackId_attribute"]["onfocus"])){ ?> onfocus="<?php echo $page["trackId_attribute"]["onfocus"]; ?>"<?php } ?><?php if(strlen($page["trackId_attribute"]["onblur"])){ ?> onblur="<?php echo $page["trackId_attribute"]["onblur"]; ?>"<?php } ?> type="text"<?php if($page["trackId_attribute"]["disabled"]){ ?> disabled="<?php echo $page["trackId_attribute"]["disabled"]; ?>"<?php } ?><?php if($page["trackId_attribute"]["readonly"]){ ?> readonly="<?php echo $page["trackId_attribute"]["readonly"]; ?>"<?php } ?>><?php } ?>
<input type="submit" value="詳細" />
	</form>
	<?php $_panel_plugin_search_form = ob_get_contents(); ?>
<?php ob_end_clean(); ?>
<?php echo $_panel_plugin_search_form; ?></div>
	<div class="table_container">
		<table class="nowrap list" id="inquiry_list">
			<thead>
				<tr>
					<?php if(!isset($page["form_name_th_visible"]) || $page["form_name_th_visible"]){ ?><th class="short">フォーム</th><?php } ?>

					<th class="short">受付番号</th>
					<th class="long">内容</th>	
					<th class="short">投稿日</th>
				</tr>
			</thead>
			<tbody>
				<?php if(!isset($page["inquiry_list_visible"]) || $page["inquiry_list_visible"]){ ?><?php $inquiry_list_counter = -1;foreach($page["inquiry_list"] as $key => $inquiry_list){ $inquiry_list_counter++; ?>
				<?php if(!isset($inquiry_list["inquiry_item_visible"]) || $inquiry_list["inquiry_item_visible"]){ ?><tr<?php if(strlen($inquiry_list["inquiry_item_attribute"]["style"])){ ?> style="<?php echo $inquiry_list["inquiry_item_attribute"]["style"]; ?>"<?php } ?><?php if(strlen($inquiry_list["inquiry_item_attribute"]["onclick"])){ ?> onclick="<?php echo $inquiry_list["inquiry_item_attribute"]["onclick"]; ?>"<?php } ?>>
					<?php if(!isset($inquiry_list["form_name_td_visible"]) || $inquiry_list["form_name_td_visible"]){ ?><td class="short"><?php if(!isset($inquiry_list["form_name_visible"]) || $inquiry_list["form_name_visible"]){ ?><?php if(strlen($inquiry_list["form_name_attribute"]["href"])>0){ ?><a<?php if(strlen($inquiry_list["form_name_attribute"]["href"])){ ?> href="<?php echo $inquiry_list["form_name_attribute"]["href"]; ?>"<?php } ?>><?php } ?><?php echo $inquiry_list["form_name"]; ?><?php if(strlen($inquiry_list["form_name_attribute"]["href"])>0){ ?></a><?php } ?><?php } ?>
</td><?php } ?>

					<td class="short"><?php if(!isset($inquiry_list["traking_number_visible"]) || $inquiry_list["traking_number_visible"]){ ?><?php if(strlen($inquiry_list["traking_number_attribute"]["href"])>0){ ?><a<?php if(strlen($inquiry_list["traking_number_attribute"]["href"])){ ?> href="<?php echo $inquiry_list["traking_number_attribute"]["href"]; ?>"<?php } ?>><?php } ?><?php echo $inquiry_list["traking_number"]; ?><?php if(strlen($inquiry_list["traking_number_attribute"]["href"])>0){ ?></a><?php } ?><?php } ?>
</td>
					<td class="long"><?php if(!isset($inquiry_list["content_visible"]) || $inquiry_list["content_visible"]){ ?><?php if(strlen($inquiry_list["content_attribute"]["href"])>0){ ?><a<?php if(strlen($inquiry_list["content_attribute"]["title"])){ ?> title="<?php echo $inquiry_list["content_attribute"]["title"]; ?>"<?php } ?><?php if(strlen($inquiry_list["content_attribute"]["href"])){ ?> href="<?php echo $inquiry_list["content_attribute"]["href"]; ?>"<?php } ?>><?php } ?><?php echo $inquiry_list["content"]; ?><?php if(strlen($inquiry_list["content_attribute"]["href"])>0){ ?></a><?php } ?><?php } ?>
</td>
					<td class="short"><?php if(!isset($inquiry_list["create_date_visible"]) || $inquiry_list["create_date_visible"]){ ?><span><?php echo $inquiry_list["create_date"]; ?></span><?php } ?>
</td>
				</tr><?php } ?>

				<?php } ?><?php } ?>

	
				<?php if(!isset($page["no_inquiry_visible"]) || $page["no_inquiry_visible"]){ ?>
				<tr>
				<?php if(!isset($page["no_inquiry_text_visible"]) || $page["no_inquiry_text_visible"]){ ?><td<?php if(strlen($page["no_inquiry_text_attribute"]["colspan"])){ ?> colspan="<?php echo $page["no_inquiry_text_attribute"]["colspan"]; ?>"<?php } ?>>
					新着の問い合わせはありません。
				</td><?php } ?>

				</tr>
				<?php } ?>

				
			</tbody>
		</table>
	</div>

<!-- 
	<hr />
	
	<div style="margin-bottom:10px;">
		<a href="/app/index.php/inquiry/Template">テンプレートの編集</a>
	</div>
 -->

</div>