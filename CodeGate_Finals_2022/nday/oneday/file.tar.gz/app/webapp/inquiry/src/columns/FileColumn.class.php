<?php

class FileColumn extends SOYInquiry_ColumnBase{

	private $extensions = "jpg,jpeg,gif,png";
	private $uploadsize = 500;	//KB
	private $uploadcount = 1;

	const KB_SIZE = 1024;

	/**
	 * ユーザに表示するようのフォーム
	 */
	function getForm($attr = array()){

		$uploadcount = min($this->uploadcount, 1) ;

		$values = $this->getValue();

		$html = array();

		//アップロードされていた場合
		$numberOfUploadedFiles = 0;
		if(is_array($values)){
			$numberOfUploadedFiles = count($values);
			$new_value = base64_encode(serialize($values));
			$html[] = '<input type="hidden" name="data['.$this->getColumnId().'][hash]" value="'.$new_value.'" >';

			foreach($values as $value){
				if(isset($value["name"]) && strlen($value["name"])){
					$html[] = htmlspecialchars($value["name"], ENT_QUOTES, "UTF-8") . " (".CMSUtil::getFilesize($value["size"]).")&nbsp;";
					$html[] = "<input type=\"checkbox\" name=\"data[".$this->getColumnId()."][delete][]\" value=\"".htmlspecialchars($value["key"], ENT_QUOTES, "UTF-8")."\" id=\"".htmlspecialchars($value["key"], ENT_QUOTES, "UTF-8")."\" >";
					$html[] = "<label for=\"".htmlspecialchars($value["key"], ENT_QUOTES, "UTF-8")."\" >削除</label><br>";
				}
			}
		}

		$attributes = array();
		foreach($attr as $key => $value){
			$attributes[] = htmlspecialchars($key, ENT_QUOTES, "UTF-8") . "=\"".htmlspecialchars($value, ENT_QUOTES, "UTF-8")."\"";
		}

		for($i = 0; $i < $this->uploadcount - $numberOfUploadedFiles; $i++){
			$html[] = "<input type=\"file\" name=\"data_".$this->getColumnId()."[]\" value=\"\"" . implode(" ",$attributes) . " >";
		}

		return implode("\n",$html);
	}

	/**
	 * 設定画面で表示する用のフォーム
	 */
	function getConfigForm(){
		$html  = 'アップロード可能なファイルサイズ:<input type="text" name="Column[config][uploadsize]" value="'.htmlspecialchars($this->uploadsize,ENT_QUOTES).'" size="3">KBまで&nbsp;';
		$html .= '<br>';
		$html .= 'サーバーの設定により一度に合計で '.ini_get("post_max_size")." または ".ini_get("upload_max_filesize").' を越えるファイルのアップロードはできません。';
		$html .= '<br>';
		$html .= 'アップロード可能なファイルの拡張子:<input type="text" name="Column[config][extensions]" value="'.htmlspecialchars($this->extensions,ENT_QUOTES).'" style="width:60%;"><br>';
		$html .= 'ファイルの数:<input type="text" name="Column[config][uploadcount]" value="'.htmlspecialchars($this->uploadcount,ENT_QUOTES).'" size="3">&nbsp;';
		return $html;
	}

	/**
	 * 確認画面用
	 */
	function getView(){
		return strtr(htmlspecialchars($this->getContent(), ENT_QUOTES, "UTF-8"), array("\n" => "<br>"));
	}

	/**
	 * データ投入用
	 */
	function getContent(){
		$values = $this->getValue();
		error_log(var_export($values,true));

		if(is_array($values)){
			$html = array();
			foreach($values as $value){
				if(isset($value["name"]) && isset($value["size"])){
					$html[] = $value["name"] . " (".CMSUtil::getFilesize($value["size"]).")";
				}
			}

			return implode("\n",$html);
		}

		return "";
	}

	/**
	 * onSend
	 */
	function onSend($inquiry){

		$values = $this->getValue();

		if(is_array($values)){
			foreach($values as $value){
				$tmp_name = $value["tmp_name"];

				$new_dir = SOY_INQUIRY_UPLOAD_DIR . "/" . $this->getFormId() . "/" . date("Ym") . "/";
				if(!file_exists($new_dir))mkdir($new_dir,0777,true);

				$new_name = str_replace(SOY_INQUIRY_UPLOAD_TEMP_DIR, $new_dir,$tmp_name);

				if(rename($tmp_name,$new_name)){
					$value["filepath"] = str_replace("\\","/",realpath($new_name));
					$value["filepath"] = str_replace(SOY_INQUIRY_UPLOAD_ROOT_DIR,"",$value["filepath"]);
					$this->setValue($value);
				}
			}

			//コメントに追加する
			$content = "";
			$content .= '<a href="'.htmlspecialchars($value["filepath"],ENT_QUOTES,"UTF-8").'">'.htmlspecialchars($value["name"],ENT_QUOTES,"UTF-8").'</a>';
			$content .= '&nbsp;'.htmlspecialchars(CMSUtil::getFilesize($value["size"]),ENT_QUOTES,"UTF-8");

			//画像ならプレビューを追加
			$pathinfo = pathinfo($value["filepath"]);
			if(in_array(strtolower($pathinfo["extension"]),array("jpg","jpeg","gif","png"))){
				$content .= '<br><img src="'.htmlspecialchars($value["filepath"],ENT_QUOTES,"UTF-8").'">';
			}

			$commentDAO = SOY2DAOFactory::create("SOYInquiry_CommentDAO");
			$comment = new SOYInquiry_Comment();

			$comment->setInquiryId($inquiry->getId());
			$comment->setTitle($this->getLabel());
			$comment->setAuthor("-");
			$comment->setContent($content);

			$commentDAO->insert($comment);

		}

	}

	/**
	 * 値が正常かどうかチェック
	 */
	function validate(){

		$id = $this->getColumnId();
		$uploads = array();

		$value = $this->getValue();
		$tmp = is_array($value) && isset($value["hash"]) && strlen($value["hash"]) ? @unserialize(base64_decode($value["hash"])) : null ;

		//既存の値
		if(is_array($tmp) && count($tmp)){
			$uploads = $tmp;
		}

		//削除
		if(is_array($value) && isset($value["delete"]) && is_array($value["delete"]) && count($value["delete"])){
			foreach($value["delete"] as $keyForDelete){
				foreach($uploads as $key => $upload){
					if($upload["key"] == $keyForDelete){
						unset($uploads[$key]);
						if(file_exists($upload["tmp_name"])) unlink($upload["tmp_name"]);
					}
				}
			}
			$uploads = array_values($uploads);
		}

		//新規または追加
		$errors = array();
		if(isset($_FILES) && is_array($_FILES) && count($_FILES)){
			foreach($_FILES["data_".$id]["name"] as $key => $value){

				$name = @$_FILES["data_".$id]["name"][$key];
				$type = @$_FILES["data_".$id]["type"][$key];
				$tmp_name = @$_FILES["data_".$id]["tmp_name"][$key];
				$error = @$_FILES["data_".$id]["error"][$key];
				$size = @$_FILES["data_".$id]["size"][$key];

				//アップロードされていない場合は次へ
				if(strlen($name)<1) continue;

				$pathinfo = pathinfo($name);

				//拡張子チェック：小文字で比較する
				$extensions = explode(",", strtolower($this->extensions));
				if(strlen($this->extensions) && count($extensions) && !in_array(strtolower($pathinfo["extension"]), $extensions)){
					$errors[] = $this->getLabel()."の".$name."はアップロードできません。";
					continue;
				}

				//ファイルサイズチェック
				if(($this->uploadsize * self::KB_SIZE)< $size){
					$errors[] = $this->getLabel()."の".$name."はファイルサイズが大きすぎます。";
					continue;
				}

				//一時的にアップロードする
				if(!file_exists(SOY_INQUIRY_UPLOAD_TEMP_DIR)){
					mkdir(SOY_INQUIRY_UPLOAD_TEMP_DIR);
				}
				$path_to = SOY_INQUIRY_UPLOAD_TEMP_DIR . md5($name . microtime().$id) . "." . $pathinfo["extension"];
				$result = move_uploaded_file($tmp_name,$path_to);

				//一時アップロードに失敗した場合
				if(!$result){
					$errors[] = $this->getLabel()."の".$name."アップロードに失敗しました。";
					continue;
				}

				//もしアップロードされているのであれば値を保存する
				if(file_exists($path_to)){
					$uploads[] = array(
						"name" => $name,
						"type" => $type,
						"tmp_name" => $path_to,
						"error" => $error,
						"size" => $size,
						"key" =>  md5($name.mt_rand().microtime().$id)
					);
				}
			}
		}

		if(count($uploads)){
			$_POST["data"][$id]["hash"] = base64_encode(serialize($uploads));
		}
		$this->setValue($uploads);

		if(count($errors)){
			$this->setErrorMessage(strtr(htmlspecialchars(implode("\n",$errors), "UTF-8",ENT_QUOTES), array("\n" => "<br>")));
			return false;
		}

		//必須チェック
		if($this->getIsRequire() && !count($uploads)){
			$this->setErrorMessage($this->getLabel()."を指定してください。");
			return false;
		}

	}

	/**
	 * 保存された設定値を渡す
	 */
	function setConfigure($config){
		SOYInquiry_ColumnBase::setConfigure($config);

		$this->uploadsize  = (isset($config["uploadsize"]) && is_numeric($config["uploadsize"])) ? (int)$config["uploadsize"] : 500;
		$this->extensions = (isset($config["extensions"]) && strlen($config["extensions"])) ? $config["extensions"] : "jpg,gif,png";
		$this->uploadcount = (isset($config["uploadcount"]) && strlen($config["uploadcount"])) ? $config["uploadcount"] : 1;
	}

	function getConfigure(){
		$config = parent::getConfigure();
		$config["uploadsize"] = $this->uploadsize;
		$config["extensions"] = $this->extensions;
		$config["uploadcount"] = $this->uploadcount;
		return $config;
	}

	function getLinkagesSOYMailTo() {
		return array(
			SOYMailConverter::SOYMAIL_NONE  => "連携しない",
		);
	}
}
?>