<form method="post" enctype="multipart/form-data">

<table class="soy_inquiry_message" id="soy_inquiry_message_information">
<tr>
	<td>
	<?php $message = $config->getMessage(); echo $message["information"]; ?>
	</td>
</tr>
</table>

<table id="inquiry_form">
<?php $counter = 0; ?>
<?php $columnCount = count($columns); ?>
<?php foreach($columns as $column){
	
	/**
	 * @プライバシーポリシーは必ず一行目で別テーブルで表示する
	 */
	
	$id = $column->getId();
	$obj = $column->getColumn();
	$label = $obj->getLabel();
	$annotation = $obj->getAnnotation();
		
	$class = array();
	if($column->getRequire()) $class[] = "require";
	if(isset($errors[$id])) $class[] = "error";
	
	if(count($class)){
		echo "<tr class=\"".implode(" ",$class)."\">";	
	}else{
		echo "<tr>";
	}
	
	if(strlen($label)>0){
		echo "<th>";
		if($column->getRequire()){
			echo "*";
		}
		echo $label;
		echo "</th>\n";
		echo "<td>\n";
	    echo "\t".$obj->getForm();
	    if(isset($annotation) && strlen($annotation)){
	    	echo "&nbsp;".$annotation;
	    }
	    if(isset($errors[$id])){
	    	echo "<br/>";
	    	echo "<span class=\"error_message\">";
	    	echo $errors[$id];
	    	echo "</span>";
	    } 
	    echo "\n</td>\n";
	}else{
		echo "<td colspan=\"2\">\n";
	    echo "\t".$obj->getForm();
	    if(isset($errors[$id])){
	    	echo "<br/>";
	    	echo "<span class=\"error_message\">";
	    	echo $errors[$id];
	    	echo "</span>";
		} 
	    echo "\n</td>\n";
	}
    
	echo "</tr>\n";
	
	//一行目はプライバシーポリシー
	if($column->getType()==="PrivacyPolicy" && $counter === 0){
		//別テーブルを用意
		echo "</table>\n";
		echo "<table id=\"inquiry_form\">\n";
	}
	
	//最後の行でもプライバシーポリシーを別テーブルにできる
	$count = $counter + 1;
	if($column->getType()==="PrivacyPolicy" && $count === $columnCount){
		//別テーブルを用意
		echo "</table>\n";
		echo "<table id=\"inquiry_form\">\n";
	}
	
	$counter++;
}
?>
</table>

<table>
	<tr>
		<td style="text-align:center;border-style:none;">
			<input name="data[hash]" type="hidden" value="<?php echo $random_hash; ?>" />
			<input name="confirm" type="submit" value="入力内容の確認" />
		</td>
	</tr>
</table>

</form>