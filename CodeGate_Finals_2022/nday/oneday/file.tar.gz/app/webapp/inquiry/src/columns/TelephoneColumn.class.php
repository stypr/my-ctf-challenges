<?php

class TelephoneColumn extends SOYInquiry_ColumnBase{

	private $size1;
	private $size2;
	private $size3;

	private $attribute1;
	private $attribute2;
	private $attribute3;

	//<input type="***">
	private $inputType = "text";

	/**
	 * ユーザに表示するようのフォーム
	 */
	function getForm($attr = array()){

		$value = $this->getValue();

		$inputType = htmlspecialchars($this->inputType, ENT_QUOTES, "UTF-8");

		$html = array();
		$html[] = "<input type=\"".$inputType."\" name=\"data[".$this->getColumnId()."][]\" value=\"".$value[0]."\" size=\"".$this->size1."\" ".$this->getFormAttribute($this->attribute1)." />";
		$html[] = "-";
		$html[] = "<input type=\"".$inputType."\" name=\"data[".$this->getColumnId()."][]\" value=\"".$value[1]."\" size=\"".$this->size2."\" ".$this->getFormAttribute($this->attribute2)." />";
		$html[] = "-";
		$html[] = "<input type=\"".$inputType."\" name=\"data[".$this->getColumnId()."][]\" value=\"".$value[2]."\" size=\"".$this->size3."\" ".$this->getFormAttribute($this->attribute3)." />";

		return implode("\n",$html);
	}

	function getFormAttribute($attribute){
		$value = "";

		if(isset($attribute) && strlen($attribute) > 0){
			$value = str_replace("&quot;","\"",$attribute);
		}

		return $value;
	}

	/**
	 * 個々のフォームのサイズを変更するフォーム
	 */
	function getConfigForm(){

		$html  = '幅:<input type="text" name="Column[config][size1]" value="'.$this->size1.'" size="3" />';
		$html .= '-<input type="text" name="Column[config][size2]" value="'.$this->size2.'" size="3" />';
		$html .= '-<input type="text" name="Column[config][size3]" value="'.$this->size3.'" size="3" />';

		$html .= "<br />";

		$html .= '<label for="Column[config][attribute1]'.$this->getColumnId().'">属性1:</label>';
		$html .= '<input  id="Column[config][attribute1]'.$this->getColumnId().'" name="Column[config][attribute1]" type="text" value="'.$this->attribute1.'" style="width:90%;" /><br />';
		$html .= '<label for="Column[config][attribute2]'.$this->getColumnId().'">属性2:</label>';
		$html .= '<input  id="Column[config][attribute2]'.$this->getColumnId().'" name="Column[config][attribute2]" type="text" value="'.$this->attribute2.'" style="width:90%;" /><br />';
		$html .= '<label for="Column[config][attribute3]'.$this->getColumnId().'">属性3:</label>';
		$html .= '<input  id="Column[config][attribute3]'.$this->getColumnId().'" name="Column[config][attribute3]" type="text" value="'.$this->attribute3.'" style="width:90%;" /><br />';
		$html .= "※記述例：class=\"sample\" title=\"サンプル\"";

		$html .= "<br/>";

		$inputType = (isset($this->inputType) && strlen($this->inputType) > 0) ? htmlspecialchars($this->inputType,ENT_QUOTES,"UTF-8") : "text";
		$html .= '<label for="Column[config][inputType]'.$this->getColumnId().'">type:</label>';
		$html .= '<input id="Column[config][inputType]'.$this->getColumnId().'" name="Column[config][inputType]" type="text" value="'.$inputType.'" style="width:10%;" /><br />';
		$html .= "※入力例: text, email, tel, number等。";

		return $html;
	}

	/**
	 * 保存された設定値を渡す
	 */
	function setConfigure($config){
		SOYInquiry_ColumnBase::setConfigure($config);
		$this->size1 = (isset($config["size1"]) && is_numeric($config["size1"])) ? (int)$config["size1"] : null;
		$this->size2 = (isset($config["size2"]) && is_numeric($config["size2"])) ? (int)$config["size2"] : null;
		$this->size3 = (isset($config["size3"]) && is_numeric($config["size3"])) ? (int)$config["size3"] : null;
		$this->attribute1 = (isset($config["attribute1"])) ? str_replace("\"","&quot;",$config["attribute1"]) : null;
		$this->attribute2 = (isset($config["attribute2"])) ? str_replace("\"","&quot;",$config["attribute2"]) : null;
		$this->attribute3 = (isset($config["attribute3"])) ? str_replace("\"","&quot;",$config["attribute3"]) : null;
		$this->inputType = (isset($config["inputType"])) && strlen($config["inputType"]) ? $config["inputType"] : "text";
	}

	function getConfigure(){
		$config = parent::getConfigure();
		$config["size1"] = $this->size1;
		$config["size2"] = $this->size2;
		$config["size3"] = $this->size3;
		$config["attribute1"] = $this->attribute1;
		$config["attribute2"] = $this->attribute2;
		$config["attribute3"] = $this->attribute3;
		$config["inputType"] = $this->inputType;
		return $config;
	}

	function validate(){
		$value = $this->getValue();

		if(empty($value) || strlen(implode("",$value))<1){
			$this->setValue(array("", "", ""));

			if($this->getIsRequire()){
				$this->setErrorMessage($this->getLabel()."を入力してください。");
				return false;
			}

			return true;
		}

		if( (strlen($value[0]) + strlen($value[1]) + strlen($value[2]) > 0)
		 && (strlen($value[0]) * strlen($value[1]) * strlen($value[2]) == 0)
		){
			$this->errorMessage = "電話番号の書式が不正です。";
			return false;
		}
	}

	function getErrorMessage(){
		return $this->errorMessage;
	}

	/**
	 * 確認画面で呼び出す
	 */
	function getView(){
		$value = $this->getValue();
		if(empty($value)){
			return "";
		}
		return htmlspecialchars(implode("-",$value), ENT_QUOTES, "UTF-8");
	}

	function getReplacement() {
		return (strlen($this->replacement) == 0) ? "#TELEPHONE#" : $this->replacement;
	}

}
?>