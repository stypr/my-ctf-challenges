<?php

class DetailPage extends WebPage{

	var $id;
	
	function doPost(){
		
		if(isset($_POST["add_comment"])){
			
			$commenDAO = SOY2DAOFactory::create("SOYInquiry_CommentDAO");
			
			$comment = SOY2::cast("SOYInquiry_Comment",(object)$_POST["Memo"]);
			$comment->setInquiryId($this->id);
			
			$comment->setContent(htmlspecialchars($comment->getContent()));
			
			$commenDAO->insert($comment);
						
			CMSApplication::jump("Inquiry.Detail." . $this->id . "#comment");
		}
		
	}

    function __construct($args) {
    	$this->id = @$args[0];
    	
    	parent::__construct();
    	
    	$dao = SOY2DAOFactory::create("SOYInquiry_InquiryDAO");
    	$formDao = SOY2DAOFactory::create("SOYInquiry_FormDAO");
    	
    	try{
    		$inquiry = $dao->getById($this->id);
    		
    		//未読の場合
    		if($inquiry->isUnread()){
    			$dao->setReaded($inquiry->getId());
    		}
    		
    	}catch(Exception $e){
    		CMSApplication::jump("Inquiry");
    	}
    	
    	try{
    		$form = $formDao->getById($inquiry->getFormId());
    	}catch(Exception $e){
    		$form = new SOYInquiry_Form();
    	}
    	
    	$this->createAdd("create_date","HTMLLabel",array(
    		"text" => date("Y-m-d H:i:s",$inquiry->getCreateDate())
    	));
		$this->createAdd("tracking_number","HTMLLabel",array(
			"text" => $inquiry->getTrackingNumber()
		));
 		$this->createAdd("inquiry_id","HTMLLabel",array(
			"text" => $inquiry->getId()
		));
    	
    	$this->createAdd("form_name","HTMLLabel",array(
			"text" => (strlen($form->getName())) ? $form->getName() : "-"
		));
    	
    	$this->createAdd("content","HTMLLabel",array(
    		"html" => $inquiry->getContent()
    	));
    	
    	//コメントを取得
    	$commenDAO = SOY2DAOFactory::create("SOYInquiry_CommentDAO");
    	$comments = $commenDAO->getByInquiryId($this->id);
    	
    	$this->createAdd("comment_list","CommentList",array(
    		"list" => $comments
    	));
    	
    	//コメントフォーム
    	$this->createAdd("comment_form","HTMLForm");
    	
    	$this->createAdd("memo_title","HTMLInput",array(
    		"name" => "Memo[title]",
    		"value" => ""
    	));
    	
    	$this->createAdd("memo_name","HTMLInput",array(
    		"name" => "Memo[author]",
    		"value" => ""
    	));
    	
    	$this->createAdd("memo_content","HTMLTextArea",array(
    		"name" => "Memo[content]",
    		"value" => ""
    	));
    	
    }
}

class CommentList extends HTMLList{
	
	protected function populateItem($bean){
		
		$this->createAdd("title","HTMLLabel",array(
			"text" => $bean->getTitle()
		));
		
		$this->createAdd("author","HTMLLabel",array(
			"text" => $bean->getAuthor()
		));
		
		$this->createAdd("content","HTMLLabel",array(
			"html" => $bean->getContent()
		));
		
		$this->createAdd("create_date","HTMLLabel",array(
			"text" => date("Y-m-d H:i:s",$bean->getCreateDate())
		));
		
	}
	
}
?>