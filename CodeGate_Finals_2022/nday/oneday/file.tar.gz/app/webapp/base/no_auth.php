<div style="padding:20px;">

<div class="error">権限が無いか、ログインしていないため、
このアプリケーションを使用することが出来ません。</div>

<a href="<?php echo SOY2PageController::createRelativeLink("../admin/"); ?>">CMS管理へ</a>

</div>