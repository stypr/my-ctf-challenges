alter table EntryHistory add column change_is_published TINYINT(1) NOT NULL DEFAULT 0;
