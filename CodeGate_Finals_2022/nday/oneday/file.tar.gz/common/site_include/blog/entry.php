<?php
/*
このブロックは、記事毎ページでご利用いただけます。

記事毎ページの該当記事の内容を出力する際に用いることができます。


<!-- b_block:id="entry" -->
	<div>
		<h2 cms:id="title">ここにはタイトルが入ります。</h2>
			<span cms:id="create_date" cms:format="Y/m/d">2008/03/17</span>
		<div cms:id="content">ここには本文が入ります</div cms:id="content">
		<div cms:id="more">ここには追記が入ります。</div cms:id="more">
			<span cms:id="create_time" cms:format="H:i">17:00</span>
			<a cms:id="comment_link">コメント(<!-- cms:id="comment_count"--><!-- /cms:id="comment_count"-->)</a>
			<a cms:id="trackback_link">トラックバック(<!-- cms:id="trackback_count"--><!-- /cms:id="trackback_count"-->)</a>
		<p>
			<!-- cms:id="category_list" -->
				<a cms:id="category_link"><!-- cms:id="category_name" --><!-- /cms:id="category_name" --></a>
			<!-- /cms:id="category_list" -->
		</p>
	</div>
<!-- /b_block:id="entry" -->
*/
/**
 * 記事の詳細情報を出力します。
 *
 */
function soy_cms_blog_output_entry($page,$entry){

	if(!class_exists("BlogPage_Entry_CategoryList")){
		class BlogPage_Entry_CategoryList extends HTMLList{
			var $categoryPageUri;

			function setCategoryPageUri($uri){
				$this->categoryPageUri = $uri;
			}

			protected function populateItem($entry){

				$this->createAdd("category_link","HTMLLink",array(
					"link"=>$this->categoryPageUri . rawurlencode($entry->getAlias()),
					"soy2prefix"=>"cms"
				));

				$this->createAdd("category_name","CMSLabel",array(
					"text"=>$entry->getBranchName(),
					"soy2prefix"=>"cms"
				));
			}
		}
	}

	if(!class_exists("BlogPage_EntryComponent")){
		/**
		 * 記事を表示するコンポーネント
		 */
		class BlogPage_EntryComponent extends SOYBodyComponentBase{

			var $entryPageUri;
			var $categoryPageUri;
			var $blogLabelId;
			var $categoryLabelList;

			function setCategoryPageUri($uri){
				$this->categoryPageUri = $uri;
			}

			function setEntryPageUri($uri){
				$this->entryPageUri = $uri;
			}

			function setBlogLabelId($blogLabelId){
				$this->blogLabelId = $blogLabelId;
			}

			function setCategoryLabelList($categoryLabelList){
				$this->categoryLabelList = $categoryLabelList;
			}

			function setEntry($entry){
				$link = $this->entryPageUri . rawurlencode($entry->getAlias());

				$this->createAdd("entry_id","CMSLabel",array(
					"text"=>$entry->getId(),
					"soy2prefix"=>"cms"
				));

				$this->createAdd("title","CMSLabel",array(
					"html"=> "<a href=\"$link\">".htmlspecialchars($entry->getTitle(), ENT_QUOTES, "UTF-8")."</a>",
					"soy2prefix"=>"cms"
				));

				$this->createAdd("title_plain","CMSLabel",array(
					"text"=> $entry->getTitle(),
					"soy2prefix"=>"cms"
				));

				//本文
				$content = $entry->getContent();

				$this->createAdd("content","CMSLabel",array(
					"html"=>$content,
					"soy2prefix"=>"cms"
				));

				//追記
				$more = $entry->getMore();

				$this->createAdd("more","CMSLabel",array(
						"html"=> '<a id="more"></a>'.$more,
						"soy2prefix"=>"cms",
				));

				// 2015-07-09追加 1.8.13以降
				$this->addLabel("more_only",array(
					"html"=> $more,
					"soy2prefix"=>"cms",
				));
				$this->addModel("has_more",array(
					"visible"=> strlen(trim($more)),
					"soy2prefix"=>"cms",
				));

				//ページ分割 3.0.1-
				$currentPage = isset($_GET["p"]) && is_numeric($_GET["p"]) && $_GET["p"] > 0 ? $_GET["p"] : 1 ;
				$numberOfPages = 1;

				$contentIsPaginated = ( strpos($content, '<!--nextpage-->') !== false );
				if($contentIsPaginated){
					$paginatedContents = explode('<!--nextpage-->', $content);
					$numberOfPages = count($paginatedContents);
				}else{
					$paginatedContents = array($content);
				}

				$moreIsPaginated = ( strpos($more, '<!--nextpage-->') !== false );
				if($moreIsPaginated){
					$paginatedMores = explode('<!--nextpage-->', $more);
					$numberOfPages = max($numberOfPages, count($paginatedContents));
				}else{
					$paginatedMores = array($more);
				}

				$this->addModel("content_is_paginated",array(
						"visible"=>$contentIsPaginated,
						"soy2prefix"=>"cms"
				));
				$this->addModel("content_is_not_paginated",array(
						"visible"=>!$contentIsPaginated,
						"soy2prefix"=>"cms"
				));
				$this->addLabel("paginated_content",array(
						"html"=>isset($paginatedContents[$currentPage -1]) ? $paginatedContents[$currentPage -1] : "",
						"soy2prefix"=>"cms"
				));

				$this->addModel("more_is_paginated",array(
						"visible"=>$moreIsPaginated,
						"soy2prefix"=>"cms",
				));
				$this->addModel("more_is_not_paginated",array(
						"visible"=>!$moreIsPaginated,
						"soy2prefix"=>"cms",
				));
				$this->addLabel("paginated_more",array(
						"html"=>isset($paginatedMores[$currentPage -1]) ? $paginatedMores[$currentPage -1] : "",
						"soy2prefix"=>"cms"
				));

				$this->addModel("entry_is_paginated",array(
						"visible"=>$contentIsPaginated || $moreIsPaginated,
						"soy2prefix"=>"cms"
				));
				$this->addModel("entry_is_not_paginated",array(
						"visible"=>!( $contentIsPaginated || $moreIsPaginated ),
						"soy2prefix"=>"cms"
				));
				$this->addLabel("current_page",array(
						"text"=> $currentPage,
						"soy2prefix"=>"cms"
				));
				$this->addLabel("pages",array(
						"text"=> $numberOfPages,
						"soy2prefix"=>"cms"
				));
				$this->addLabel("total_pages",array(
						"text"=> $numberOfPages,
						"soy2prefix"=>"cms"
				));
				$this->addModel("is_first_page",array(
						"visible"=> $currentPage == 1,
						"soy2prefix"=>"cms"
				));
				$this->addModel("is_middle_page",array(
						"visible"=> 1 < $currentPage && $currentPage < $numberOfPages,
						"soy2prefix"=>"cms"
				));
				$this->addModel("is_last_page",array(
						"visible"=> $currentPage == $numberOfPages,
						"soy2prefix"=>"cms"
				));

				$this->addLink("next_page_link",array(
					"link"=> ( $currentPage < $numberOfPages ? $link."?p=".($currentPage +1) : ""),
					"soy2prefix"=>"cms"
				));
				$this->addModel("has_next_page",array(
					"visible"=> ($currentPage < $numberOfPages),
					"soy2prefix"=>"cms"
				));

				$this->addLink("prev_page_link",array(
					"link"=> ( $currentPage > 1 ? $link."?p=".($currentPage -1) : ""),
					"soy2prefix"=>"cms"
				));
				$this->addModel("has_prev_page",array(
					"visible"=> ($currentPage > 1),
					"soy2prefix"=>"cms"
				));

				$this->createAdd("page_list","BlogPage_PagerList",array(
					"list"=> range(1,$numberOfPages),
					"current" => $currentPage,
					"url" => $link,
					"soy2prefix"=>"cms"
				));


				$this->createAdd("create_date","DateLabel",array(
					"text"=>$entry->getCdate(),
					"soy2prefix"=>"cms"
				));

				$this->createAdd("create_time","DateLabel",array(
					"text"=>$entry->getCdate(),
					"soy2prefix"=>"cms",
					"defaultFormat"=>"H:i"
				));

				$this->createAdd("entry_link","HTMLLink",array(
					"soy2prefix"=>"cms",
					"link" => $link
				));

				$this->createAdd("more_link","HTMLLink",array(
					"soy2prefix"=>"cms",
					"link" => $link ."#more",
					"visible"=>(strlen($entry->getMore()) != 0)
				));

				$this->createAdd("more_link_no_anchor","HTMLLink",array(
					"soy2prefix"=>"cms",
					"link" => $link,
					"visible"=>(strlen($entry->getMore()) != 0)
				));

				$this->createAdd("trackback_link","HTMLLink",array(
					"soy2prefix"=>"cms",
					"link" => $link ."#trackback_list"
				));

				$this->createAdd("trackback_count","CMSLabel",array(
					"soy2prefix"=>"cms",
					"text" => $entry->getTrackbackCount()
				));

				$this->createAdd("comment_link","HTMLLink",array(
					"soy2prefix"=>"cms",
					"link" => $link ."#comment_list"
				));

				$this->createAdd("comment_count","CMSLabel",array(
					"soy2prefix"=>"cms",
					"text" => $entry->getCommentCount()
				));

				$this->createAdd("category_list","BlogPage_Entry_CategoryList",array(
					"list" => $entry->getLabels(),
					"categoryPageUri" => $this->categoryPageUri,
					"soy2prefix" => "cms"
				));


				CMSPlugin::callEventFunc('onEntryOutput',array("entryId"=>$entry->getId(),"SOY2HTMLObject"=>$this,"entry"=>$entry));

				//Messageの追加
				//$this->addMessagePropertyでは意味がない
				//$this->getParentObject->addMessagePropertyをここでやっても意味がない（parentObjectが入ってない）。$this->_soy2_idも入ってない。
				$this->addMessageProperty("entry_id",'<?php echo $'.$this->_soy2_id.'["entry_id"]; ?>');
				$this->addMessageProperty("title",'<?php echo $'.$this->_soy2_id.'["title_plain"]; ?>');
				$this->addMessageProperty("content",'<?php echo $'.$this->_soy2_id.'["content"]; ?>');
				$this->addMessageProperty("more",'<?php echo $'.$this->_soy2_id.'["more"]; ?>');
				$this->addMessageProperty("create_date",'<?php echo $'.$this->_soy2_id.'["create_date"]; ?>');
				$this->addMessageProperty("entry_link",'<?php echo $'.$this->_soy2_id.'["entry_link_attribute"]["href"]; ?>');
				$this->addMessageProperty("more_link",'<?php echo $'.$this->_soy2_id.'["more_link_attribute"]["href"]; ?>');
				$this->addMessageProperty("trackback_link",'<?php echo $'.$this->_soy2_id.'["trackback_link_attribute"]["href"]; ?>');
				$this->addMessageProperty("comment_link",'<?php echo $'.$this->_soy2_id.'["comment_link_attribute"]["href"]; ?>');
			}

			function getStartTag(){

				if(defined("CMS_PREVIEW_MODE")){
					return parent::getStartTag() . CMSUtil::getEntryHiddenInputHTML('<?php echo $'.$this->_soy2_pageParam.'["'.$this->_soy2_id.'"]["entry_id"]; ?>','<?php echo strip_tags($'.$this->_soy2_pageParam.'["'.$this->_soy2_id.'"]["title"]); ?>');
				}else{
					return parent::getStartTag();
				}
			}

		}
	}

	$page->createAdd("entry","BlogPage_EntryComponent",array(
		"soy2prefix" => "b_block",
		"entryPageUri"=> $page->getEntryPageURL(true),
		"categoryPageUri" => $page->getCategoryPageURL(true),
		"blogLabelId" => $page->page->getBlogLabelId(),
		"categoryLabelList" => $page->page->getCategoryLabelList(),
		"visible" => ($entry->getId()),
		"entry" => $entry
	));
}

/**
 * 次の記事を出力
 * 次の記事が無い場合は表示されない
 *
 * <div b_block:id="next_entry">
 * 	<a cms:id="entry_link"><!-- cms:id="title" --><!--/cms:id="title" --></a>
 * </div b_block:id="next_entry">
 *
 * <div b_block:id="prev_entry">
 * 	<a cms:id="entry_link"><!-- cms:id="title" --><!--/cms:id="title" --></a>
 * </div b_block:id="prev_entry">
 */
function soy_cms_blog_output_entry_navi($page,$next,$prev){

	if(!class_exists("BlogPage_Entry_Navigation")){
		class BlogPage_Entry_Navigation extends SOYBodyComponentBase{

			var $entryPageUri;

			function setEntryPageUri($uri){
				$this->entryPageUri = $uri;
			}

			function setEntry($entry){
				$this->createAdd("title","CMSLabel",array(
					"text" => $entry->getTitle(),
					"soy2prefix" => "cms"
				));

				$this->createAdd("entry_link","HTMLLink",array(
					"link" => $this->entryPageUri . rawurlencode($entry->getAlias()),
					"soy2prefix" => "cms"
				));
			}
		}
	}

	$page->createAdd("next_entry","BlogPage_Entry_Navigation",array(
		"entryPageUri"=> $page->getEntryPageURL(true),
		"entry" => $next,
		"soy2prefix" => "b_block",
		"visible" => $next->getId()
	));

	$page->createAdd("prev_entry","BlogPage_Entry_Navigation",array(
		"entryPageUri"=> $page->getEntryPageURL(true),
		"entry" => $prev,
		"soy2prefix" => "b_block",
		"visible" => $prev->getId()
	));

}




/*
このブロックは、記事毎ページでご利用になれます。

このブロックで、記事に対して、閲覧者がコメントを投稿できるようにフォームを設置することができます。

ここで投稿されたコメント、管理ページより確認することができます。

このブロックは必ずFORMタグに使用してください。

<form b_block:id="comment_form">
	<p>タイトル：<input cms:id="title" /></p>
	<p>お名前：<input cms:id="author" /></p>
	<p>mail：<input cms:id="mail_address" /></p>
	<p>URL：<input cms:id="url" /></p>
	<p><textarea cms:id="body"></textarea></p>
	<input type="submit" value="投稿">
</form b_block:id="comment_form">
 */
function soy_cms_blog_output_comment_form($page,$entry,$entryComment){

	if(!class_exists("BlogPage_CommentForm")){
		class BlogPage_CommentForm extends HTMLForm{

			const SOY_TYPE = SOY2HTML::HTML_BODY;

			private $entryComment;

			function execute(){

				//cookieから読みだす：高速化キャッシュ対応のため廃止
				$array = array();
				//@parse_str($_COOKIE["soycms_comment"],$array);

				$this->createAdd("title","HTMLInput",array(
					"name" => "title",
					"value" => $this->entryComment->getTitle(),
					"soy2prefix" => "cms"
				));

				$this->createAdd("author","HTMLInput",array(
					"name" => "author",
					"value" => (strlen($this->entryComment->getAuthor()) > 0) ? $this->entryComment->getAuthor() : @$array["author"],
					"soy2prefix" => "cms"
				));

				$this->createAdd("body","HTMLTextArea",array(
					"name" => "body",
					"value" => $this->entryComment->getBody(),
					"soy2prefix" => "cms"
				));

				$this->createAdd("mail_address","HTMLInput",array(
					"name" => "mail_address",
					"value" => (strlen($this->entryComment->getMailAddress()) > 0) ? $this->entryComment->getMailAddress() : @$array["mailaddress"],
					"soy2prefix" => "cms"
				));

				$this->createAdd("url","HTMLInput",array(
					"name" => "url",
					"value" => (strlen($this->entryComment->getUrl()) > 0) ? $this->entryComment->getUrl() : @$array["url"],
					"soy2prefix" => "cms"
				));

				parent::execute();
			}


			function getEntryComment() {
				return $this->entryComment;
			}
			function setEntryComment($entryComment) {
				$this->entryComment = $entryComment;
			}
		}
	}

	$page->createAdd("comment_form","BlogPage_CommentForm",array(
		"action" => $page->getEntryPageURL(true) . $entry->getId() ."?comment",
		"soy2prefix" => "b_block",
		"entryComment" => (is_null($entryComment)) ? new EntryComment() : $entryComment,
		"visible" => ($entry->getId())
	));
}

/*
このブロックは、記事毎ページでご利用になれます。

このブロックで、記事に対して、投稿されたコメントの一覧を出力させることができます。

管理ページより、拒否に設定されているコメントは表示されません。


<!-- b_block:id="comment_list" -->
<div>
	<h5 cms:id="title" cms:alt="無題">タイトル</h5>
	<a cms:id="mail_address"><!-- cms:id="author" cms:alt="名無しさん" -->名前<!-- /cms:id="author" --></a>
	|<!-- cms:id="submit_date" cms:format="Y-m-d"-->2008-03-17<!-- /cms:id="submit_date"-->
	|<a cms:id="url">URL</a>
	<div cms:id="body" cms:alt="本文無し">本文</div>
	<span cms:id="submit_time" cms:format="H:i">17:52</span>
</div>
<!--/b_block:id="comment_list" -->

*/
function soy_cms_blog_output_comment_list($page,$entry){

	$dao = SOY2DAOFactory::create("cms.EntryCommentDAO");
	$_simpleCommentList = $dao->getApprovedCommentByEntryId($entry->getId());

	$rootCommentList = array();
	$childCommentList = array();
	$family = array();
	foreach($_simpleCommentList as $comment){
		if($comment->getParentId()){
			if(!isset($family[$comment->getParentId()])) $family[$comment->getParentId()] = array();
			$family[$comment->getParentId()][] = $comment->getId();
			$childCommentList[$comment->getId()] = array(
				"EntryComment" => $comment,
				"children"     => array(),
				"hasChild"     => false,
				"isFirstChild" => false,
				"isEndItem"    => false,
			);
		}else{
			$rootCommentList[$comment->getId()] = array(
				"EntryComment" => $comment,
				"children"     => array(),
				"hasChild"     => false,
				"isFirstChild" => false,
				"isEndItem"    => false,
			);
		}
	}

	$flatCommentListForHtmlList = array();
	foreach($rootCommentList as $commentId => $commentArray){
		$rootCommentList[$commentId]["children"] = __getChildren($commentId, $family, $childCommentList);
	}

	foreach($rootCommentList as $commentId => $commentArray){
		if(count($commentArray["children"])){
			$commentArray["hasChild"] = true;
		}
		$flatCommentListForHtmlList[] = $commentArray;
		if(count($commentArray["children"])){
			$flatCommentListForHtmlList = __getFlatChildren($flatCommentListForHtmlList, $commentArray["children"]);
		}
	}

	$page->createAdd("comment_tree_list","Blog_CommentTreeList",array(
		"list" => $flatCommentListForHtmlList,
		"soy2prefix" => "b_block",
		"visible" => ($entry->getId())
	));
	$page->createAdd("comment_list","Blog_CommentList",array(
		"list" => $_simpleCommentList,
		"soy2prefix" => "b_block",
		"visible" => ($entry->getId())
	));

	$page->addModel("has_comment",array(
		"visible" => count($_simpleCommentList),
		"soy2prefix" => "b_block",
	));

}

function __getChildren($parentId, $family, $childCommentList){
	$array = array();
	if(isset($family[$parentId]) && is_array($family[$parentId]) && count($family[$parentId])){
		foreach($family[$parentId] as $childCommentId){
			$childCommentList[$childCommentId]["children"] = __getChildren($childCommentId, $family, $childCommentList);
			$array[] = $childCommentList[$childCommentId];
		}
	}
	return $array;
}

function __getFlatChildren($flatCommentListForHtmlList, $childList){
	foreach($childList as $key => $childComment){
		$childComment["isFirstChild"] = ( $key === 0 );
		if(count($childComment["children"])){
			$childComment["hasChild"] = true;
		}
		$flatCommentListForHtmlList[] = $childComment;
		if(count($childComment["children"])){
			$flatCommentListForHtmlList = __getFlatChildren($flatCommentListForHtmlList, $childComment["children"]);
		}
	}

	if(count($childList)){
		$flatCommentListForHtmlList[] = array(
				"isEndItem"    => true,
				"EntryComment" => null,
		);
	}

	return $flatCommentListForHtmlList;
}

/*
親子関係で入れ子にするコメントリスト
<div id="comment_tree">
<!-- b_block:id="comment_tree_list" -->
	<!-- cms:id="is_not_end_item" -->
	<div class="comment_item">
		<h4 class="comment_body_title"><!-- cms:id="title" cms:alt="無題" -->コメントのタイトル<!-- /cms:id="title" --> <!-- cms:id="author" cms:alt="名無しさん" -->名前<!-- /cms:id="author" --> | <!-- cms:id="submit_date" cms:format="Y/m/d H:i" -->March 23:15<!-- /cms:id="submit_date" --></h4>
		<p class="comment_body_content" cms:id="body">コメントの本文がここに<br />改行つきで表示されます。<br />コメントの本文がここに<br />改行つきで表示されます。<br />コメントの本文がここに<br />改行つきで表示されます。<br />コメントの本文がここに<br />改行つきで表示されます。<br /></p>
	<!-- cms:id="has_no_child" --></div><!-- no child --><!-- /cms:id="has_no_child" -->
	<!-- /cms:id="is_not_end_item" -->
	</div cms:id="is_end_item">
<!-- /b_block:id="comment_tree_list" -->
</div>

 */
class Blog_CommentTreeList extends HTMLList{

	function getStartTag(){
		return '<a name="comment_list"></a>'.parent::getStartTag();
	}

	function populateItem($commentArray){
		/*
		array(
			"EntryComment" => $comment,
			"children"     => array(),
			"hasChild"     => false,
			"isFirstChild" => false,
			"isEndItem"    => false,
		)
		*/

		$comment = isset($commentArray["EntryComment"]) ? $commentArray["EntryComment"] : new EntryComment();

		$hasChild = isset($commentArray["hasChild"]) ? $commentArray["hasChild"] : false;
		$this->addModel("has_child", array(
				"visible" => $hasChild,
				"soy2prefix" => "cms",
		));
		$this->addModel("has_no_child", array(
				"visible" => !$hasChild,
				"soy2prefix" => "cms",
		));
		$this->addModel("is_first_child", array(
				"visible" => isset($commentArray["isFirstChild"]) ? $commentArray["isFirstChild"] : false,
				"soy2prefix" => "cms",
		));
		$isEndItem = isset($commentArray["isEndItem"]) ? $commentArray["isEndItem"] : false;
		$this->addModel("is_end_item", array(
				"visible" => $isEndItem,
				"soy2prefix" => "cms",
		));
		$this->addModel("is_not_end_item", array(
				"visible" => !$isEndItem,
				"soy2prefix" => "cms",
		));
		$this->addLabel("comment_id", array(
				"text" => $comment->getId(),
				"soy2prefix" => "cms",
		));
		$this->addLabel("parent_id", array(
				"text" => $comment->getParentId(),
				"soy2prefix" => "cms",
		));

		$this->createAdd("title","CMSLabel",array(
				"text" => $comment->getTitle(),
				"soy2prefix" => "cms"
		));
		$this->createAdd("author","CMSLabel",array(
				"text" => $comment->getAuthor(),
				"soy2prefix" => "cms"
		));

		$comment_body = str_replace("\n","@@@@__BR__MARKER__@@@@",$comment->getBody());
		$comment_body = htmlspecialchars($comment_body, ENT_QUOTES, "UTF-8");
		$comment_body = str_replace("@@@@__BR__MARKER__@@@@","<br>",$comment_body);

		$this->createAdd("body","CMSLabel",array(
				"html" => $comment_body,
				"soy2prefix" => "cms"
		));

		$this->createAdd("submit_date","DateLabel",array(
				"text" => $comment->getSubmitDate(),
				"soy2prefix" => "cms"
		));
		$this->createAdd("submit_time","DateLabel",array(
				"text"=>$comment->getSubmitDate(),
				"soy2prefix"=>"cms",
				"defaultFormat"=>"H:i"
		));
		$this->createAdd("url","HTMLLink",array(
				"link" => $comment->getUrl(),
				"soy2prefix" => "cms"
		));
		$this->createAdd("mail_address","HTMLLink",array(
				"link" => "mailto:".$comment->getMailAddress(),
				"soy2prefix" => "cms"
		));
	}
}

class Blog_CommentList extends HTMLList{

	function getStartTag(){
		return '<a name="comment_list"></a>'.parent::getStartTag();
	}

	function populateItem($comment){

		$this->createAdd("title","CMSLabel",array(
				"text" => $comment->getTitle(),
				"soy2prefix" => "cms"
		));
		$this->createAdd("author","CMSLabel",array(
				"text" => $comment->getAuthor(),
				"soy2prefix" => "cms"
		));

		$comment_body = str_replace("\n","@@@@__BR__MARKER__@@@@",$comment->getBody());
		$comment_body = htmlspecialchars($comment_body, ENT_QUOTES, "UTF-8");
		$comment_body = str_replace("@@@@__BR__MARKER__@@@@","<br>",$comment_body);

		$this->createAdd("body","CMSLabel",array(
				"html" => $comment_body,
				"soy2prefix" => "cms"
		));



		$this->createAdd("submit_date","DateLabel",array(
				"text" => $comment->getSubmitDate(),
				"soy2prefix" => "cms"
		));
		$this->createAdd("submit_time","DateLabel",array(
				"text"=>$comment->getSubmitDate(),
				"soy2prefix"=>"cms",
				"defaultFormat"=>"H:i"
		));
		$this->createAdd("url","HTMLLink",array(
				"link" => $comment->getUrl(),
				"soy2prefix" => "cms"
		));
		$this->createAdd("mail_address","HTMLLink",array(
				"link" => "mailto:".$comment->getMailAddress(),
				"soy2prefix" => "cms"
		));
	}
}


/*
このブロックは、記事毎ページでご利用になれます。

このブロックで、記事に対して、投稿されたトラックバックの一覧を出力させることができます。

管理ページより、拒否に設定されているトラックバックは表示されません。

投稿されたトラックバックは初期状態は拒否になっているため、許可に設定しなければ表示されないことにご注意ください。

<ul>
<!-- b_block:id="trackback_list" -->
	<li>
		<h5 cms:id="title">タイトル</h5>
		<a cms:id="url"><!-- cms:id="blog_name"-->ブログ名<!-- /cms:id="blog_name"--></a>
		<p cms:id="excerpt">要約</p>
		<span cms:id="submit_date" cms:format="Y/m/d H:i">2008/03/15 12:35</span>
	</li>
<!--/b_block:id="trackback_list" -->
</ul>
*/
function soy_cms_blog_output_trackback_list($page,$entry){

	if(!class_exists("Blog_TrackbackList")){
		class Blog_TrackbackList extends HTMLList{

			function getStartTag(){
				return '<a name="trackback_list"></a>'.parent::getStartTag();
			}

			function populateItem($trackback){

				$this->createAdd("title","CMSLabel",array(
					"text"=>$trackback->getTitle(),
					"soy2prefix" => "cms"
				));
				$this->createAdd("url","HTMLLink",array(
					"link"=>$trackback->getUrl(),
					"soy2prefix" => "cms"
				));
				$this->createAdd("blog_name","CMSLabel",array(
					"text"=>$trackback->getBlogName(),
					"soy2prefix" => "cms"
				));
				$this->createAdd("excerpt","CMSLabel",array(
					"html"=> str_replace("\n","<br>", htmlspecialchars($trackback->getExcerpt(), ENT_QUOTES, "UTF-8")),
					"soy2prefix" => "cms"
				));
				$this->createAdd("submit_date","DateLabel",array(
					"text"=>$trackback->getSubmitdate(),
					"soy2prefix" => "cms"
				));
				$this->createAdd("submit_time","DateLabel",array(
					"text"=>$trackback->getSubmitdate(),
					"soy2prefix"=>"cms",
					"defaultFormat"=>"H:i"
				));

			}
		}
	}

	$dao = SOY2DAOFactory::create("cms.EntryTrackbackDAO");
	$trackbackList = $dao->getCertificatedTrackbackByEntryId($entry->getId());

	$page->createAdd("trackback_list","Blog_TrackbackList",array(
		"list" => $trackbackList,
		"soy2prefix" => "b_block",
		"visible" => ($entry->getId())
	));

	$page->addModel("has_trackback",array(
		"visible" => count($trackbackList),
		"soy2prefix" => "b_block",
	));

}


/*
このブロックは、記事毎ページでご利用になれます。

このブロックで、この記事に投稿するためのURLを出力します。

このブロックは必ずINPUTタグにご使用ください。

<input b_block:id="trackback_link">
 */
function soy_cms_blog_output_trackback_link($page,$entry){

	/**
	 * 絶対URL（http://～）
	 */
	$trackbackUrl = $page->getEntryPageURL(true) . $entry->getId() ."?trackback";

	if(!class_exists("Blog_TrackbackURL")){
		class Blog_TrackbackURL extends HTMLLabel{

			function execute(){

				parent::execute();

				if($this->tag == "input"){
					$this->setInnerHTML("");
				}else{
					$this->clearAttribute("value");
				}
			}
		}
	}

	$page->createAdd("trackback_link","Blog_TrackbackURL",array(
		"value" => $trackbackUrl,
		"text" => $trackbackUrl,
		"soy2prefix" => "b_block",
		"type"=>"text"
	));
}


class BlogPage_PagerList extends HTMLList{

	//今のページ番号
	var $current;
	//最大ページ数
	var $last;
	//ベースURL=最初のページのURL
	var $url;
	function setCurrent($current){
		$this->current = $current;
	}
	function setUrl($url){
		$this->url = $url;
	}

	protected function populateItem($page_num){

		$this->last = count($this->list);

		$url = $this->url;
		if($page_num >1){
			$url = $url."?p=".$page_num;
		}
		if($page_num == $this->current){
			$url = "";
		}

		$class = array();
		if($page_num == $this->current) $class[] = "current_page_number";
		if($page_num == 1) $class[] = "first_page_number";
		if($page_num == $this->last) $class[] = "last_page_number";

		$html = "";
		if(strlen($url)){
			$html .= "<a href=\"".htmlspecialchars($url, ENT_QUOTES, "UTF-8")."\"";
			if(count($class)) $html .= " class=\"".implode(" ",$class)."\"";
			$html .= ">";
		}
		$html .= htmlspecialchars($page_num, ENT_QUOTES, "UTF-8");
		if(strlen($url)) $html .= "</a>";

		$this->createAdd("pager_item","HTMLLabel",array(
				"html" => $html,
				"soy2prefix" => "cms"
		));
		$this->createAdd("pager_item_link", "HTMLLink", array(
				"link" => $url,
				"soy2prefix" => "cms"
		));
		$this->createAdd("pager_item_number", "HTMLLabel", array(
				"text" => $page_num,
				"soy2prefix" => "cms"
		));

		$this->createAdd("is_first","HTMLModel",array(
				"visible" => ($page_num == 1),
				"soy2prefix" => "cms"
		));
		$this->createAdd("is_last","HTMLModel",array(
				"visible" => ($page_num == $this->last),
				"soy2prefix" => "cms"
		));
		$this->createAdd("is_middle","HTMLModel",array(
				"visible" => ($page_num > 1 && $page_num < $this->last),
				"soy2prefix" => "cms"
		));
		$this->createAdd("is_current","HTMLModel",array(
				"visible" => ($page_num == $this->current),
				"soy2prefix" => "cms"
		));
	}

}

