<div>
<h3>設定</h3>
<pre style="margin:5px;border:1px solid #000000;padding:3px;">
&lt;-- app:id="soygallery_plugin" app:galleryId="ギャラリID" app:count="表示件数" --&gt;

&lt;-- cms:id="image_list" --&gt;
&lt;img cms:id="image"&gt;
&lt;-- /cms:id="image_list" --&gt;

&lt;-- /app:id="soygallery_plugin" --&gt;
</pre>

</div>