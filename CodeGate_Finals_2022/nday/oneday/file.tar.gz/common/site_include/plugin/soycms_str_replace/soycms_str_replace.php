<?php
/**
 * 文字列置換プラグイン
 */
SOYCMS_Str_Replace_Plugin::registerPlugin();


class SOYCMS_Str_Replace_Plugin{

	const PLUGIN_ID = "soycms_str_replace";

	private $config = array(
		"settings" => array(),
		"phrases" => array(),
	);

	private function getId(){
		return self::PLUGIN_ID;
	}

	/**
	 * 初期化
	 */
	public function init(){

		CMSPlugin::addPluginMenu($this->getId(),array(
			"name"=>"文字列置換プラグイン",
			"description"=>"出力時に文字列の置換を行います。",
			"author"=>"株式会社Brassica",
			"url"=>"https://brassica.jp/",
			"mail"=>"soycms@soycms.net",
			"version"=>"1.0"
		));
		CMSPlugin::addPluginConfigPage($this->getId(),array(
			$this,"config_page"
		));

		//イベント登録
		if(CMSPlugin::activeCheck($this->getId())){
			CMSPlugin::setEvent('onOutput',$this->getId(),array($this,"onOutput"));
		}
	}

	/**
	 * 設定画面
	 */
	public function config_page(){

		if(isset($_POST["add"])){

			$phrase = $_POST["phrase"];

			if(strlen($phrase["key"])>0) $this->config["phrases"][$phrase["key"]] = $phrase["value"];

			$this->save();

			//CMSUtil::notifyUpdate();
			CMSPlugin::redirectConfigPage();

			exit;
		}

		if(isset($_POST["save"])){

			$this->config["phrases"]= array();

			foreach($_POST["phrases"] as $key => $phrase){
				if(strlen($phrase["key"])>0)
					$this->config["phrases"][$phrase["key"]] = $phrase["value"];
			}

			$this->save();
			//CMSUtil::notifyUpdate();
			CMSPlugin::redirectConfigPage();

			exit;
		}

		if(isset($_POST["clear"])){

			foreach($_POST["clear_phrases"] as $value){
				if(isset($this->config["phrases"][$value])){
					unset($this->config["phrases"][$value]);
				}
			}

			//CMSUtil::notifyUpdate();
			$this->save();
			CMSPlugin::redirectConfigPage();

			exit;
		}

		ob_start();
		include_once(dirname(__FILE__) . "/config.php");
		$html = ob_get_contents();
		ob_end_clean();

		return $html;
	}

	/**
	 * 出力時によびだし
	 */
	public function onOutput($arguments){

		$html = $arguments["html"];
		$isReplaced = false;

		if(isset($this->config["phrases"])){
			foreach($this->config["phrases"] as $key => $value){
				if(strpos($html, $key) !== false){
					$isReplaced = true;
					break;
				}
			}
			if($isReplaced){
				$html = strtr($html,$this->config["phrases"]);
			}
		}

		if($isReplaced){
			return $html;
		}
	}

	private function save(){
		CMSPlugin::savePluginConfig($this->getId(),$this->config);
	}

	/**
	 * プラグインの登録
	 */
	public static function registerPlugin(){

		$obj = new SOYCMS_Str_Replace_Plugin();
		$array = CMSPlugin::loadPluginConfig(self::PLUGIN_ID);
		if(is_array($array)){
			$obj->config = $array;
		}

		CMSPlugin::addPlugin(self::PLUGIN_ID,array($obj,"init"));
	}

}
?>
