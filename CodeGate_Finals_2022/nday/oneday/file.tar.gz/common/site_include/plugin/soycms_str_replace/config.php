<?php
/*
 * Created on 2008/12/15
 *
 * To change the template for this generated file go to
 * Window - Preferences - PHPeclipse - PHP - Code Templates
 */
?>
<form method="post">

<?php if(count($this->config["phrases"])>0){ ?>

<table class="table table-striped">
	<tr>
		<th>&nbsp;</th>
		<th>置換対象</th>
		<th>置換後</th>
	</tr>

	<?php
	$_index = 0;
	foreach($this->config["phrases"] as $key => $value){
		$_index++;
		$_key = htmlspecialchars($key, ENT_QUOTES, "UTF-8");
		$_value = htmlspecialchars($value, ENT_QUOTES, "UTF-8");
	?>
	<tr>
		<td style="width: 2em;">
			<input type="checkbox" name="clear_phrases[]" value="<?php echo $_key; ?>" />
		</td>
		<td>
			<input class="form-control" type="text" name="phrases[<?php echo $_index; ?>][key]" value="<?php echo $_key; ?>" />
		</td>
		<td>
			<textarea class="form-control" type="text" name="phrases[<?php echo $_index; ?>][value]">
<?php echo $_value; ?>
</textarea>
		</td>
	</tr>
	<?php } ?>

	<tr>
		<td colspan="3">
			<input type="submit" name="save" value="保存" class="btn btn-success">
			<input type="submit" name="clear" value="チェックを削除"  class="btn btn-danger">
		</td>
	</tr>

</table>
<?php } ?>

<div class="panel panel-default">
	<div class="panel-heading">追加</div>
	<table class="table table-striped">
		<tr>
			<td>
				<input class="form-control" type="text" name="phrase[key]" placeholder="置換対象">
			</td>
			<td>
				<textarea class="form-control" type="text" name="phrase[value]" placeholder="置換後">
</textarea>
			</td>
			<td>
				<input type="submit" name="add" value="追加" class="btn btn-success">
			</td>
		</tr>
	</table>
</div>

</form>


<div class="panel panel-default">
	<div class="panel-heading">使い方</div>
	<div class="panel-body">
	SOY CMSのサイトから出力されるウェブページに「置換対象」の文字列が含まれていれば「置換後」の文字列に置換されます。
	</div>
</div>

<div class="panel panel-default">
	<div class="panel-heading">設定例</div>
	<table class="table table-striped">
		<tr>
			<th>置換対象</th>
			<th>置換後</th>
			<th>備考</th>
		</tr>
		<form method="post">
		<tr>
			<td>
				<input class="form-control" type="text" name="phrase[key]" value="=&quot;http://<?php echo htmlspecialchars($_SERVER["HTTP_HOST"],ENT_QUOTES,"UTF-8") ?>/" readonly>
			</td>
			<td>
				<input class="form-control" type="text" name="phrase[value]" value="=&quot;https://<?php echo htmlspecialchars($_SERVER["HTTP_HOST"],ENT_QUOTES,"UTF-8") ?>/" readonly>
			</td>
			<td>
				画像、CSS、JSなどの参照をhttpsにする
				<input type="submit" name="add" value="追加" class="btn btn-success pull-right">
			</td>
		</tr>
		</form>
		<form method="post">
		<tr>
			<td>
				<input class="form-control" type="text" name="phrase[key]" value="@@MY_VALUE@@" readonly>
			</td>
			<td>
				<input class="form-control" type="text" name="phrase[value]" value="私の定数" readonly>
			</td>
			<td>
				まとめて管理したい文字列定数など
				<input type="submit" name="add" value="追加" class="btn btn-success pull-right">
			</td>
		</tr>
		</form>
	</table>
</div>
