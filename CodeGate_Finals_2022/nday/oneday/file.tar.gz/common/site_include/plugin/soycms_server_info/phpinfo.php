<?php
if(!class_exists("UserInfoUtil") OR !UserInfoUtil::isDefaultUser())exit;

phpinfo();
exit;
