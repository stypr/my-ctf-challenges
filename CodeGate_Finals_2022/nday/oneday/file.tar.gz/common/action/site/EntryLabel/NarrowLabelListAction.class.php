<?php
/**
 * ラベルを複数指定し、そのラベルに割り当てられているエントリーについているすべてのラベルを取得する
 */
class NarrowLabelListAction extends SOY2Action{

	private $labelIds = array();

	function setLabelIds($labelIds){
		$this->labelIds = $labelIds;
	}

	function execute() {

		$logic = SOY2Logic::createInstance("logic.site.Label.LabelLogic");
		$subLabelIds = $logic->getEntryCountByLabelIdForNarrowEntries($this->labelIds);

		//記事管理者に見えないラベルを除外する
		if(count($subLabelIds)){
			$prohibitedLabelIds = $logic->getProhibitedLabelIds();
			foreach($prohibitedLabelIds as $labelId){
				if(isset($subLabelIds[$labelId])){
					unset($subLabelIds[$labelId]);
				}
			}
		}

		$this->setAttribute("CountByLabelId",$subLabelIds);

		return SOY2Action::SUCCESS;

	}
}
?>