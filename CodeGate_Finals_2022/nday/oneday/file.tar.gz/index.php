dev blog in progress..
